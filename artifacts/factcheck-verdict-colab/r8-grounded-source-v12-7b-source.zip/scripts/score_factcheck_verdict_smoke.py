"""Check the six reviewed v6.1 development cases after inference."""
import argparse
from importlib import import_module
import json
from pathlib import Path


source_segments = import_module('04_factchecker.inference.semantic_verdict').source_segments
CASE_IDS = tuple(f'holdout-v6:{number:03d}' for number in (4, 13, 21, 25, 27, 29))
NUMERIC_CASE_IDS = tuple(f'holdout-v6:{number:03d}' for number in (3, 9, 11, 14, 16, 28))
SAMPLING_CASE_IDS = tuple(sorted((*NUMERIC_CASE_IDS, 'holdout-v6:023')))


def score(cases, predictions, *, case_ids=CASE_IDS):
    if tuple(case['example_id'] for case in cases) != case_ids:
        raise ValueError('Unexpected smoke gold roster')
    if tuple(row['example_id'] for row in predictions) != case_ids:
        raise ValueError('Predictions must cover all smoke cases in order')
    details = []
    for case, row in zip(cases, predictions):
        result = row['result']
        label = result['assessed_label'] if result['status'] == 'completed' else None
        verdict = result.get('verdict', {})
        ids = verdict.get('evidence_ids', [])
        context = case['context']
        segments = source_segments(context)
        spans = [dict(id=key, **segments[key]) for key in ids if key in segments]
        grounded = (label is not None and verdict.get('label') == label and len(spans) == len(ids)
                    and len(ids) <= 4 and len(ids) == len(set(ids))
                    and spans == verdict.get('evidence_spans')
                    and [span['text'] for span in spans] == verdict.get('evidence')
                    and (label == 'not_enough_info' or bool(spans)))
        reference_covered = all(
            char.isspace() or any(span['start'] <= offset < span['end'] for span in spans)
            for proof in case['required_evidence']
            for offset, char in enumerate(context[proof['start']:proof['end']], start=proof['start'])
        )
        check = result.get('evidence_check') or {}
        details.append(dict(id=case['example_id'], expected=case['label'], predicted=label,
                            grounded=grounded, reference_covered=reference_covered,
                            evidence_ids=ids, evidence=[span['text'] for span in spans],
                            proof_method=check.get('method'), proof_stage=check.get('stage'),
                            proof_detail=check.get('reason'),
                            reasoning=verdict.get('reasoning'), error=result.get('error_detail')))
    correct = sum(item['expected'] == item['predicted'] for item in details)
    false_support = sum(item['predicted'] == 'support' and item['expected'] != 'support' for item in details)
    passed = correct == len(case_ids) and false_support == 0 and all(
        item['grounded'] and item['reference_covered'] for item in details
    )
    return dict(smoke_pass=passed, correct=correct, false_support=false_support, cases=details)


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--cases', type=Path, required=True)
    cli.add_argument('--predictions', type=Path, required=True)
    profiles = {'source-id': CASE_IDS, 'numeric': NUMERIC_CASE_IDS, 'sampling': SAMPLING_CASE_IDS}
    cli.add_argument('--profile', choices=profiles, default='source-id')
    args = cli.parse_args()
    report = score(json.loads(args.cases.read_bytes()),
                   [json.loads(line) for line in args.predictions.read_bytes().splitlines()],
                   case_ids=profiles[args.profile])
    print(json.dumps(report, ensure_ascii=True, indent=2))
    raise SystemExit(0 if report['smoke_pass'] else 1)
