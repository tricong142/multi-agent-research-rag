"""Offline Cellfix20 holdout integrity and direct-human gold admission; no inference."""
import argparse
import json
from pathlib import Path
import zipfile

if __package__:
    from . import atomic_holdout_review as core
else:
    import holdout_gate_core as core

CRITERIA = "11157355f308c59997b63b6f46b0304c79d9d8f403a25e2ebea3d1cd9c2dd308"
FREEZE = "70d59a5be79fce2844613a9bc054825f79cb4b6c82dacb905b2703948beb5347"


def verify(folder):
    # The existing gate logic is snapshotted; only this new wrapper rebinds it.
    previous = core.CRITERIA_SHA256
    try:
        core.CRITERIA_SHA256 = CRITERIA
        manifest, rows = core.verify(folder)
    finally:
        core.CRITERIA_SHA256 = previous
    folder = Path(folder)
    binding = json.loads((folder / "candidate-binding.json").read_bytes())
    if (binding["accepted_freeze_lock_sha256"] != FREEZE or binding["candidate_criteria_sha256"] != CRITERIA
            or binding["candidate"] != "atomic-verifier-constrained-v8-cellfix20"):
        raise ValueError("Wrong frozen Cellfix20 binding")
    for name in ("model-settings.json", "criteria.json"):
        settings = json.loads((folder / name).read_bytes())
        if any(settings.get(k) != v for k, v in binding.items()):
            raise ValueError("Inconsistent protocol/model binding")
    with zipfile.ZipFile(folder / "blind-inputs.zip") as archive:
        if sorted(archive.namelist()) != ["inputs.jsonl", "model-settings.json"]:
            raise ValueError("Gold or unexpected file in blind archive")
        if any(archive.read(n) != (folder / n).read_bytes() for n in archive.namelist()):
            raise ValueError("Blind archive differs from locked inputs")
    overlap = json.loads((folder / "overlap-report.json").read_bytes())
    if overlap["development30_paper_overlap"] or not overlap["selected_in_test_candidate"]:
        raise ValueError("Wrong or overlapping holdout papers")
    return manifest, rows


def admit_holdout(folder, review):
    verify(folder)
    if review.get("accepted_freeze_lock_sha256") != FREEZE or review.get("no_holdout_used_for_tuning") is not True:
        raise ValueError("Freeze binding and explicit no-run/no-tuning declaration required")
    for decision in review.get("decisions", []):
        if any(decision.get("checks", {}).get(key) is not True for key in core.CHECKS):
            raise ValueError("Every human annotation criterion must be explicitly true")
    result = core.admit(folder, review)
    return {**result, "accepted_freeze_lock_sha256": FREEZE,
            "packet_lock_sha256": core.digest((Path(folder) / "packet-lock.json").read_bytes()),
            "annotation_review_sha256": core.digest(core.json_bytes(review)),
            "independent_validation_completed": False, "promoted_to_serving": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--packet", required=True, type=Path)
    parser.add_argument("--review", type=Path)
    parser.add_argument("--lock", type=Path)
    args = parser.parse_args()
    if bool(args.review) != bool(args.lock):
        parser.error("Use --review and --lock together")
    manifest, rows = verify(args.packet)
    if args.review:
        result = admit_holdout(args.packet, json.loads(args.review.read_bytes()))
        core.write_once(args.lock, core.json_bytes(result))
    else:
        result = dict(status="frozen_pending_human_annotation", cases=len(rows), papers=manifest["papers"],
                      inference_completed=False, independent_validation_completed=False)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
