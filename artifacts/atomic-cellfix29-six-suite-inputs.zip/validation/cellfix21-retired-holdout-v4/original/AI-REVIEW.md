# AI review trước inference — không phải human admission

Đọc lại 30 claim/context và evidence đề xuất: chưa phát hiện nhãn cần đổi. Đây là nhận xét AI, cần người duyệt từng tiêu chí; không có prediction candidate.

## holdout-v4:001 — support

The source explicitly gives two occupation categories and names both.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:002 — contradict

The asserted total of three categories conflicts with the stated total of two.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:003 — not_enough_info

A source list and category definition do not establish who assigned labels or how many annotators participated.

Thiếu thông tin: The paragraph does not identify the number or independence of human annotators assigning these categories.

## holdout-v4:004 — support

The source binds the majority coverage and 2000-2015 interval specifically to men's matches.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:005 — contradict

The stated start year for women's matches is 2007, whereas 2000 belongs to the men's interval.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:006 — not_enough_info

The interview selection interval is supplied, but it does not determine the transcript count.

Thiếu thông tin: The total number of selected interview transcripts is not reported in this paragraph.

## holdout-v4:007 — support

The adjacent sentences bind the model, APPA-REAL test condition, accuracy metric and exact value.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:008 — contradict

For the same model, metric and test condition, the reported value is 91.00%, not 81.00%.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:009 — not_enough_info

The paragraph reports accuracy and uneven error distribution, but no recall value.

Thiếu thông tin: Recall on APPA-REAL is not reported; the stated accuracy does not determine recall.

## holdout-v4:010 — support

The test-set role and coverage of every reported experiment are stated explicitly.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:011 — contradict

The denial of any test-set use is refuted by the explicit statement that all reported experiments used this test set.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:012 — not_enough_info

The paragraph gives an utterance count and alignment language but no duration measurement.

Thiếu thông tin: The total speech duration in hours is not stated; the utterance count does not determine duration.

## holdout-v4:013 — support

Hindi and Urdu are the explicit exceptions for which LAS results are identical.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:014 — contradict

A universal strict improvement is refuted by the two named languages with identical results.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:015 — not_enough_info

The source compares parsing accuracy, which does not establish a parameter-count ordering.

Thiếu thông tin: Parameter counts or a parameter-count comparison between char-lstm and char-cnn are not provided.

## holdout-v4:016 — support

The source identifies both the exact headline count and The Onion as the satirical source.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:017 — contradict

The serious corpus has 9000 headlines; 9159 is the count for the distinct satirical corpus.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:018 — not_enough_info

The paragraph reports headlines and news sources, not the lengths or token counts of headlines.

Thiếu thông tin: The word-token count is not supplied; a headline count cannot establish a word-token count.

## holdout-v4:019 — support

The source directly binds the Raw Text column to a physician as its author.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:020 — contradict

The explicit positive count refutes the claim of no death certificates.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:021 — not_enough_info

A total across three periods does not establish the count for the 2014 subset.

Thiếu thông tin: The total is reported, but the number of certificates specifically for 2014 is not supplied.

## holdout-v4:022 — support

The source explicitly states removal of all such trailing hashtags before training and testing.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:023 — contradict

Retaining these hashtags during training/testing conflicts with removing all of them beforehand.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:024 — not_enough_info

A preprocessing description alone does not establish a quantified accuracy improvement.

Thiếu thông tin: No test-accuracy measurement or ablation estimating the effect of hashtag removal is reported in this paragraph.

## holdout-v4:025 — support

The source names the three splits and explicitly states that entities do not overlap across them.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:026 — contradict

The existence of a shared training/test entity conflicts with the explicit non-overlap policy.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:027 — not_enough_info

Article/topic counts, stance percentages and split sizes do not determine the number of languages.

Thiếu thông tin: The paragraph does not state the languages or the number of languages in the dataset.

## holdout-v4:028 — support

The statement explicitly includes the CNN in the models for which all tested active learning strategies did not work well.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:029 — contradict

The asserted universal success is the opposite of the reported result for the same strategies and CNN.

Quote được đối chiếu nguyên văn với context; cần người duyệt phạm vi/predicate của claim.

## holdout-v4:030 — not_enough_info

A qualitative statement about active learning suitability does not determine a CNN accuracy value.

Thiếu thông tin: The paragraph does not provide a numerical CNN accuracy.

