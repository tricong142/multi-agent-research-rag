# Cellfix20 holdout30-v3 — chờ người review gold

Đây là phiên bản/binding mới cho candidate Cellfix20 đã đóng băng, tái sử dụng
30 claim / 10 paper của packet Cellfix16 chưa chạy. Không phải development30.
Đã rà lại exposure đến Cellfix20, kiểm nguồn cache và đọc lại 30 nhãn đề xuất.
Chưa chạy model; chưa có score holdout hoặc chứng nhận Reader/Writer.

1. Mở REVIEW.html, đọc claim/context/evidence/missing information của từng ca.
   AI-REVIEW.md là ghi chú hỗ trợ do AI viết, không thay chữ ký người review.
2. Chọn nhãn, đánh giá đủ 5 tiêu chí, viết ghi chú, điền tên/ngày và các khai báo.
   Không tick đúng nếu có lỗi. Xuất annotation-review.json bằng nút cuối trang.
3. Kiểm và khóa gold bằng lệnh bên dưới, trước mọi prediction holdout.
   Nếu cần sửa nhãn/evidence/context: giữ packet này, tạo phiên bản mới rồi
   review lại; gate cố ý từ chối đổi gold âm thầm trong bản đã khóa nội dung.

    python review_gate.py --packet .
    python review_gate.py --packet . --review annotation-review.json --lock holdout-annotation-admission.json

Lệnh chạy từ thư mục giải nén packet. Gate không gọi model. REVIEW.html chưa
điền sẵn checkbox, tên, ngày hoặc chấp thuận. packet-lock.json chỉ khóa nội dung;
holdout-annotation-admission.json chỉ được tạo khi review thực tế hợp lệ.

Sau admission, cần xác minh freeze Cellfix20 và exposure vẫn không thay đổi,
rồi dùng một job holdout riêng đã kiểm tra cách nạp binding/budget. Chỉ đưa
blind-inputs.zip cho inference (id/claim/context + model settings); giữ labels,
evidence và full review packet ở phía đánh giá. Không thay bộ trong cell 7
development30. Packet này chưa cung cấp/chạy job inference holdout.

Protocol criteria.json yêu cầu 30/30, không false support/runtime failure,
đủ 10 paper, trace/token/deadline/budget đo thực tế. Lưu mọi outcome kể cả lỗi
và technical rerun; nếu dùng kết quả để tuning thì chuyển bộ này sang development.

NEI chỉ áp dụng context được cấp, không tuyên bố toàn paper thiếu thông tin.
Nguồn là bản QASPER cache đã hash, không phải PDF mới tải. 3 ca đối chiếu mỗi
paper có tương quan; 10 paper là pilot nhỏ. Không chứng minh dữ liệu tiền huấn
luyện chưa thấy, không phải đánh giá retrieval hay toàn pipeline Reader/Writer.
