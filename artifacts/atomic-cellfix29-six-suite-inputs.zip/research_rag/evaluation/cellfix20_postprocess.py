"""Exact schema replay with per-request memoization and observable checkpoints."""
from importlib import import_module
import json
from pathlib import Path
import time


def progress_writer(output, started, write_summary):
    output = Path(output)
    def progress(event):
        record = {**event, 'elapsed_ms': round((time.perf_counter()-started)*1000, 3)}
        write_summary(output/'progress.json', record)
        with (output/'progress.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(record)+'\n')
        print(json.dumps({'event':'postprocess_progress', **record}), flush=True)
    return progress


def decoding_trace_complete(decoding, generations, messages, criteria, on_progress=None):
    if len(generations) != len(messages) or not generations:
        return False
    runtime = import_module(decoding.__package__ + '.cellfix14_runtime')
    # This cache lives only for this audit, not across runs or candidates.
    hashes = {}
    for index, (event, request) in enumerate(zip(generations, messages), 1):
        if on_progress:
            on_progress(dict(phase='schema_replay', state='running', call_index=index,
                             call_count=len(generations), example_id=event.get('example_id')))
        key = tuple((m['role'], m['content']) for m in request)
        if key not in hashes:
            with runtime.decode_request(None):
                hashes[key] = decoding.schema_sha256(decoding.schema_for(request)[0])
        valid = (event.get('structured_decoder') == criteria['structured_decoder']
                 and event.get('schema_sha256') == hashes[key]
                 and (not criteria.get('require_cooperative_deadline') or event.get('deadline_stop_enabled') is True))
        if not valid:
            if on_progress:
                on_progress(dict(phase='schema_replay', state='failed', call_index=index))
            return False
    if on_progress:
        on_progress(dict(phase='schema_replay', state='completed', call_count=len(generations)))
    return True
