"""Regression variants for retired development evidence; no model accuracy claims."""
from copy import deepcopy
import importlib
import json
from pathlib import Path
import unittest

a = importlib.import_module('04_factchecker.inference.atomic_verifier')
d = importlib.import_module('04_factchecker.inference.atomic_decoding')
r = importlib.import_module('04_factchecker.inference.cellfix21_rules')
c = importlib.import_module('04_factchecker.inference.cellfix14_decomposition')
binding = importlib.import_module('04_factchecker.inference.cellfix14_binding_rules')
n = importlib.import_module('04_factchecker.inference.numeric_verifier')


class Cellfix21Tests(unittest.TestCase):
    def test_comparison_paraphrases_and_epistemic_negatives(self):
        for subject,other in [('Juniper','Spruce'),('Atlas parser','Beacon parser')]:
            for verb in ('uses','used','has','had','requires','required'):
                claim=f'{subject} {verb} fewer parameters than {other}.'
                part={'quote':claim}
                for reported in ('uses','used','has','had','requires','required'):
                    source=f'{subject} {reported} fewer parameters than {other}.'
                    with self.subTest(subject=subject,claim_verb=verb,source_verb=reported):
                        self.assertIsNone(r.comparison_issue(part,subject,[source],'true'))
                        self.assertIsNotNone(r.comparison_issue(part,subject,[source.replace('fewer','more')],'true'))
                        self.assertIsNone(r.comparison_issue(part,subject,[source.replace('fewer','more')],'false'))
                        self.assertIsNotNone(r.comparison_issue(part,subject,['If activated, '+source],'true'))

    def test_existence_zero_plural_counts_and_modality(self):
        for subject,obj in [('collection','records'),('register','certificates')]:
            for count in (0,1,108,17001):
                for verb in ('contains','contained'):
                    source=f'The {subject} {verb} {count:,} {obj}.'
                    positive={'quote':f'The {subject} contains {obj}.'}
                    negative={'quote':f'The {subject} did not contain any {obj}.'}
                    self.assertEqual(r.existence_truth(positive,subject,source),'true' if count else 'false')
                    self.assertEqual(r.existence_truth(negative,subject,source),'false' if count else 'true')
                    self.assertIsNone(r.existence_truth(negative,subject,'If confirmed, '+source))

    def test_numeric_qualification_preserves_real_denials_and_uncertainty(self):
        for number in ('64.25','97.50'):
            claim=f'The model achieved {number}% accuracy.'
            positive=f'The model achieves an accuracy of {number}%'
            for tail in [', however its errors are not evenly distributed.',
                         ', however their errors are not evenly distributed.']:
                text=positive+tail
                rec={'kind':'value','source_quote':text,'left':{'value':number,'unit':'%','quote':number+'%'},'right':{'value':number,'unit':'%','quote':number+'%'}}
                self.assertEqual(n.check_numeric(rec,claim,text,metric='accuracy')['truth'],'true')
            for tail in [' but this accuracy is not established.',
                         ' but this finding was not confirmed.']:
                text=positive+tail;rec['source_quote']=text
                self.assertNotEqual(n.check_numeric(rec,claim,text,metric='accuracy')['truth'],'true')

    def test_typed_reference_rejects_competing_or_nonadjacent_subjects(self):
        for name in ('Juniper model','Spruce model'):
            intro=f'We employ a {name} to annotate the data.'
            result='When tested, the model achieves an accuracy of 87%.'
            self.assertIn(result,r.owned_clauses(name,[intro+' '+result],lambda *args:[]))
            self.assertEqual(r.owned_clauses(name,[intro+' We describe another model. '+result],lambda *args:[]),[])
            self.assertEqual(r.owned_clauses(name,[intro+' We also use another model. '+result],lambda *args:[]),[])

    def test_scope_and_identity_do_not_change_under_renaming(self):
        for owner in ('Juniper-Data','Spruce-Data'):
            for start,end in [('2003','2014'),('1998','2022')]:
                claim=f"{owner} covers the majority of adults' matches from {start} to {end}."
                context=f"A dataset provided by {owner}, which covers the majority of the matches played on the adults' side from {start}-{end}."
                value=r.coverage_range(claim,context)
                self.assertEqual(value[1:3],([start,end],[start,end]))
                self.assertIsNone(r.coverage_range(claim,context.replace("adults'","children's")))
                self.assertIsNone(r.coverage_range(claim,'If available, '+context))

    def test_received_false_supports_blocked_in_shared_guard(self):
        fixture=json.loads((Path(__file__).parent/'fixtures/cellfix20_retired_holdout.json').read_bytes())
        for index in (14,19):
            case=fixture['cases'][index]; result=fixture['predictions'][index]['result']
            part=result['parts'][0]['part']; obs=result['parts'][0]['observations'][0]
            issue=r.relation_issue(part,obs['member'],obs['quotes'],obs['truth'],case['context'],lambda *args:None)
            self.assertIsNotNone(issue)
            raw=next(t['output'] for t in result['trace'] if t['stage']=='part_1')
            with self.assertRaises(ValueError):a.assess_part(raw,part,case['context'])
            from .test_atomic_cellfix16 import accepts
            self.assertFalse(accepts(d.assessment_schema(case['claim'],part,case['context']),json.dumps(raw)))

    def test_comparison_variants_bind_measurement_and_comparator(self):
        for name,other in [('Cedar','Birch'),('Oak','Elm')]:
            for metric in ('parameters','memory','latency'):
                claim=f'{name} uses less {metric} than {other}.'
                part={'quote':claim}
                self.assertIsNone(r.comparison_issue(part,name,[claim],'true'))
                self.assertIsNone(r.comparison_issue(part,name,[claim.replace('less','more')],'false'))
                for text in [claim.replace(metric,'accuracy'),claim.replace(other,'Other'),claim.replace(name,'Other'),claim.replace('uses','may use')]:
                    self.assertIsNotNone(r.comparison_issue(part,name,[text],'true'))
                self.assertIsNone(r.comparison_issue(part,name,[],'unknown'))

    def test_existence_negation_changes_direction_not_gold(self):
        for subject,obj in [('training set','reports'),('archive','documents')]:
            for number in (1,27,125):
                source=f'This {subject} contained {number} {obj}.'
                for negative in (False,True):
                    part={'quote':f'The {subject} '+('did not contain any' if negative else 'contains')+f' {obj}.'}
                    self.assertEqual(r.existence_truth(part,subject,source),'false' if negative else 'true')
                    self.assertIsNone(r.existence_truth(part,subject,source.replace('contained','might contain')))
                    self.assertIsNone(r.existence_truth(part,subject,source.replace(subject,'other collection')))

    def test_argument_coordination_does_not_split_predicates(self):
        for claim in ['Results are identical for Cedar and Birch.',
                      'Items were assigned to two categories: alpha and beta.',
                      'Features were removed before training and testing.',
                      'Entities occur in both the training and testing splits.']:
            self.assertEqual(c.conjunctions(claim),[],claim)
        self.assertEqual(len(c.conjunctions('The device improved accuracy and reduced latency.')),1)
        self.assertEqual(len(c.conjunctions('Before training the device improved and the sensor failed.')),1)
        self.assertEqual(len(c.conjunctions('The corpus was used for development and the model vanished.')),1)
        self.assertFalse(r.unsupported_logic('Trailing public or private labels were removed.'))
        self.assertTrue(r.unsupported_logic('The model improved or failed.'))
        self.assertTrue(r.unsupported_logic('Either labels were removed or scores improved.'))

    def test_quoted_target_and_explicit_relative_clause_only(self):
        part={'scope':{'entity':'Raw Data column'}}
        self.assertTrue(binding.source_targets(part,'The "Raw Data" column was entered by an auditor.'))
        self.assertEqual(binding.source_targets(part,'The "Other Data" column was entered.'),[])
        part={'scope':{'entity':'tested learning strategies'}}
        self.assertEqual(binding.source_targets(part,'All learning strategies we tested did not work well.'),['learning strategies'])
        self.assertEqual(binding.source_targets(part,'Some learning strategies were proposed.'),[])

    def test_numeric_count_does_not_absorb_participles(self):
        self.assertEqual(n.numeric_requirements('9,000 headlines drawn from websites.')[0]['unit'],'headlines')
        self.assertEqual(n.numeric_requirements('13 records published by the group.')[0]['unit'],'records')

    def test_local_accuracy_qualification_not_broad_denial(self):
        for value in ('83.00','91.00'):
            proof=f'The model achieves an accuracy of {value}%, however its errors are not evenly distributed.'
            claim=f'The model achieved {value}% accuracy.'
            rec={'kind':'value','source_quote':proof,'left':{'value':value,'unit':'%','quote':value+'%'},'right':{'value':value,'unit':'%','quote':value+'%'}}
            self.assertEqual(n.check_numeric(rec,claim,proof,metric='accuracy')['truth'],'true')
            denied=proof.replace('however its errors are not evenly distributed','but this accuracy is not established')
            rec['source_quote']=denied
            self.assertNotEqual(n.check_numeric(rec,claim,denied,metric='accuracy')['truth'],'true')

    def test_elliptical_count_binds_own_corpus_not_neighbor(self):
        for count,other in [('9000','9159'),('140','230')]:
            proof=f'Our first corpus consists of {other} headlines; our second corpus, of {count} headlines drawn from websites.'
            claim=f'The second corpus consists of {other} headlines.'
            rec={'kind':'value','source_quote':proof,'left':{'value':other,'unit':'headlines','quote':other+' headlines'},'right':{'value':count,'unit':'headlines','quote':count+' headlines'}}
            self.assertEqual(n.check_numeric(rec,claim,proof,metric='consists of')['truth'],'false')
            rec['right']={'value':other,'unit':'headlines','quote':other+' headlines'}
            self.assertEqual(n.check_numeric(rec,claim,proof,metric='consists of')['truth'],'unknown')

    def test_coverage_endpoints_remain_bound_to_population(self):
        for owner in ('Cedar-Data','Birch-Data'):
            source=f"A dataset provided by {owner}, which covers the majority of the matches played on the seniors' side from 2001-2019 and on the juniors' side from 2008-2019."
            claim=f"The stated {owner} coverage period for juniors' matches starts in 2001."
            record={'kind':'value','source_quote':source,'left':{'value':'2001','unit':'','quote':'2001'},'right':{'value':'2008','unit':'','quote':'2008'}}
            self.assertEqual(n.check_numeric(record,claim,source,metric='starts')['truth'],'false')
            record['right']={'value':'2001','unit':'','quote':'2001'}
            self.assertEqual(n.check_numeric(record,claim,source,metric='starts')['truth'],'unknown')
            self.assertIsNone(r.coverage_range(claim,source.replace(owner,'Other-Data')))

    def test_received_accuracy_ledgers_replay_after_local_binding(self):
        fixture=json.loads((Path(__file__).parent/'fixtures/cellfix20_retired_holdout.json').read_bytes())
        for index,expected in [(6,'support'),(7,'contradict')]:
            case=fixture['cases'][index]; result=fixture['predictions'][index]['result']
            raw=next(t['output'] for t in result['trace'] if t['stage']=='part_1')
            value=a.assess_part(raw,result['parts'][0]['part'],case['context'])
            self.assertEqual(value['assessed_label'],expected)

    def test_explicit_disjointness_not_one_false_member_refutes_some(self):
        claim='Some entities occur in both the training and testing splits.'
        part={'quote':claim,'quantifier':'some','scope':{'entity':'entities','metric':'occur','time':'','condition':''}}
        context='We use training and testing splits. We ensure that entities do not overlap across splits.'
        witness=r.disjoint_population(part,context)
        self.assertIsNotNone(witness)
        self.assertTrue(witness['complete'])
        for bad in ['We use training and testing splits. Entity Cedar occurs only in training.',
                    context.replace('entities do not','some entities do not'),
                    context.replace('do not overlap','might not overlap')]:
            self.assertIsNone(r.disjoint_population(part,bad))


if __name__=='__main__':unittest.main()
