"""Regression from the two rejected Cellfix27 Kaggle assessment traces."""
from copy import deepcopy
import json
from pathlib import Path
import unittest

from .test_atomic_cellfix16 import accepts
from .test_atomic_cellfix22 import a, d
from .test_atomic_cellfix27 import CASES, evidence
from .test_atomic_verifier import run

FIXTURE = Path(__file__).with_name('fixtures') / 'cellfix27_duplicate_citations.json'
TRACES = {r['example_id'].rsplit(':', 1)[-1]: r
          for r in json.loads(FIXTURE.read_bytes())['cases']}


def inputs(case_id):
    case = CASES[case_id]
    claim, context = case['claim'], case['context']
    plan = TRACES[case_id]['decomposition']
    part, = a.normalize_decomposition(plan, claim)['parts']
    expected, _ = evidence.source_ledger(part, context)
    return case, plan, part, expected


class Cellfix28Tests(unittest.TestCase):
    def test_actual_duplicate_citations_fail_in_decoder_and_validator(self):
        for case_id, attempts in [('014', (0, 1)), ('019', (0,))]:
            case, _, part, expected = inputs(case_id)
            claim, context = case['claim'], case['context']
            schema = d.assessment_schema(claim, part, context)
            self.assertTrue(accepts(schema, json.dumps(expected)))
            for attempt in attempts:
                with self.subTest(case=case_id, attempt=attempt):
                    raw = TRACES[case_id]['assessment_attempts'][attempt]
                    self.assertFalse(accepts(schema, json.dumps(raw)))
                    with self.assertRaisesRegex(ValueError, 'decisive_witness_missing_or_unknown'):
                        a.assess_part(raw, part, context)

    def test_actual_reordered_019_is_valid_and_keeps_raw_quote_order(self):
        case, plan, part, expected = inputs('019')
        raw = TRACES['019']['assessment_attempts'][1]
        self.assertEqual(raw['coverage']['quotes'], expected['coverage']['quotes'][::-1])
        self.assertEqual(raw['observations'][0]['quotes'], expected['observations'][0]['quotes'][::-1])
        result, backend = run([plan, raw], case['claim'], case['context'])
        self.assertEqual(result['assessed_label'], 'support')
        self.assertEqual(len(backend.calls), 2)
        self.assertEqual(result['parts'][0]['coverage']['quotes'], raw['coverage']['quotes'])
        self.assertEqual(result['parts'][0]['observations'][0]['quotes'], raw['observations'][0]['quotes'])

        duplicate = deepcopy(expected)
        duplicate['coverage']['quotes'][1] = duplicate['coverage']['quotes'][0]
        with self.assertRaisesRegex(ValueError, 'decisive_witness_missing_or_unknown'):
            a.assess_part(duplicate, part, case['context'])

    def test_full_required_citations_reach_expected_decisions(self):
        for case_id in TRACES:
            with self.subTest(case=case_id):
                case, plan, part, expected = inputs(case_id)
                claim, context = case['claim'], case['context']
                schema = d.assessment_schema(claim, part, context)
                for indent in (None, 2):
                    self.assertTrue(accepts(schema, json.dumps(expected, ensure_ascii=False, indent=indent)))
                for quotes in (expected['observations'][0]['quotes'][:-1],
                               ['Fabricated sentence.', *expected['observations'][0]['quotes'][1:]]):
                    changed = deepcopy(expected)
                    changed['observations'][0]['quotes'] = quotes
                    self.assertFalse(accepts(schema, json.dumps(changed)))
                    with self.assertRaisesRegex(ValueError, 'decisive_witness_missing_or_unknown'):
                        a.assess_part(changed, part, context)
                result, _ = run([plan, expected], claim, context)
                self.assertEqual(result['status'], 'completed')
                self.assertEqual(result['assessed_label'], case['proposed_gold'])

    def test_literal_array_handles_escaped_citations(self):
        value = ['A "quoted" value and a \\ separator.', 'Unicode citation – with a newline\n.']
        payload = {'quotes': value}
        schema = evidence.literal_schema(payload)
        self.assertTrue(accepts(schema, json.dumps(payload, ensure_ascii=False, indent=2)))
        self.assertFalse(accepts(schema, json.dumps({'quotes': [value[0], value[0]]}, ensure_ascii=False)))
