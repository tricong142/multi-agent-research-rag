"""Regression cases for predicate quantifiers, NEI details and failed-schema reports."""
from contextlib import contextmanager, redirect_stdout
from io import StringIO
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import atomic_workflow_cellfix21 as workflow
from .test_atomic_cellfix16 import accepts
from .test_atomic_cellfix22 import ROOT, a, cases, d, decisions, ledger, part
from .test_atomic_verifier import assessment, run


def plan(p):
    return {'parts': [{k: p[k] for k in ('quote', 'quantifier', 'scope')}], 'unresolved': []}


class Cellfix24Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.retired = cases('retired-holdout-v4')
        cls.dev = cases('dev30')

    def test_test_set_quantifier_belongs_to_the_predicate(self):
        case = self.retired[9]
        claim, context = case['claim'], case['context']
        metric = 'was used as a test set for all reported experiments'
        p = part(claim, 'Mboshi5K corpus', metric)
        parsed = a.normalize_decomposition(plan(p), claim)['parts'][0]
        self.assertEqual(parsed['quantifier'], 'atomic')
        self.assertTrue(accepts(d.decomposition_schema(claim), json.dumps(plan(p))))
        witness = decisions.decision_evidence(parsed, context)
        result, _ = run([plan(p), ledger(witness)], claim, context)
        self.assertEqual(result['assessed_label'], 'support')
        self.assertIn('all the experiments reported here', result['parts'][0]['observations'][0]['quotes'][0])

    def test_explicit_subject_quantifier_and_modifier_are_still_required(self):
        claim = 'All audited corpora were used as a test set for all reported experiments.'
        metric = 'were used as a test set for all reported experiments'
        good = plan(part(claim, 'audited corpora', metric, 'all'))
        bad = plan(part(claim, 'corpora', metric, 'all'))
        schema = d.decomposition_schema(claim)
        self.assertTrue(accepts(schema, json.dumps(good)))
        self.assertFalse(accepts(schema, json.dumps(bad)))
        a.normalize_decomposition(good, claim)
        with self.assertRaisesRegex(ValueError, 'scope_role_mismatch|quantified_population_required'):
            a.normalize_decomposition(bad, claim)

    def test_unbound_annotator_group_requests_a_count(self):
        case = self.dev[23]
        p = part(case['claim'], 'human annotators', "produced the study's name-variant annotations")
        raw = assessment([], scope='unknown', missing=['target_binding_unresolved'])
        result = a.assess_part(raw, p, case['context'])
        self.assertEqual(result['assessed_label'], 'not_enough_info')
        self.assertEqual(result['model_missing_information'], ['target_binding_unresolved'])
        self.assertEqual(result['observations'], [])
        self.assertEqual(len(result['missing_information']), 2)
        self.assertIn('count for the claimed group', result['missing_information'][1])
        self.assertIn('human annotators', result['missing_information'][1])

    def test_unbound_study_still_requests_experimental_evidence(self):
        case = self.dev[26]
        p = part(case['claim'], 'The study', case['claim'].removeprefix('The study ').rstrip('.'))
        raw = assessment([], scope='unknown', missing=['target_binding_unresolved'])
        result = a.assess_part(raw, p, case['context'])
        self.assertEqual(result['assessed_label'], 'not_enough_info')
        self.assertEqual(result['model_missing_information'], ['target_binding_unresolved'])
        self.assertEqual(len(result['missing_information']), 2)
        self.assertIn('Experimental evidence', result['missing_information'][1])
        self.assertIn('semantic masking', result['missing_information'][1])

    def test_validation_writes_metrics_and_diagnostics_for_schema_failure(self):
        original = self.retired[9]
        case = {'example_id': original['id'], 'claim': original['claim'], 'context': original['context'],
                'label': original['proposed_gold'], 'dataset_group': original['group_id']}
        frozen = workflow.read(workflow.r.CRITERIA)
        baseline = workflow.read(workflow.r.CRITERIA.with_name(frozen['baseline_file']))
        criteria = {**frozen, 'policy': a.POLICY, 'structured_decoder': d.DECODER,
                    'dataset_groups': {case['dataset_group']: 1}, 'cases_per_backend': 1,
                    'min_correct_labels_recognized': 1}

        class Backend:
            on_generation = None

            @contextmanager
            def generation_deadline(self, deadline):
                yield True

            def generate_json(self, messages, *, max_new_tokens):
                try:
                    d.schema_for(messages)
                except ValueError:
                    self.on_generation(dict(raw_output=None, json_valid=False, parse_error_type='ValueError',
                                            failure_phase='schema', usage_complete=False, generated_tokens=None,
                                            prompt_tokens=20, max_new_tokens=max_new_tokens))
                    raise

        @contextmanager
        def loader(kind, settings):
            yield Backend(), {**baseline['model_metadata'], 'structured_decoder': criteria['structured_decoder'],
                              'max_new_tokens': criteria['max_new_tokens']}

        with (tempfile.TemporaryDirectory(dir=ROOT.parent) as temp,
              patch.object(workflow, 'configuration', return_value=({}, criteria, [case])),
              patch.object(workflow, 'require_full39', return_value={}),
              patch.object(workflow.r, 'load_frozen', return_value=(criteria, [case], None, None, None, baseline, None)),
              patch.object(d, 'schema_for', side_effect=ValueError('unsupported_scope_structure')),
              redirect_stdout(StringIO())):
            output = Path(temp) / 'output'
            binding_dir = ROOT / 'validation/cellfix21-retired-holdout-v4'
            summary = workflow.run_validation(output, None, None, binding_dir, loader)
            self.assertEqual(summary['status'], 'automated_gates_failed')
            metrics = workflow.read(output / 'metrics.json')
            self.assertEqual(metrics['correct_labels'], 0)
            self.assertEqual(metrics['runtime_failed_rows'], 1)
            self.assertFalse(metrics['checks']['structured_decoding_trace_complete'])
            self.assertFalse(metrics['usage_complete'])
            self.assertIsNone(metrics['generated_tokens'])
            self.assertTrue((output / 'classification.json').is_file())
            self.assertTrue((output / 'HUMAN_REVIEW.html').is_file())
            progress = workflow.rows(output / 'progress.jsonl')
            error = next(row for row in progress if row['phase'] == 'schema_replay' and row['state'] == 'failed')
            self.assertEqual(error['example_id'], case['example_id'])
            self.assertEqual(error['error_message'], 'unsupported_scope_structure')
