
from copy import deepcopy
import json, unittest
from research_rag.tests import test_atomic_assessment_v8 as h
from research_rag.tests.test_atomic_verifier import (
    a, part, assessment, observation, numeric, operand
)

class Cellfix2Tests(unittest.TestCase):
    setUp = h.AssessmentTokenFilterTests.setUp
    accepts = h.AssessmentTokenFilterTests.accepts
    ordered = h.AssessmentTokenFilterTests.ordered

    def request(self, claim, p, proof):
        return [
            {'role':'system', 'content':a.ASSESS_PROMPT},
            {'role':'user', 'content':json.dumps({
                'claim':claim, 'part':p, 'context':proof
            })},
        ]

    def fixture(self):
        claim, proof = 'Capacity was 9 liters.', 'Capacity was 9 liters.'
        p = part(claim, metric='Capacity')
        raw = assessment([observation(
            'Capacity', 'true', proof,
            numeric('value', proof, operand('9','liters'), operand('9','liters'))
        )])
        return raw, self.request(claim, p, proof)

    def test_true_numeric_requires_quote_and_check(self):
        raw, request = self.fixture()
        self.assertTrue(self.accepts(self.ordered(raw), request))
        raw['observations'][0]['quotes'] = []
        self.assertFalse(self.accepts(self.ordered(raw), request))
        raw, request = self.fixture()
        raw['observations'][0]['numeric'] = None
        self.assertFalse(self.accepts(self.ordered(raw), request))

    def test_atomic_population_flag_is_false_not_empty_true(self):
        raw, request = self.fixture()
        raw['coverage']['complete'] = True
        self.assertFalse(self.accepts(self.ordered(raw), request))
        raw['coverage']['complete'] = False
        self.assertTrue(self.accepts(self.ordered(raw), request))

    def test_missing_numeric_source_allows_unknown_not_false(self):
        claim, proof = 'Capacity was 9 liters.', 'Capacity was not reported.'
        p = part(claim, metric='Capacity')
        raw = assessment(
            [observation('Capacity', 'unknown', proof)],
            missing=['measurement_unreported']
        )
        request = self.request(claim, p, proof)
        self.assertTrue(self.accepts(self.ordered(raw), request))
        raw['observations'][0]['truth'] = 'false'
        self.assertFalse(self.accepts(self.ordered(raw), request))

    def test_qualitative_false_requires_evidence(self):
        claim = 'The survey used paper forms.'
        proof = 'The survey did not use paper forms.'
        p = part(claim, metric='used paper forms')
        raw = assessment([observation('survey', 'false', proof)])
        request = self.request(claim, p, proof)
        self.assertTrue(self.accepts(self.ordered(raw), request))
        self.assertEqual(
            a.assess_part(raw, p, proof)['assessed_label'], 'contradict'
        )
        raw['observations'][0]['quotes'] = []
        self.assertFalse(self.accepts(self.ordered(raw), request))

    def test_quantified_complete_needs_nonempty_population(self):
        claim, proof = 'All pumps remained operable.', 'One pump failed.'
        p = part(claim, quantifier='all', metric='operable')
        p['scope']['entity'] = 'pumps'
        raw = assessment([observation('pump', 'false', proof)])
        request = self.request(claim, p, proof)
        self.assertTrue(self.accepts(self.ordered(raw), request))
        raw['coverage']['complete'] = True
        self.assertFalse(self.accepts(self.ordered(raw), request))
        raw['coverage'].update(members=['pump'], quotes=[proof])
        self.assertFalse(self.accepts(self.ordered(raw), request))
        with self.assertRaisesRegex(ValueError, 'population_closure_unproven'):
            a.assess_part(raw, p, proof)
