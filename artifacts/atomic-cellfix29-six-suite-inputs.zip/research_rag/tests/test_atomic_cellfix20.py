"""Semantic regression controls, including received traces; no inference claims."""
from copy import deepcopy
import importlib
import json
from pathlib import Path
import unittest

from .test_atomic_cellfix16 import accepts

a = importlib.import_module('04_factchecker.inference.atomic_verifier')
d = importlib.import_module('04_factchecker.inference.atomic_decoding')
rules = importlib.import_module('04_factchecker.inference.cellfix20_rules')
runtime = importlib.import_module('04_factchecker.inference.cellfix14_runtime')


def canonical_plan(raw):
    raw = deepcopy(raw)
    for part in raw['parts']:
        span = rules.relational_predicate(part['quote'])
        if span:
            part['scope']['metric'] = span
    return raw


def received():
    return json.loads((Path(__file__).parent/'fixtures/cellfix19_semantic_failures.json').read_bytes())


def ledger(member, truth, quote=None):
    return dict(scope_match='matched',coverage=dict(complete=False,members=[],quotes=[]),
        observations=[dict(member=member,truth=truth,quotes=[quote] if quote else [],
                           explanation='Predicate evidence recorded.',numeric=None)],
        missing_information=[],explanation='Assess the recorded evidence ledger.')


def example(model='Cedar model', comparator='Birch encoder', dataset='Maple dataset', direction='better'):
    claim=f'The {model} performs {direction} than the {comparator} on the {dataset}.'
    part=dict(quote=claim,quantifier='atomic',scope=dict(entity=model,metric=rules.relational_predicate(claim),time='',condition=f'on the {dataset}'))
    context=f'The {model} performs {direction} than the {comparator} on the {dataset}.'
    return claim,part,context


def token_paths20():
    paths=[]
    for row in received():
        case,result=row['case'],row['result'];claim=case['claim'];context=case['context']
        old=result['trace'][0]['output'];fixed=canonical_plan(old)
        paths.extend([(case['example_id']+'_old_scope_blocked',claim,None,None,old,False),
                      (case['example_id']+'_full_scope_reachable',claim,None,None,fixed,True)])
        part=a.normalize_decomposition(fixed,claim)['parts'][0]
        raw=deepcopy(next(t['output'] for t in result['trace'] if t['stage']=='part_1' and t.get('valid')))
        if case['example_id'].endswith('025'):
            paths.append(('cf20_received_unbound_comparison',claim,part,context,deepcopy(raw),False))
            proof=next(q for q in sorted(d.evidence_passages(context),key=len)
                       if rules.comparative_proofs(part,q))
            raw=ledger('our model','true',proof)
        paths.append((case['example_id']+'_valid_assessment',claim,part,context,raw,True))
    return paths


class Cellfix20Tests(unittest.TestCase):
    def test_received_scopes_and_quotes_are_blocked_with_reachable_repairs(self):
        for name,claim,part,context,raw,expected in token_paths20():
            with self.subTest(name=name),runtime.decode_request(None):
                schema=d.decomposition_schema(claim) if part is None else d.assessment_schema(claim,part,context)
                self.assertEqual(accepts(schema,json.dumps(raw)),expected)
                check=(lambda:a.normalize_decomposition(raw,claim)) if part is None else (lambda:a.assess_part(raw,part,context))
                if expected:
                    value=check()
                    if part is not None:
                        self.assertIn(claim,value['observations'][0]['explanation'])
                        if claim==received()[2]['case']['claim']:
                            self.assertEqual(value['missing_reason'],'experimental_evidence_unestablished')
                            self.assertIn('Experimental evidence',value['missing_information'][0])
                            self.assertIn(claim,value['missing_information'][0])
                else:
                    with self.assertRaises(ValueError):check()

    def test_requirement_is_not_replaced_by_purpose(self):
        for subject,object_ in [('Cedar procedure','modified objective'),('Birch algorithm','external resource')]:
            for verb in ['required','requires','did not require','never required']:
                claim=f'The {subject} {verb} a {object_} to achieve its score.'
                span=rules.relational_predicate(claim)
                self.assertEqual(span,f'{verb} a {object_} to achieve its score')
                self.assertEqual(rules.metric_requirement(dict(metric='achieve its score'),claim,lambda *_:None),span)
                self.assertIsNone(rules.metric_requirement(dict(metric=span),claim,lambda *_:'wrong'))

    def test_comparisons_bind_target_comparator_direction_and_condition(self):
        for model,comparator,dataset in [('Cedar model','Birch encoder','Maple dataset'),('Atlas parser','Pine baseline','Oak corpus')]:
            claim,part,context=example(model,comparator,dataset)
            raw=ledger(model,'true',context)
            with self.subTest(model=model),runtime.decode_request(None):
                self.assertEqual(a.assess_part(raw,part,context)['assessed_label'],'support')
                self.assertTrue(accepts(d.assessment_schema(claim,part,context),json.dumps(raw)))
                for bad in [context.replace(comparator,'Other comparator'),context.replace(dataset,'Other dataset'),
                            context.replace(model,'Other model'),context.replace('performs','might perform'),
                            context.replace('on the','not on the'), 'If activated, '+context,
                            context.replace('better','worse')]:
                    modified=ledger(model,'true',bad)
                    self.assertIsNotNone(rules.relation_issue(part,model,[bad],'true',bad,lambda *_:None))
                    with self.assertRaises(ValueError):a.assess_part(modified,part,bad)
                    self.assertFalse(accepts(d.assessment_schema(claim,part,bad),json.dumps(modified)))

    def test_shared_comparator_does_not_cross_subject_or_condition(self):
        claim,part,_=example()
        source='The Cedar model is competitive, which achieves a comparable result with the Birch encoder on the Oak dataset and a better result on the Maple dataset.'
        self.assertTrue(rules.comparative_proofs(part,source))
        for text in [source.replace('and a better','and the Pine model achieves a better'),
                     source.replace('and a better result on the Maple dataset','and a better result on the Elm dataset'),
                     source.replace(' and ','. It has '),source.replace('achieves','might achieve')]:
            self.assertEqual(rules.comparative_proofs(part,text),[])

    def test_negation_does_not_invert_or_invent_strict_comparisons(self):
        _,part,context=example()
        negated=context.replace('performs better','is not better')
        self.assertEqual({r['truth'] for r in rules.comparative_proofs(part,negated)},{'false'})
        not_worse=context.replace('performs better','is not worse')
        self.assertEqual(rules.comparative_proofs(part,not_worse),[])
        part=deepcopy(part);part['quote']=part['quote'].replace('performs better','does not perform better')
        self.assertEqual({r['truth'] for r in rules.comparative_proofs(part,context)},{'false'})

    def test_conflicting_results_are_not_forced_into_one_truth(self):
        _,part,context=example()
        context+=' '+context.replace('better','worse')
        self.assertIsNotNone(rules.relation_issue(part,'Cedar model',[context],'true',context,lambda *_:None))
        self.assertIsNone(rules.relation_issue(part,'Cedar model',[],'unknown',context,lambda *_:None))

    def test_same_subject_ellipsis_retains_comparator_and_condition(self):
        _,part,_=example()
        source='The Cedar model obtains a similar performance on the Oak dataset, but is still worse than the Birch encoder on the Maple dataset.'
        self.assertEqual({r['truth'] for r in rules.comparative_proofs(part,source)},{'false'})
        self.assertEqual(rules.comparative_proofs(part,source.replace('but is','but the Elm model is')),[])

    def test_tentative_explanation_never_becomes_empirical_proof(self):
        claim='The study experimentally established that masking is more suitable on noisy input because the features are unreliable.'
        part=dict(quote=claim,quantifier='atomic',scope=dict(entity='masking',metric=rules.relational_predicate(claim),time='',condition=''))
        for text in ['Masking might be more suitable on noisy input because the features are unreliable.',
                     'The study might have experimentally established that masking is more suitable on noisy input because the features are unreliable.',
                     'The study experimentally established that a different technique is more suitable on noisy input because the features are unreliable.']:
            self.assertIsNotNone(rules.relation_issue(part,'masking',[text],'true',text,lambda *_:None))
            self.assertIsNone(rules.relation_issue(part,'masking',[],'unknown',text,lambda *_:None))
        self.assertIsNone(rules.relation_issue(part,'masking',[claim],'true',claim,lambda *_:None))

    def test_reporting_preserves_negation_and_quantifier_without_reinterpretation(self):
        for quote,q in [('None of the sensors leaked.','none'),('The model did not require a modified objective.','atomic')]:
            part=dict(quote=quote,quantifier=q)
            for truth in ['true','false','unknown']:
                text=rules.observation_explanation(dict(member='target',truth=truth),part)
                self.assertIn(quote,text);self.assertIn('truth='+truth,text)
                self.assertIn(q.upper(),text)


if __name__=='__main__':unittest.main()
