"""Cell 7 and retired-v4 witnesses plus lexical and scope variants."""
import importlib
import json
from pathlib import Path
import unittest

from .test_atomic_verifier import assessment, observation
from .test_atomic_smoke_cellfix3 import scoped

a = importlib.import_module('04_factchecker.inference.atomic_verifier')
d = importlib.import_module('04_factchecker.inference.atomic_decoding')
decisions = importlib.import_module('04_factchecker.inference.assessment_decisions')
rules = importlib.import_module('04_factchecker.inference.assessment_rules')
members = importlib.import_module('04_factchecker.inference.assessment_members')
evidence = importlib.import_module('04_factchecker.inference.assessment_evidence')
ROOT = Path(__file__).resolve().parents[2]


def cases(suite):
    path = ROOT / f'validation/cellfix21-{suite}/original/cases.jsonl'
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]


def part(claim, entity, metric, quantifier='atomic', time='', condition=''):
    return scoped(claim, entity, metric, quantifier=quantifier, time=time, condition=condition)


def model_part(p):
    return {k: p[k] for k in ('quote', 'scope', 'quantifier')}


def ledger(witness):
    name, quote = witness['members'][0], witness['quotes'][0]
    raw = assessment([observation(name, witness['truth'], quote)])
    if witness.get('complete'):
        raw['coverage'] = dict(complete=True, members=[name], quotes=[quote])
    return raw


class Cellfix22Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dev = cases('dev30')
        cls.retired = cases('retired-holdout-v4')

    def check_witness(self, p, context, label):
        witness = decisions.decision_evidence(p, context)
        self.assertIsNotNone(witness)
        raw = ledger(witness)
        self.assertEqual(a.assess_part(raw, p, context)['assessed_label'], label)
        d.assessment_schema(p['quote'], p, context)
        return witness, raw

    def test_removal_polarity_and_phase_binding(self):
        case = self.retired[22]
        for negative in (False, True):
            claim = case['claim'].replace('were retained', 'were not retained') if negative else case['claim']
            p = part(claim, 'Trailing sarcasm or emotion hashtags',
                     'were not retained in the data' if negative else 'were retained in the data',
                     time='during training and testing')
            witness, raw = self.check_witness(p, case['context'], 'support' if negative else 'contradict')
            raw['observations'][0]['truth'] = 'false' if negative else 'true'
            with self.assertRaisesRegex(ValueError, 'observation_polarity_mismatch|decisive_witness_missing_or_unknown'):
                a.assess_part(raw, p, case['context'])
        claim = 'Demo tags were kept in the corpus during validation and testing.'
        p = part(claim, 'Demo tags', 'were kept in the corpus', time='during validation and testing')
        self.check_witness(p, 'Demo tags were excluded from the corpus before testing and validation.', 'contradict')
        for source in ('Demo tags were not excluded from the corpus before validation and testing.',
                       'Demo tags were excluded from the corpus after validation and testing.',
                       'Demo tags were excluded from the corpus before validation.',
                       'Other tags were excluded from the corpus before validation and testing.',
                       'Demo tags were excluded from the archive before validation and testing.',
                       'Demo tags were excluded from the corpus before validation and testing. They were restored.'):
            with self.subTest(source=source):
                self.assertIsNone(decisions.decision_evidence(p, source))
        conditioned = claim.replace('testing.', 'testing under cold conditions.')
        p = part(conditioned, 'Demo tags', 'were kept in the corpus', time='during validation and testing',
                 condition='under cold conditions')
        source = 'Demo tags were excluded from the corpus before validation and testing under cold conditions.'
        self.check_witness(p, source, 'contradict')
        self.assertIsNone(decisions.decision_evidence(p, source.replace('cold', 'warm')))

    def test_unknown_entity_is_not_missing_overlap_status(self):
        case = self.retired[24]
        p = part(case['claim'], 'Entities', 'do not overlap')
        self.check_witness(p, case['context'], 'support')
        self.assertFalse(rules.missing_result(p, 'Unknown entities in the wild do not overlap across splits'))
        self.assertTrue(rules.missing_result(p, 'The overlap status is unknown'))
        self.assertFalse(rules.missing_result(p, 'Accuracy was not measured'))
        case = self.retired[25]
        p = part(case['claim'], 'entities', 'occur in both', quantifier='some')
        self.check_witness(p, case['context'], 'contradict')

    def test_coordination_has_one_complete_predicate_per_part(self):
        claim = self.retired[12]['claim']
        p = part(claim, 'char-lstm model and the word model', 'identical LAS results')
        a.normalize_decomposition(dict(parts=[model_part(p)], unresolved=[]), claim)
        self.check_witness(p, self.retired[12]['context'], 'support')
        d.decomposition_schema(claim)
        fragments = [part(fragment, 'word model', 'identical LAS results') for fragment in
                     ('The char-lstm model', 'and the word model', 'have identical LAS results', 'for Hindi and Urdu.')]
        with self.assertRaisesRegex(ValueError, 'incomplete_predicate_span'):
            a.normalize_decomposition(dict(parts=[model_part(p) for p in fragments], unresolved=[]), claim)
        claim = 'Model Finch achieved 0.9 accuracy and improved recall.'
        first = part('Model Finch achieved 0.9 accuracy', 'Model Finch', 'accuracy')
        second = part('and improved recall.', 'Model Finch', 'recall')
        a.normalize_decomposition(dict(parts=[model_part(first), model_part(second)], unresolved=[]), claim)
        d.decomposition_schema(claim)

    def test_population_identity_and_closure_are_checked_independently(self):
        case = self.dev[8]
        p = part(case['claim'], 'sentence', 'simplified', quantifier='all')
        for truth in ('true', 'false', 'unknown'):
            for member in ('Sentence', 'BIBREF9'):
                self.assertEqual(members.member_identity_issue(p, member, truth, case['context']),
                                 'observation_member_is_not_entity')
        source = 'The parser was benchmarked in July. Results on packets were not reported.'
        p = part('Every packet was accepted.', 'packet', 'accepted', quantifier='all')
        raw = assessment([observation('packets', 'unknown', '')])
        raw['observations'][0]['quotes'] = []
        raw['coverage'] = dict(complete=True, members=['packets'], quotes=[source])
        with self.assertRaisesRegex(ValueError, 'population_closure_unproven'):
            a.assess_part(raw, p, source)
        case = self.retired[21]
        p = part(case['claim'], 'trailing sarcasm or emotion hashtags', 'were removed from the data',
                 quantifier='all', time='before training and testing')
        witness, raw = self.check_witness(p, case['context'], 'support')
        raw['coverage']['quotes'] = [case['context'].split('.')[0]]
        with self.assertRaisesRegex(ValueError, 'population_closure_unproven'):
            a.assess_part(raw, p, case['context'])
        case = self.retired[28]
        p = part(case['claim'], 'tested active learning strategies', 'worked well with the CNN', quantifier='all')
        self.assertIsNotNone(members.member_identity_issue(p, 'tested', 'false', case['context']))
        self.check_witness(p, case['context'], 'contradict')
        case = self.retired[9]
        p = part(case['claim'], 'Mboshi5K corpus', 'was used as a test set for all reported experiments')
        self.check_witness(p, case['context'], 'support')
        raw = assessment([observation('BIBREF13', 'true', case['context'].split('.')[0])])
        with self.assertRaisesRegex(ValueError, 'observation_target_mismatch'):
            a.assess_part(raw, p, case['context'])

    def test_classification_count_and_names_are_bound_to_the_object(self):
        for index, wanted in ((0, 'true'), (1, 'false')):
            case = self.retired[index]
            p = part(case['claim'], 'occupations', 'classified into')
            witness = decisions.decision_evidence(p, case['context'])
            self.assertEqual(witness['truth'], wanted)
            record, truth = decisions.numeric_choices(p, case['context'])[0][0]
            raw = assessment([observation('occupations', truth, record['source_quote'], record)])
            self.assertEqual(a.assess_part(raw, p, case['context'])['assessed_label'],
                             'support' if index == 0 else 'contradict')
            with self.assertRaisesRegex(ValueError, 'decisive_witness_missing_or_unknown'):
                a.assess_part(assessment([]), p, case['context'])
            d.assessment_schema(case['claim'], p, case['context'])
        claim = 'The records were grouped into four groups: amber, blue, gray and ivory.'
        p = part(claim, 'records', 'grouped into')
        for source in ('We grouped the notes into 4 groups: amber, blue, gray and ivory.',
                       'We grouped the records into 4 groups: amber, blue, gray and black.',
                       'We might have grouped the records into 4 groups.'):
            self.assertIsNone(decisions.decision_evidence(p, source))
        source = 'The records were grouped into 4 groups: amber, blue, gray and ivory.'
        self.assertEqual(decisions.decision_evidence(p, source)['truth'], 'true')

    def test_numeric_count_object_ends_before_the_predicate(self):
        variants = [(self.dev[23]['claim'], 'human annotators'),
                    (self.retired[2]['claim'], 'independent human annotators'),
                    ("Four expert reviewers labeled Orion's examples.", 'expert reviewers'),
                    ("Six domain experts review our transcripts.", 'domain experts'),
                    ('Five medical specialists documented outcomes.', 'medical specialists'),
                    ('Eight new research assistants.', 'new research assistants')]
        for text, unit in variants:
            with self.subTest(text=text):
                self.assertEqual(a.numeric_requirements(text)[0]['unit'], unit)

    def test_scope_requires_predicate_agent_actor_and_complete_time(self):
        dev, retired = self.dev, self.retired
        cases = [
            (dev[14]['claim'], 'produced each prediction in 20 milliseconds', 'model',
             'produced each prediction in 20 milliseconds', '', 'condition', 'produced'),
            (dev[28]['claim'], dev[28]['claim'], 'PDTB sections 0-1', 'were the test set used in the study', '', 'metric', 'used in the study'),
            (retired[4]['claim'], retired[4]['claim'], "stated Tennis-Data coverage period for women's matches",
             'starts in 2000', '', 'condition', 'starts in 2000'),
            (retired[15]['claim'], retired[15]['claim'], 'satirical corpus', 'consists of 9159 headlines published by The Onion', '', 'entity', 'corpus'),
            (retired[21]['claim'], retired[21]['claim'], 'trailing sarcasm or emotion hashtags',
             'were removed from the data', 'before training and testing', 'time', 'before training'),
            (retired[22]['claim'], retired[22]['claim'], 'Trailing sarcasm or emotion hashtags',
             'were retained in the data', 'during training and testing', 'time', 'during training'),
            (retired[23]['claim'], retired[23]['claim'], 'Removing trailing hashtags', 'test accuracy', '', 'entity', 'trailing hashtags'),
        ]
        for claim, quote, entity, metric, time, field, wrong in cases:
            with self.subTest(claim=claim):
                scope = dict(entity=entity, metric=metric, time=time, condition='')
                self.assertEqual(a.scope_issues(scope, claim, quote), [])
                self.assertIn(field, {row['field'] for row in a.scope_issues({**scope, field: wrong}, claim, quote)})
                d.decomposition_schema(claim)

    def test_scope_with_publisher_keeps_numeric_evidence(self):
        case = self.retired[15]
        p = part(case['claim'], 'satirical corpus', 'consists of 9159 headlines published by The Onion')
        choices = decisions.numeric_choices(p, case['context'])[0]
        self.assertTrue(choices)
        record, truth = choices[0]
        raw = assessment([observation('satirical corpus', truth, record['source_quote'], record)])
        self.assertEqual(a.assess_part(raw, p, case['context'])['assessed_label'], 'support')
        self.assertFalse(decisions.numeric_choices(p, case['context'].replace('The Onion', 'The Gazette'))[0])

    def test_coverage_start_keeps_source_owner_and_group(self):
        case = self.retired[4]
        p = part(case['claim'], "stated Tennis-Data coverage period for women's matches", 'starts in 2000')
        record, truth = decisions.numeric_choices(p, case['context'])[0][0]
        self.assertEqual(record['right']['value'], '2007')
        raw = assessment([observation('Tennis-Data', truth, record['source_quote'], record)])
        self.assertEqual(a.assess_part(raw, p, case['context'])['assessed_label'], 'contradict')

    def test_column_name_and_agent_must_survive_the_same_quote(self):
        case = self.retired[18]
        p = part(case['claim'], 'Raw Text column', 'was entered by a physician')
        witness, raw = self.check_witness(p, case['context'], 'support')
        self.assertEqual(witness['members'], ['"Raw Text" column'])
        from .test_atomic_cellfix16 import accepts
        from .test_atomic_assessment_cellfix10 import canonical
        from .test_atomic_assessment_v8 import AssessmentTokenFilterTests
        schema = d.assessment_schema(p['quote'], p, case['context'])
        ordered = AssessmentTokenFilterTests().ordered
        self.assertTrue(accepts(schema, ordered(canonical(raw, p, case['context']))))
        truncated = canonical(raw, p, case['context'])
        truncated['observations'][0].update(member='Raw Text', quotes=['Each CSV file contains a '])
        self.assertFalse(accepts(schema, ordered(truncated)))
        raw['observations'][0]['quotes'] = ['"Raw Text" column']
        with self.assertRaisesRegex(ValueError, 'observation_predicate_not_grounded'):
            a.assess_part(raw, p, case['context'])
        claim = 'The Review Note column was annotated by an auditor.'
        p = part(claim, 'Review Note column', 'was annotated by an auditor')
        context = 'Each file contains a “Review Note” column annotated by an auditor, and a “Summary” column annotated by a clerk.'
        self.check_witness(p, context, 'support')
        self.assertIsNone(decisions.decision_evidence(p, context.replace('an auditor', 'a clerk')))
