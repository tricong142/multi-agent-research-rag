"""Replay the Cellfix28 Cell 9 review findings through the verifier."""
import json
from importlib import import_module
from pathlib import Path
import unittest

from .test_atomic_cellfix16 import accepts
from .test_atomic_cellfix22 import a, d
from .test_atomic_cellfix27 import evidence
from .test_atomic_verifier import run


FIXTURE = Path(__file__).with_name('fixtures') / 'cellfix28_cell9_semantic_review.json'
reports = import_module('04_factchecker.inference.cellfix27_reports')
CASES = {row['example_id'].rsplit(':', 1)[-1]: row for row in json.loads(FIXTURE.read_bytes())['cases']}
MEASUREMENTS = {
    '008': 'The reported BLEU score for the translation system trained with BPE units.',
    '020': 'The F1 score of the claimed speech-act classifier on Request tweets.',
    '021': "The proposed NER approach's average recall on the Ritter dataset.",
    '027': 'The proportion of numeric-range cases the rule-based model handled correctly.',
}
TIE_RULE = 'If there are multiple pattern matches with the same length, the one with a higher priority will be chosen for the NSW.'


def replies_for(key):
    case = CASES[key]
    claim, context = case['claim'], case['context']
    plan, assessment, *_ = case['recorded_replies']
    if key in ('012', '027'):
        role = evidence.predicate_roles(claim)
        plan = {'parts': [{'quote': claim, 'quantifier': 'atomic', 'scope': {
            'entity': role['entity'], 'metric': role['metric'], 'time': '', 'condition': '',
        }}], 'unresolved': []}
    part, = a.normalize_decomposition(plan, claim)['parts']
    if key in ('009', '012'):
        assessment, _ = evidence.source_ledger(part, context)
    if key in MEASUREMENTS:
        assessment = {**assessment, 'missing_information': ['measurement_unreported']}
    return plan, part, assessment


class Cellfix29Tests(unittest.TestCase):
    def test_ten_review_cases(self):
        for key, case in CASES.items():
            with self.subTest(case=key):
                claim, context = case['claim'], case['context']
                plan, part, assessment = replies_for(key)
                self.assertTrue(accepts(d.decomposition_schema(claim), json.dumps(plan)))
                self.assertTrue(accepts(d.assessment_schema(claim, part, context), json.dumps(assessment)))
                result, backend = run([plan, assessment], claim, context)
                self.assertEqual(result['status'], 'completed')
                self.assertEqual(result['assessed_label'], case['label'])
                self.assertEqual(len(backend.calls), 2)
                checked, = result['parts']
                if key in ('009', '014'):
                    self.assertIn(TIE_RULE, checked['observations'][0]['quotes'])
                elif key == '012':
                    self.assertIn('exclusively on character and word units', checked['part']['scope']['metric'])
                    self.assertIn('morpheme', checked['observations'][0]['quotes'][0])
                elif key == '019':
                    self.assertTrue(checked['coverage']['complete'])
                    self.assertEqual(len(checked['coverage']['quotes']), 2)
                    self.assertIn('for each sentence', checked['coverage']['quotes'][0])
                    self.assertIn('entire corpus', checked['coverage']['quotes'][1])
                elif key in ('002', '024'):
                    positive = 'manually annotated' if key == '002' else 'incorporate supervision from English'
                    self.assertIn('counterexample to the claimed absence', checked['explanation'])
                    self.assertIn(positive, checked['explanation'])
                else:
                    self.assertEqual(checked['missing_reason'], 'measurement_unreported')
                    self.assertEqual(checked['missing_information'], [MEASUREMENTS[key]])
                    if key == '027':
                        self.assertIn('numeric-range cases correctly', checked['part']['scope']['metric'])

    def test_old_decompositions_and_priority_citation_are_rejected(self):
        for key, issue in [('012', 'incomplete_predicate_span'), ('027', 'scope_role_mismatch')]:
            with self.subTest(case=key), self.assertRaisesRegex(ValueError, issue):
                case = CASES[key]
                a.normalize_decomposition(case['recorded_replies'][0], case['claim'])
        case = CASES['009']
        _, part, _ = replies_for('009')
        old = case['recorded_replies'][1]
        self.assertFalse(accepts(d.assessment_schema(case['claim'], part, case['context']), json.dumps(old)))
        with self.assertRaisesRegex(ValueError, 'decisive_witness_missing_or_unknown'):
            a.assess_part(old, part, case['context'])

    def test_exclusive_list_requires_same_target_and_exact_set(self):
        _, part, _ = replies_for('012')
        proof = 'We trained translation systems over the following basic units: character and word.'
        raw, _ = evidence.source_ledger(part, proof)
        self.assertEqual(a.assess_part(raw, part, proof)['assessed_label'], 'support')
        for other in (proof.replace('translation systems', 'retrieval systems'),
                      proof.replace('the following basic units:', 'units including')):
            self.assertIsNone(evidence.source_ledger(part, other))

    def test_missing_measurement_does_not_override_a_reported_metric(self):
        reported = {'008': 'BLEU was 35.', '020': 'The F1 score was 0.80.',
                    '021': 'Average recall was 0.63.', '027': 'The success rate was 90%.'}
        for key, sentence in reported.items():
            with self.subTest(case=key):
                _, part, _ = replies_for(key)
                self.assertIsNone(reports.missing_measurement(part, CASES[key]['context'] + ' ' + sentence))
