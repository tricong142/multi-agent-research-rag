"""Keep unresolved counts tied to the qualified group or the containing target."""
import unittest

from .test_atomic_cellfix22 import cases, part
from .test_atomic_cellfix24 import plan
from .test_atomic_verifier import assessment, run


class Cellfix25Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.retired = {case['id']: case for case in cases('retired-holdout-v4')}

    def verify_unknown(self, case, entity, metric):
        claim, context = case['claim'], case['context']
        raw = assessment([], scope='unknown', missing=['target_binding_unresolved'])
        result, _ = run([plan(part(claim, entity, metric)), raw], claim, context)
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(result['assessed_label'], 'not_enough_info')
        self.assertEqual(result['parts'][0]['model_missing_information'], ['target_binding_unresolved'])
        self.assertEqual(result['parts'][0]['observations'], [])
        return result['parts'][0]['missing_information']

    def test_retired_003_requests_count_and_qualification(self):
        missing = self.verify_unknown(self.retired['holdout-v4:003'], 'human annotators',
                                      'assigned the occupation categories')
        self.assertTrue(any('count' in item and 'evidence that' in item
                            and 'unit=independent human annotators' in item
                            for item in missing), missing)

    def test_retired_006_requests_transcript_total_for_the_selected_dataset(self):
        missing = self.verify_unknown(self.retired['holdout-v4:006'], "study's selected interview dataset",
                                      'contains 50000 transcripts')
        self.assertTrue(any('source-backed total' in item and 'unit=transcripts' in item
                            and "target=study's selected interview dataset" in item
                            for item in missing), missing)
