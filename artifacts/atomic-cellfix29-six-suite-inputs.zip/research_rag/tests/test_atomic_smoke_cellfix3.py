
"""Cellfix3 development tests. Novel examples here are NOT held-out evaluation."""
from copy import deepcopy
import json
from pathlib import Path
import unittest
from research_rag.tests.test_atomic_verifier import (
    a, n, part, observation, assessment, operand, numeric, run
)
from research_rag.tests import test_atomic_assessment_v8 as h

def scoped(claim, entity, metric, **kwargs):
    p = part(claim, metric=metric, **kwargs)
    p['scope']['entity'] = entity
    return p

def request(claim,p,context):
    return [{'role':'system','content':a.ASSESS_PROMPT},
        {'role':'user','content':json.dumps({'claim':claim,'part':p,'context':context})}]

class BindingTests(unittest.TestCase):
    setUp=h.AssessmentTokenFilterTests.setUp
    accepts=h.AssessmentTokenFilterTests.accepts
    ordered=h.AssessmentTokenFilterTests.ordered

    def counts(self):
        claim='The audit evaluated six systems on three corpora.'
        first='Six systems were evaluated in the audit.'
        second='The evaluation used three corpora.'
        p=scoped(claim,'audit','evaluated six systems',condition='on three corpora')
        records=[numeric('value',first,operand('6','systems','six systems'),operand('6','systems','Six systems')),
            numeric('value',second,operand('3','corpora','three corpora'),operand('3','corpora','three corpora'))]
        raw=assessment([observation('audit','true',first,records)])
        raw['observations'][0]['quotes'].append(second)
        return claim,p,first+' '+second,raw

    def test_cross_sentence_quantities_share_one_target_observation(self):
        claim,p,proof,raw=self.counts()
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'support')
        self.assertTrue(self.accepts(self.ordered(raw),request(claim,p,proof)))

    def test_wrong_object_binding_is_filtered_and_enters_bounded_repair(self):
        claim,p,proof,good=self.counts();bad=deepcopy(good)
        bad['observations'][0]['numeric'][1].update(
            source_quote=good['observations'][0]['numeric'][0]['source_quote'],
            right=operand('6','systems','Six systems'))
        self.assertFalse(self.accepts(self.ordered(bad),request(claim,p,proof)))
        with self.assertRaisesRegex(ValueError,'numeric_metric_binding_unresolved'):
            a.assess_part(bad,p,proof)
        result,backend=run([{'parts':[p],'unresolved':[]},bad,good],claim,proof)
        self.assertEqual(result['assessed_label'],'support')
        self.assertEqual(result['backend_calls'],3)
        self.assertIn('SAME metric/object',backend.calls[-1][0][-1]['content'])

    def test_absent_measurement_remains_unknown_without_forcing_repair(self):
        claim,p,proof,raw=self.counts()
        proof='Six systems were evaluated in the audit.'
        raw['observations'][0].update(truth='unknown',numeric=None,quotes=[proof])
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'not_enough_info')
        self.assertTrue(self.accepts(self.ordered(raw),request(claim,p,proof)))

    def test_true_requires_every_quantity_and_repeated_requirement_is_rejected(self):
        claim,p,proof,raw=self.counts();raw['observations'][0]['numeric'].pop()
        self.assertFalse(self.accepts(self.ordered(raw),request(claim,p,proof)))
        with self.assertRaisesRegex(ValueError,'numeric_requirement_missing'):
            a.assess_part(raw,p,proof)
        raw['observations'][0]['numeric'] *= 2
        with self.assertRaisesRegex(ValueError,'duplicate_numeric_requirement'):
            a.assess_part(raw,p,proof)

    def test_atomic_target_rejects_baseline_and_duplicate_without_discarding_it(self):
        claim='Model Larch retained accuracy.'
        proof='Model Larch retained accuracy. The baseline was unmeasured.'
        p=scoped(claim,'Model Larch','accuracy')
        good=assessment([observation('Model Larch','true','Model Larch retained accuracy.')])
        bad=deepcopy(good)
        bad['observations'].append(observation('baseline','unknown','The baseline was unmeasured.'))
        with self.assertRaisesRegex(ValueError,'observation_target_mismatch'):
            a.assess_part(bad,p,proof)
        self.assertFalse(self.accepts(self.ordered(bad),request(claim,p,proof)))
        self.assertTrue(self.accepts(self.ordered(good),request(claim,p,proof)))
        bad=deepcopy(good);bad['observations'] *= 2
        with self.assertRaisesRegex(ValueError,'observation_identity_or_truth'):
            a.assess_part(bad,p,proof)

    def test_target_error_repair_preserves_budget(self):
        claim='Model Larch retained accuracy.';proof=claim+' The baseline was unmeasured.'
        p=scoped(claim,'Model Larch','accuracy')
        good=assessment([observation('Model Larch','true',claim)])
        bad=assessment([observation('baseline','unknown','The baseline was unmeasured.')])
        result,backend=run([{'parts':[p],'unresolved':[]},bad,good],claim,proof)
        self.assertEqual(result['assessed_label'],'support')
        self.assertEqual(result['backend_calls'],3)
        self.assertEqual(result['trace'][1]['validation_issue'],'observation_target_mismatch')
        exhausted,_=run([{'parts':[p],'unresolved':[]},bad,bad],claim,proof)
        self.assertEqual(exhausted['stop_reason'],'invalid_output_exhausted')
        self.assertIsNone(exhausted['assessed_label'])

    def test_missing_target_never_becomes_support(self):
        claim='Model Larch retained accuracy.';proof='Model Cedar retained accuracy.'
        p=scoped(claim,'Model Larch','accuracy')
        raw=assessment([observation('Model Cedar','true',proof)])
        with self.assertRaisesRegex(ValueError,'unresolved_target_requires_empty_ledger'):a.assess_part(raw,p,proof)
        self.assertFalse(self.accepts(self.ordered(raw),request(claim,p,proof)))
        raw['observations'][0]['truth']='unknown'
        self.assertFalse(self.accepts(self.ordered(raw),request(claim,p,proof)))
        raw=assessment([],scope='unknown',missing=['target_binding_unresolved'])
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'not_enough_info')
        self.assertTrue(self.accepts(self.ordered(raw),request(claim,p,proof)))

    def test_correct_member_cannot_borrow_another_named_targets_measurement(self):
        claim='Model Larch retained 71% accuracy.'
        first='Model Larch was tested.';second='Model Cedar retained 71% accuracy.'
        proof=first+' '+second;p=scoped(claim,'Model Larch','accuracy')
        for citation in (second,proof):
            check=numeric('value',citation,operand('71','%','71%'),operand('71','%','71%'))
            raw=assessment([observation('Model Larch','true',proof,[check])])
            self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'not_enough_info')
            self.assertFalse(self.accepts(self.ordered(raw),request(claim,p,proof)))

    def test_conflicting_quotes_declared_unknown_are_not_promoted(self):
        claim='Accuracy was 71%.';proof='Accuracy was 71%. Accuracy was 63%.'
        p=scoped(claim,'Accuracy','Accuracy')
        raw=assessment([observation('Accuracy','unknown',proof)])
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'not_enough_info')
        self.assertTrue(self.accepts(self.ordered(raw),request(claim,p,proof)))

    def test_metric_bridge_in_explicit_denial(self):
        claim='Model Aspen retained 71% accuracy.'
        proof='Model Aspen retained 63% accuracy, not 71%.'
        p=scoped(claim,'Model Aspen','accuracy')
        check=numeric('value',proof,operand('71','%','71%'),operand('63','%','63%'))
        raw=assessment([observation('Model Aspen','false',proof,[check])])
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'contradict')
        self.assertTrue(self.accepts(self.ordered(raw),request(claim,p,proof)))
        for prefix in ('If measured, ','Hypothetically, the model might: '):
            source=prefix+proof
            changed=deepcopy(check);changed['source_quote']=source
            self.assertEqual(n.check_numeric(changed,claim,source,metric='accuracy')['truth'],'unknown')

    def test_denied_quantity_is_not_the_observed_right_operand(self):
        claim='Model Aspen retained 71% accuracy.'
        proof='Model Aspen retained 63% accuracy, not 71%.'
        p=scoped(claim,'Model Aspen','accuracy')
        check=numeric('value',proof,operand('71','%','71%'),operand('71','%','71%'))
        raw=assessment([observation('Model Aspen','true',proof,[check])])
        self.assertFalse(self.accepts(self.ordered(raw),request(claim,p,proof)))
        with self.assertRaisesRegex(ValueError,'numeric_metric_binding_unresolved'):
            a.assess_part(raw,p,proof)

    def test_other_metric_denial_does_not_poison_positive_memory(self):
        claim='Model Aspen used 18% less memory.'
        proof='Model Aspen used 18% less memory and retained 79% accuracy, not 92%.'
        p=scoped(claim,'Model Aspen','memory')
        check=numeric('value',proof,operand('18','%','18%'),operand('18','%','18%'))
        raw=assessment([observation('Model Aspen','true',proof,[check])])
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'support')
        wrong=deepcopy(check);wrong['right']=operand('79','%','79%')
        self.assertFalse(a.numeric_metric_matches(p,wrong,n.numeric_requirements(claim)))

    def test_measurement_scope_generalizes_to_other_properties_and_units(self):
        claim='Pump Delta recorded 18 bar pressure.'
        proof='Pump Delta recorded 18 bar pressure and reported 25 C temperature, not 30 C.'
        p=scoped(claim,'Pump Delta','pressure')
        check=numeric('value',proof,operand('18','bar'),operand('18','bar'))
        raw=assessment([observation('Pump Delta','true',proof,[check])])
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'support')
        claim='Cost was 37 dollars.'
        proof='Cost was 37 dollars and latency was 5 seconds, not 8 seconds.'
        p=scoped(claim,'Cost','Cost')
        check=numeric('value',proof,operand('37','dollars'),operand('37','dollars'))
        raw=assessment([observation('Cost','true',proof,[check])])
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'support')

    def test_shared_modality_and_broad_negation_are_preserved(self):
        claim='Accuracy was 91%.'
        for proof in ('If measured, memory was 18% and accuracy was 91%.',
                'It is not true that memory was 18% and accuracy was 91%.',
                'Memory was not 18% and accuracy 91%.'):
            check=numeric('value',proof,operand('91','%','91%'),operand('91','%','91%'))
            self.assertEqual(n.check_numeric(check,claim,proof,metric='accuracy')['truth'],'unknown')

    def test_back_reference_and_preceding_negation_cannot_be_stripped(self):
        claim='Accuracy was 91%.'
        for proof in ('Accuracy was 91% and this is not true.',
                'The team did not report memory was 18% and accuracy was 91%.',
                'It never happened that memory was 18% and accuracy was 91%.',
                'Accuracy was 91% and we did not confirm this with precision 63%.'):
            check=numeric('value',proof,operand('91','%','91%'),operand('91','%','91%'))
            self.assertEqual(n.check_numeric(check,claim,proof,metric='Accuracy')['truth'],'unknown')

    def test_threshold_claim_guard_is_not_overridden(self):
        proof='Accuracy was 63% accuracy, not 71%.'
        check=numeric('value',proof,operand('71','%','71%'),operand('63','%','63%'))
        for claim in ('Accuracy was at least 71%.','Accuracy was not 71%.'):
            self.assertEqual(n.check_numeric(check,claim,proof,metric='Accuracy')['truth'],'unknown')

    def test_named_properties_and_quantifiers_keep_their_contract(self):
        for prop in ('accuracy','latency'):
            claim='The service improved '+prop+'.';p=scoped(claim,'service',prop)
            raw=assessment([observation('service','true',claim)])
            self.assertEqual(a.assess_part(raw,p,claim)['assessed_label'],'support')
            self.assertTrue(self.accepts(self.ordered(raw),request(claim,p,claim)))
        proof='Pump A improved. Pump B worsened.'
        claim='All pumps improved.';p=scoped(claim,'pumps','improved',quantifier='all')
        raw=assessment([observation('Pump B','false','Pump B worsened.')])
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'contradict')

    def test_real_cellfix2_invalid_targets_are_filtered(self):
        fixture=json.loads((Path(__file__).parent/'fixtures/atomic_cellfix2_binding_traces.json').read_text())
        for case in fixture:
            with self.subTest(case=case['example_id'],stage=case['stage']):
                self.assertFalse(self.accepts(self.ordered(case['output']),request(case['claim'],case['part'],case['context'])))
