"""Source-bound regressions for causal metrics and reported evidence gaps."""
import json
import unittest

from .test_atomic_cellfix16 import accepts
from .test_atomic_cellfix22 import ROOT, a, d, model_part, part
from .test_atomic_verifier import assessment, observation, run


def unknown(member, quote=None):
    raw = observation(member, 'unknown', quote)
    if quote is None:
        raw['quotes'] = []
    return raw


class Cellfix23Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases = {}
        for filename in ('factchecker_contract_cases.jsonl', 'blind_verifier_scope_regression_cases.jsonl'):
            path = ROOT / 'research_rag/evaluation' / filename
            cls.cases.update((row['example_id'], row) for row in
                             (json.loads(line) for line in path.read_bytes().splitlines()))

    def test_causal_metric_is_shared_by_decomposition_schema_and_validator(self):
        for claim, actor, metric, effect in (
            (self.cases['contract:causality_missing']['claim'], 'new index', 'latency', 'improvement'),
            ('The routing change caused the median request latency drop.', 'routing change',
             'median request latency', 'drop'),
        ):
            with self.subTest(claim=claim):
                p = part(claim, actor, metric)
                item = {key: p[key] for key in ('quote', 'quantifier', 'scope')}
                good = dict(parts=[item], unresolved=[])
                bad = dict(parts=[{**item, 'scope': {**item['scope'], 'metric': f'{metric} {effect}'}}],
                           unresolved=[])
                schema = d.decomposition_schema(claim)
                self.assertTrue(accepts(schema, json.dumps(good, separators=(',', ':'))))
                self.assertFalse(accepts(schema, json.dumps(bad, separators=(',', ':'))))
                result = a.normalize_decomposition(good, claim)
                self.assertEqual(result['parts'][0]['quote'], claim)
                with self.assertRaisesRegex(ValueError, 'metric_property_not_canonical'):
                    a.normalize_decomposition(bad, claim)

    def test_missing_quotes_survive_through_verify_without_changing_outcome_ledger(self):
        for family, entity, metric, quantifier, time, member, expected in (
            ('universal', 'validation shard', 'recall', 'all', 'after the revision',
             'validation shards', 'does not identify the complete set of validation shards'),
            ('existential', 'audited cache node', 'response time', 'some', 'after the patch',
             'the other audited nodes', 'Results for the other audited nodes were not reported'),
            ('entity', 'North gateway', 'error rate', 'atomic', 'after calibration',
             'North gateway', 'No calibration results for the North gateway were recorded'),
            ('direction', 'patch', 'median request latency', 'atomic', '',
             'patch', 'No before-patch latency or comparative change was reported'),
        ):
            with self.subTest(family=family):
                case = self.cases[f'scope:{family}:not_enough_info']
                claim, context = case['claim'], case['context']
                p = part(claim, entity, metric, quantifier=quantifier, time=time)
                plan = dict(parts=[model_part(p)], unresolved=[])
                result, _ = run([plan, assessment([unknown(member)])], claim, context)
                self.assertEqual(result['assessed_label'], 'not_enough_info')
                output = result['parts'][0]
                self.assertTrue(any(expected in q for q in output['missing_evidence']))
                self.assertTrue(all(q in context for q in output['missing_evidence']))
                self.assertEqual(output['observations'][0]['quotes'], [])
                self.assertFalse(output['coverage']['complete'])

    def test_missing_information_names_the_unresolved_member(self):
        case = self.cases['scope:none:not_enough_info']
        p = part(case['claim'], 'monitored pumps', 'leaked', 'none', 'during the overnight test')
        source = "Blue and Green had no leaks, but Silver's leak status was not reported."
        result = a.assess_part(assessment([unknown('Silver', source)]), p, case['context'])
        self.assertEqual(result['assessed_label'], 'not_enough_info')
        self.assertIn('unresolved members=Silver', result['missing_information'][0])
        self.assertIn(source, result['missing_evidence'])

    def test_unbound_target_and_unreported_measurement_are_distinct(self):
        case = self.cases['contract:irrelevant']
        p = part(case['claim'], 'Model Juniper', 'accuracy')
        raw = assessment([], scope='unknown', missing=['target_binding_unresolved'])
        result = a.assess_part(raw, p, case['context'])
        self.assertEqual(result['observations'], [])
        self.assertEqual(result['model_missing_information'], ['target_binding_unresolved'])
        self.assertEqual(len(result['missing_information']), 2)
        self.assertIn('accuracy', result['missing_information'][1])
        self.assertIn('No model accuracy is reported', result['missing_evidence'])
        claim = 'After tuning, the extractor increased token recall.'
        p = part(claim, 'extractor', 'token recall', time='After tuning')
        result = a.assess_part(raw, p, 'Token recall after tuning was not evaluated.')
        self.assertEqual(len(result['missing_information']), 2)
        self.assertIn('Token recall after tuning was not evaluated', result['missing_evidence'])
        for context in ('Precision after tuning was not evaluated.',
                        'Token recall before tuning was not evaluated.'):
            result = a.assess_part(raw, p, context)
            self.assertEqual(len(result['missing_information']), 1)
            self.assertEqual(result['missing_evidence'], [])

    def test_foreign_population_or_gateway_gap_does_not_become_evidence(self):
        claim = self.cases['scope:entity:not_enough_info']['claim']
        p = part(claim, 'North gateway', 'error rate', time='after calibration')
        context = ('The North gateway was calibrated. '
                   'No calibration results for the South gateway were recorded.')
        result = a.assess_part(assessment([unknown('North gateway')]), p, context)
        self.assertEqual(result['missing_evidence'], [])
        claim = self.cases['scope:universal:not_enough_info']['claim']
        p = part(claim, 'validation shard', 'recall', 'all', 'after the revision')
        context = ('Two validation shards improved recall after the revision. '
                   'The report does not identify the complete set of non-validation shards.')
        result = a.assess_part(assessment([unknown('validation shards')]), p, context)
        self.assertEqual(result['missing_evidence'], [])
