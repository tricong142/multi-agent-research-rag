"""Development regressions from the retired v5.1 packet and scope controls."""
from copy import deepcopy
import importlib
import json
import unittest

from .test_atomic_cellfix16 import accepts
from .test_atomic_cellfix22 import a, d, part
from .test_atomic_verifier import assessment, run

evidence = importlib.import_module('04_factchecker.inference.cellfix26_evidence')
reporting = importlib.import_module('04_factchecker.inference.assessment_reporting')

CASES = json.loads(r'''{
  "006": {
    "claim": "The WikiLarge test split contained 296,402 pairs.",
    "context": "Following BIBREF15 , we experiment on three simplification datasets, namely: (1) Newsela BIBREF22 , a high-quality simplification corpus of news articles composed by Newsela professional editors for children at multiple grade levels. We used the split of the data in BIBREF15 , i.e., 94,208/1,129/1,077 pairs for train/dev/test. (2) WikiSmall BIBREF10 , which contains aligned complex-simple sentence pairs from English Wikipedia (EW) and SEW. The dataset has 88,837/205/100 pairs for train/dev/test. (3) WikiLarge BIBREF15 , a larger corpus in which the training set is a mixture of three Wikipedia datasets in BIBREF10 , BIBREF11 , BIBREF23 , and the development and test sests are complex sentences taken from WikiSmall, each has 8 simplifications written by Amazon Mechanical Turk workers BIBREF12 . The dataset has 296,402/2,000/359 pairs for train/dev/test. Table TABREF7 provides statistics on the training sets.",
    "proposed_gold": "contradict",
    "evidence": [
      {
        "quote": "(3) WikiLarge BIBREF15",
        "start": 501,
        "end": 523
      },
      {
        "quote": "The dataset has 296,402/2,000/359 pairs for train/dev/test.",
        "start": 804,
        "end": 863
      }
    ]
  },
  "007": {
    "claim": "For every language in CoNLL 2009, the authors trained both a monolingual parser and parser variants with added English supervision.",
    "context": "ammar2016malopa found that using training data from multiple languages annotated with Universal Dependencies BIBREF1 , and represented using multilingual word vectors, outperformed monolingual training. Inspired by this, we apply the idea of training one model on multiple languages\u2014which we call polyglot training\u2014to PropBank-style semantic role labeling (SRL). We train several parsers for each language in the CoNLL 2009 dataset BIBREF0 : a traditional monolingual version, and variants which additionally incorporate supervision from English portion of the dataset. To our knowledge, this is the first multilingual SRL approach to combine supervision from several languages.",
    "proposed_gold": "support",
    "evidence": [
      {
        "quote": "We train several parsers for each language in the CoNLL 2009 dataset BIBREF0 : a traditional monolingual version, and variants which additionally incorporate supervision from English portion of the dataset.",
        "start": 363,
        "end": 569
      }
    ]
  },
  "010": {
    "claim": "The Newsela development split used in the experiment contained 1,129 pairs.",
    "context": "Following BIBREF15 , we experiment on three simplification datasets, namely: (1) Newsela BIBREF22 , a high-quality simplification corpus of news articles composed by Newsela professional editors for children at multiple grade levels. We used the split of the data in BIBREF15 , i.e., 94,208/1,129/1,077 pairs for train/dev/test. (2) WikiSmall BIBREF10 , which contains aligned complex-simple sentence pairs from English Wikipedia (EW) and SEW. The dataset has 88,837/205/100 pairs for train/dev/test. (3) WikiLarge BIBREF15 , a larger corpus in which the training set is a mixture of three Wikipedia datasets in BIBREF10 , BIBREF11 , BIBREF23 , and the development and test sests are complex sentences taken from WikiSmall, each has 8 simplifications written by Amazon Mechanical Turk workers BIBREF12 . The dataset has 296,402/2,000/359 pairs for train/dev/test. Table TABREF7 provides statistics on the training sets.",
    "proposed_gold": "support",
    "evidence": [
      {
        "quote": "(1) Newsela BIBREF22 , a high-quality simplification corpus of news articles composed by Newsela professional editors for children at multiple grade levels. We used the split of the data in BIBREF15 , i.e., 94,208/1,129/1,077 pairs for train/dev/test.",
        "start": 77,
        "end": 328
      }
    ]
  },
  "011": {
    "claim": "The IAC contains quote-response pairs whose responses were manually labeled as primarily factual or feeling based.",
    "context": "Our research examines factual versus feeling argument styles, drawing on annotations provided in the Internet Argument Corpus (IAC) BIBREF6 . This corpus includes quote-response pairs that were manually annotated with respect to whether the response is primarily a factual or feeling based argument, as Section SECREF2 describes in more detail. Figure FIGREF1 provides examples of responses in the IAC (paired with preceding quotes to provide context), along with the response's factual vs. feeling label.",
    "proposed_gold": "support",
    "evidence": [
      {
        "quote": "This corpus includes quote-response pairs that were manually annotated with respect to whether the response is primarily a factual or feeling based argument",
        "start": 142,
        "end": 298
      }
    ]
  },
  "023": {
    "claim": "The proposed NER approach achieved an average F1 score of 0.59 on the Ritter dataset.",
    "context": "In this paper we presented a novel architecture for NER that expands the feature set space based on feature clustering of images and texts, focused on microblogs. Due to their terse nature, such noisy data often lack enough context, which poses a challenge to the correct identification of named entities. To address this issue we have presented and evaluated a novel approach using the Ritter dataset, showing consistent results over state-of-the-art models without using any external resource or encoded rule, achieving an average of 0.59 F1. The results slightly outperformed state-of-the-art models which do not rely on encoded rules (0.49 and 0.54 F1), suggesting the viability of using the produced metadata to also boost existing NER approaches. A further important contribution is the ability to handle single tokens and misspelled words successfully, which is of utmost importance in order to better understand short texts. Finally, the architecture of the approach and its indicators introduce potential to transparently support multilingual data, which is the subject of ongoing investigation.",
    "proposed_gold": "support",
    "evidence": [
      {
        "quote": "using the Ritter dataset, showing consistent results over state-of-the-art models without using any external resource or encoded rule, achieving an average of 0.59 F1.",
        "start": 377,
        "end": 544
      }
    ]
  },
  "026": {
    "claim": "The translation systems were trained using morphemes and orthographic syllables as basic units.",
    "context": "We trained translation systems over the following basic units: character, morpheme, word, orthographic syllable and BPE unit. In this section, we summarize the languages and writing systems chosen for our experiments, the datasets used and the experimental configuration of our translation systems, and the evaluation methodology.",
    "proposed_gold": "support",
    "evidence": [
      {
        "quote": "We trained translation systems over the following basic units: character, morpheme, word, orthographic syllable and BPE unit.",
        "start": 0,
        "end": 125
      }
    ]
  },
  "030": {
    "claim": "The study found x-vectors more suitable than i-vectors when the task domain differed from the training data domain.",
    "context": "Our experiments with the European Portuguese datasets support the hypothesis that discriminative speaker embeddings contain information relevant for disease detection. In particular, we found evidence that these embeddings contain information that KB features fail to represent, thus proving the validity of our approach. It was also observed that x-vectors are more suitable than i-vectors for tasks whose domain does not match that of the training data, such as verbal task mismatch and cross-lingual experiments. This indicates that x-vectors embeddings are a strong contender in the replacement of knowledge-based feature sets for PD and OSA detection.",
    "proposed_gold": "support",
    "evidence": [
      {
        "quote": "It was also observed that x-vectors are more suitable than i-vectors for tasks whose domain does not match that of the training data, such as verbal task mismatch and cross-lingual experiments.",
        "start": 322,
        "end": 515
      }
    ]
  }
}''')
FRAGMENTS = {'007': {'parts': [{'quote': 'For every language in CoNLL 2009, the authors trained both a monolingual parser', 'quantifier': 'all', 'scope': {'entity': 'language in CoNLL 2009', 'metric': 'trained both a monolingual parser', 'time': '', 'condition': ''}}, {'quote': 'and parser variants with added English supervision.', 'quantifier': 'all', 'scope': {'entity': 'parser variants', 'metric': 'trained', 'time': '', 'condition': 'with added English supervision'}}], 'unresolved': []}, '026': {'parts': [{'quote': 'The translation systems were trained using morphemes', 'quantifier': 'atomic', 'scope': {'entity': 'translation systems', 'metric': 'trained', 'time': '', 'condition': 'using morphemes'}}, {'quote': 'and orthographic syllables as basic units.', 'quantifier': 'atomic', 'scope': {'entity': 'orthographic syllables', 'metric': 'as basic units', 'time': '', 'condition': 'and'}}], 'unresolved': []}}

class Cellfix26Tests(unittest.TestCase):
    def scope(self, case_id, claim=None):
        entity, metric, quantifier, condition = {
            '006': ('WikiLarge test split', 'contained 296,402 pairs', 'atomic', ''),
            '007': ('language in CoNLL 2009', 'trained both a monolingual parser and parser variants with added English supervision', 'all', ''),
            '010': ('Newsela development split used in the experiment', 'contained 1,129 pairs', 'atomic', ''),
            '011': ('IAC', 'contains quote-response pairs whose responses were manually labeled as primarily factual or feeling based', 'atomic', ''),
            '023': ('proposed NER approach', 'achieved an average F1 score of 0.59', 'atomic', 'on the Ritter dataset'),
            '026': ('translation systems', 'were trained using morphemes and orthographic syllables as basic units', 'atomic', ''),
            '030': ('x-vectors', 'more suitable than i-vectors', 'atomic', 'when the task domain differed from the training data domain'),
        }[case_id]
        return part(claim or CASES[case_id]['claim'], entity, metric, quantifier, condition=condition)

    def test_reported_fragments_are_rejected(self):
        for case_id in ('007', '026'):
            with self.subTest(case=case_id):
                claim = CASES[case_id]['claim']
                with self.assertRaisesRegex(ValueError, 'incomplete_predicate_span'):
                    a.normalize_decomposition(FRAGMENTS[case_id], claim)
                self.assertFalse(accepts(d.decomposition_schema(claim), json.dumps(FRAGMENTS[case_id])))

    def test_newsela_count_survives_the_subject_modifier(self):
        case = CASES['010']
        a.preflight_request(case['claim'], case['context'])
        d.decomposition_schema(case['claim'])

    def test_annotation_categories_are_not_two_propositions(self):
        claim = CASES['011']['claim']
        p = part(claim, 'IAC', claim.split('IAC ', 1)[1].rstrip('.'))
        raw = {'parts': [{k: p[k] for k in ('quote', 'quantifier', 'scope')}], 'unresolved': []}
        self.assertEqual(a.normalize_decomposition(raw, claim)['parts'][0]['quote'], claim)
        self.assertTrue(accepts(d.decomposition_schema(claim), json.dumps(raw)))

    def test_verifier_replays_the_seven_scoped_reports(self):
        for case_id, case in CASES.items():
            with self.subTest(case=case_id):
                claim, context = case['claim'], case['context']
                p = self.scope(case_id)
                plan = {'parts': [{k: p[k] for k in ('quote', 'quantifier', 'scope')}], 'unresolved': []}
                self.assertTrue(accepts(d.decomposition_schema(claim), json.dumps(plan)))
                normalized, = a.normalize_decomposition(plan, claim)['parts']
                self.assertEqual({k: normalized[k] for k in p}, p)
                witness = evidence.source_ledger(p, context)
                self.assertIsNotNone(witness)
                raw, _ = witness
                self.assertTrue(accepts(d.assessment_schema(claim, p, context), json.dumps(raw)))
                result, backend = run([plan, raw], claim, context)
                self.assertEqual(result['assessed_label'], case['proposed_gold'], result)
                self.assertEqual(len(backend.calls), 2)
                quotes = raw['observations'][0]['quotes']
                self.assertTrue(all(quote in context for quote in quotes))
                required = [item['quote'] for item in case['evidence']]
                if case_id == '010':
                    required = ['94,208/1,129/1,077 pairs for train/dev/test.']
                self.assertTrue(all(any(q in actual for actual in quotes) for q in required), quotes)

                altered = deepcopy(raw)
                altered['observations'][0]['quotes'][0] = 'No exact source span.'
                with self.assertRaisesRegex(ValueError, 'decisive_witness_missing_or_unknown'):
                    a.assess_part(altered, p, context)

    def test_missing_or_mismatched_scope_stays_unresolved(self):
        controls = [
            ('006', 'pairs for train/dev/test. Table', 'pairs for train/dev/evaluation. Table'),
            ('007', 'for each language', 'for some languages'),
            ('023', 'average of 0.59 F1.', 'average of 0.59 recall.'),
            ('023', 'using the Ritter dataset', 'using a different dataset'),
            ('026', ', orthographic syllable', ''),
            ('030', 'domain does not match', 'domain matches'),
        ]
        for case_id, original, modified in controls:
            with self.subTest(case=case_id, control=modified):
                case = CASES[case_id]
                self.assertIn(original, case['context'])
                context = case['context'].replace(original, modified)
                p = self.scope(case_id)
                self.assertIsNone(evidence.source_ledger(p, context))
                raw = assessment([], scope='unknown', missing=[reporting.missing_reason(p, context)])
                self.assertEqual(a.assess_part(raw, p, context)['assessed_label'], 'not_enough_info')

    def test_reordered_splits_and_reversed_comparator_bind_to_the_report(self):
        count = CASES['006']['context'].replace(
            '296,402/2,000/359 pairs for train/dev/test.', '296,402/359/2,000 pairs for test/train/dev.')
        compare = CASES['030']['context'].replace(
            'x-vectors are more suitable than i-vectors', 'i-vectors are more suitable than x-vectors')
        for case_id, context, expected in [('006', count, 'support'), ('030', compare, 'contradict')]:
            with self.subTest(case=case_id):
                p = self.scope(case_id)
                raw, _ = evidence.source_ledger(p, context)
                self.assertEqual(a.assess_part(raw, p, context)['assessed_label'], expected)
