"""End-to-end offline regressions for retired v5.1 reports and metric ambiguity."""
import json
from importlib import import_module
from pathlib import Path
import unittest

from .test_atomic_cellfix16 import accepts
from .test_atomic_cellfix22 import a, d
from .test_atomic_verifier import assessment, run

evidence = import_module('04_factchecker.inference.cellfix26_evidence')
reporting = import_module('04_factchecker.inference.assessment_reporting')
PACKET = Path(__file__).resolve().parents[2] / 'validation/cellfix26-retired-holdout-v5-1/original/cases.jsonl'
CASES = {r['id'].split(':')[-1]: r for r in map(json.loads, PACKET.read_text(encoding='utf-8').splitlines())}
REPORT_CASES = ('001', '003', '005', '013', '014', '018', '019', '022', '024', '025')
BIRCH = 'At least one audited cache node reduced response time after the patch.'
BIRCH_CONTEXT = ('The audited cache nodes were Birch, Elm and Fir. '
                 'After the patch, Birch became faster, while Elm and Fir became slower.')


def plan_for(claim):
    parts = []
    for clause in a.scope_clauses(claim):
        quote = claim[clause['start']:clause['end']].strip()
        scope = {key: (clause['roles'].get(key) or clause.get(key) or [''])[0]
                 for key in ('entity', 'metric', 'time', 'condition')}
        parts.append(dict(quote=quote, quantifier=a._quantifier(quote), scope=scope))
    return dict(parts=parts, unresolved=[])


def birch_plan():
    return {'parts': [dict(quote=BIRCH, quantifier='some', scope=dict(
        entity='audited cache node', metric='response time', time='after the patch', condition=''))],
        'unresolved': []}


class Cellfix27Tests(unittest.TestCase):
    def test_source_reports_pass_through_verifier_and_decoder(self):
        for case_id in REPORT_CASES:
            with self.subTest(case_id=case_id):
                case = CASES[case_id]
                claim, context = case['claim'], case['context']
                plan = plan_for(claim)
                self.assertTrue(accepts(d.decomposition_schema(claim), json.dumps(plan)))
                parts = a.normalize_decomposition(plan, claim)['parts']
                if case_id == '005':
                    self.assertEqual([part['scope']['entity'] for part in parts], ['OMICS', 'OMICS'])
                    bad = json.loads(json.dumps(plan))
                    bad['parts'][1]['scope']['entity'] = '9,044 individual narratives'
                    self.assertFalse(accepts(d.decomposition_schema(claim), json.dumps(bad)))
                    with self.assertRaises(ValueError):
                        a.normalize_decomposition(bad, claim)
                responses = []
                for part in parts:
                    raw, _ = evidence.source_ledger(part, context)
                    self.assertTrue(accepts(d.assessment_schema(claim, part, context), json.dumps(raw)))
                    for observation in raw['observations']:
                        self.assertTrue(all(quote in context for quote in observation['quotes']))
                        self.assertTrue(any(observation['member'] in quote for quote in observation['quotes']))
                    responses.append(raw)
                result, backend = run([plan, *responses], claim, context)
                self.assertEqual(result['assessed_label'], case['proposed_gold'], result)
                self.assertEqual(len(backend.calls), 1 + len(parts))
                if case_id == '003':
                    record = result['parts'][0]['observations'][0]['numeric_result']
                    self.assertEqual((record['kind'], record['lower_bound'], record['upper_bound']),
                                     ('range', '14', '122'))

    def test_reports_do_not_borrow_another_target_condition_or_result(self):
        controls = [
            ('001', 'does not necessarily mean', 'sometimes implies'),
            ('003', '14 to 122 narratives', '14 to 130 narratives'),
            ('005', 'The OMICS corpus has', 'The Other corpus has'),
            ('013', 'domain does not match', 'domain matches'),
            ('014', 'matches with the same length', 'matches with a different length'),
            ('018', 'using the Ritter dataset', 'using the unrelated dataset'),
            ('019', 'for each sentence', 'for some sentences'),
            ('022', ', Request,', ', Offer,'),
            ('024', 'from English portion', 'from German portion'),
            ('025', 'and Miscellaneous.', 'and Other.'),
        ]
        for case_id, before, after in controls:
            with self.subTest(case_id=case_id):
                case = CASES[case_id]
                claim = case['claim']
                self.assertIn(before, case['context'])
                context = case['context'].replace(before, after, 1)
                part = a.normalize_decomposition(plan_for(claim), claim)['parts'][-1]
                self.assertIsNone(evidence.source_ledger(part, context))

    def test_missing_count_and_time_are_specific(self):
        for case_id, count in [('015', '5,000 English training sentences'),
                               ('017', '50,000 tokens'), ('029', '100,000 sentences')]:
            with self.subTest(case_id=case_id):
                case = CASES[case_id]
                claim, context = case['claim'], case['context']
                plan = plan_for(claim)
                part, = a.normalize_decomposition(plan, claim)['parts']
                self.assertTrue(accepts(d.decomposition_schema(claim), json.dumps(plan)))
                reason = reporting.missing_reason(part, context)
                self.assertIn(reason, ('measurement_unreported', 'contained_total_unresolved'))
                raw = assessment([], scope='unknown', missing=[reason])
                self.assertTrue(accepts(d.assessment_schema(claim, part, context), json.dumps(raw)))
                result, _ = run([plan, raw], claim, context)
                self.assertEqual(result['assessed_label'], 'not_enough_info')
                self.assertIn(count, result['parts'][0]['missing_information'][0])
                if case_id == '029':
                    self.assertEqual(part['scope']['time'], 'during the grammatical evaluation')

    def test_qualitative_speed_cannot_establish_response_time(self):
        plan = birch_plan()
        part, = a.normalize_decomposition(plan, BIRCH)['parts']
        raw, _ = evidence.source_ledger(part, BIRCH_CONTEXT)
        self.assertTrue(accepts(d.assessment_schema(BIRCH, part, BIRCH_CONTEXT), json.dumps(raw)))
        result, _ = run([plan, raw], BIRCH, BIRCH_CONTEXT)
        self.assertEqual(result['assessed_label'], 'not_enough_info')
        self.assertEqual(result['parts'][0]['missing_reason'], 'comparison_unresolved')

        measured = ('The audited cache nodes were Birch, Elm and Fir. '
                    "After the patch, Birch's response time decreased.")
        self.assertIsNone(evidence.source_ledger(part, measured))
        observation = {'member': 'Birch', 'truth': 'true', 'quotes': [measured],
                       'explanation': reporting.OBSERVATION_NOTE, 'numeric': None}
        result, _ = run([plan, assessment([observation])], BIRCH, measured)
        self.assertEqual(result['assessed_label'], 'support')
