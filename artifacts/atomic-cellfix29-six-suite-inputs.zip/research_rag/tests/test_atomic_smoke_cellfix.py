
"""Cellfix regressions: real failure modes and novel inputs; no model inference."""
from copy import deepcopy
import json, unittest
from research_rag.tests.test_atomic_verifier import a, assessment, observation, operand, numeric, part
from research_rag.tests import test_atomic_assessment_v8 as helpers

class CellfixTests(unittest.TestCase):
    setUp = helpers.AssessmentTokenFilterTests.setUp
    accepts = helpers.AssessmentTokenFilterTests.accepts
    ordered = helpers.AssessmentTokenFilterTests.ordered
    def request(self, claim, p, proof):
        return [{'role':'system','content':a.ASSESS_PROMPT}, {'role':'user','content':json.dumps(
            {'claim':claim,'part':p,'context':proof})}]
    def test_value_operand_roles_cannot_be_swapped(self):
        claim,proof='Rehearsal took 11 seconds.','Rehearsal took 11 minutes, not 11 seconds.'
        p=part(claim,metric='took 11 seconds')
        check=numeric('value',proof,operand('11','seconds'),operand('11','minutes'))
        raw=assessment([observation('Rehearsal','false',proof,check)])
        self.assertTrue(self.accepts(self.ordered(raw),self.request(claim,p,proof)))
        check['left'],check['right']=check['right'],check['left']
        self.assertFalse(self.accepts(self.ordered(raw),self.request(claim,p,proof)))
    def test_change_is_not_a_claim_value_record(self):
        claim,proof='Latency decreased.','Latency fell from 42 ms to 31 ms.'
        p=part(claim,metric='Latency')
        check=numeric('change',proof,operand('42','ms'),operand('31','ms'))
        raw=assessment([observation('Latency','true',proof,check)])
        self.assertTrue(self.accepts(self.ordered(raw),self.request(claim,p,proof)))
        check['kind']='value'
        self.assertFalse(self.accepts(self.ordered(raw),self.request(claim,p,proof)))
    def test_atomic_observation_count_is_bounded(self):
        claim,proof='A improved.','A improved. B improved. C improved.'
        p=part(claim,metric='improved')
        raw=assessment([observation(m,'true',m+' improved.') for m in ('A','B')])
        self.assertFalse(self.accepts(self.ordered(raw),self.request(claim,p,proof)))
        raw['observations']=raw['observations'][:1]
        self.assertTrue(self.accepts(self.ordered(raw),self.request(claim,p,proof)))
        raw['observations'].append(observation('C','true','C improved.'))
        self.assertFalse(self.accepts(self.ordered(raw),self.request(claim,p,proof)))
    def test_right_operand_must_belong_to_selected_source_quote(self):
        claim='Capacity was 9 liters.'
        proof='Capacity was 9 liters. Temperature was 4 degrees.'
        p=part(claim,metric='Capacity')
        check=numeric('value','Capacity was 9 liters.',operand('9','liters'),operand('9','liters'))
        raw=assessment([observation('Capacity','true',proof,check)])
        self.assertTrue(self.accepts(self.ordered(raw),self.request(claim,p,proof)))
        check['source_quote']='Temperature was 4 degrees.'
        self.assertFalse(self.accepts(self.ordered(raw),self.request(claim,p,proof)))
    def test_causal_support_needs_causal_evidence(self):
        for entity,claim,proof in (
            ('new index','The new index caused the latency improvement.',
             'The new index and lower latency were observed in the same deployment. The study did not establish a causal relationship.'),
            ('driver','The driver caused the slowdown.','The driver and a slowdown were observed together.')):
            p=part(claim,metric='latency');p['scope']['entity']=entity
            raw=assessment([observation(entity,'true',proof)])
            with self.assertRaisesRegex(ValueError,'causal_relation_not_grounded'):
                a.assess_part(raw,p,proof)
            raw['observations'][0]['truth']='unknown'
            self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'not_enough_info')
        proof='The driver caused the slowdown.'
        raw=assessment([observation('driver','true',proof)])
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'support')
    def test_collective_noun_does_not_prove_all(self):
        for entity,claim,proof in (
            ('tasks','All tasks improved after compression.',
             'Three tasks improved after compression, but a fourth task became less accurate.'),
            ('valves','All valves remained sealed.','Two valves remained sealed, but a third valve leaked.')):
            p=part(claim,quantifier='all',metric='improved');p['scope']['entity']=entity
            raw=assessment([observation(entity,'true',proof)],complete=True)
            with self.assertRaisesRegex(ValueError,'collective_coverage_unproven'):
                a.assess_part(raw,p,proof)
        proof='All valves remained sealed.'
        raw=assessment([observation('valves','true',proof)],complete=True)
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'support')
        proof='A remained sealed. B remained sealed. The complete set of valves is A and B.'
        raw=assessment([observation(m,'true',proof) for m in ('A','B')],complete=True)
        self.assertEqual(a.assess_part(raw,p,proof)['assessed_label'],'support')
    def test_assessment_repair_does_not_echo_failed_answer(self):
        messages=a.request_messages(a.ASSESS_PROMPT,{'claim':'source'},
            {'validation_issue':'numeric_source_membership','output':{'echo':'BAD_DRAFT'}})
        self.assertFalse(any(m['role']=='assistant' for m in messages))
        self.assertNotIn('BAD_DRAFT',json.dumps(messages))
