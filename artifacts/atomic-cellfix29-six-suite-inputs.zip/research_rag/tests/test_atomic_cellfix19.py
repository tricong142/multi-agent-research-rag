"""Received development failures and novel controls; no holdout or model weights."""
from copy import deepcopy
import importlib
import json
from pathlib import Path
from types import SimpleNamespace
import unittest

from .test_atomic_cellfix16 import accepts
from .test_atomic_cellfix18 import ledger

a = importlib.import_module('04_factchecker.inference.atomic_verifier')
d = importlib.import_module('04_factchecker.inference.atomic_decoding')
rules = importlib.import_module('04_factchecker.inference.cellfix19_rules')
counts = importlib.import_module('04_factchecker.inference.cellfix16_rules')
runtime = importlib.import_module('04_factchecker.inference.cellfix14_runtime')
from research_rag.evaluation.cellfix19_postprocess import decoding_trace_complete


def received():
    return json.loads((Path(__file__).parent/'fixtures/cellfix18_validation30_failure.json').read_bytes())


def example(total='six', selected='two', actor='audit', source='Atlas catalog', verb='evaluates'):
    claim = f'The {actor} {verb} all {total} categories from the {source}.'
    context = f'The {source} contains {total} categories: Alpha, Beta, Gamma, Delta, Epsilon, Zeta. The {actor} {verb} only the first {selected} categories.'
    part = dict(quote=claim, quantifier='all', scope=dict(entity=total+' categories',metric=verb,time='',condition='from the '+source))
    return claim, part, context


def token_paths19():
    paths = []
    for failure in received():
        case, saved = failure['case'], failure['result']
        raw = deepcopy(saved['trace'][0]['output'])
        if case['example_id'].endswith('020'):
            paths.append(('cf19_article_entity_rejected', case['claim'],None,None,deepcopy(raw),False))
            raw['parts'][0]['scope']['entity'] = '80 events'
        paths.append(('cf19_valid_population_'+case['example_id'][-3:],case['claim'],None,None,raw,True))
        part = a.normalize_decomposition(raw,case['claim'])['parts'][0]
        witness = counts.count_witness(part,case['context'])
        assert witness is not None, case['example_id']
        paths.append(('cf19_decisive_subset_'+case['example_id'][-3:],case['claim'],part,case['context'],ledger(witness),True))
        unknown = ledger(witness);unknown['observations'][0].update(truth='unknown',numeric=None,quotes=[])
        unknown['missing_information']=['population_results_unresolved']
        paths.append(('cf19_subset_not_unknown_'+case['example_id'][-3:],case['claim'],part,case['context'],unknown,False))
        unknown_numeric = ledger(witness);unknown_numeric['observations'][0]['truth']='unknown'
        paths.append(('cf19_subset_not_numeric_unknown_'+case['example_id'][-3:],case['claim'],part,case['context'],unknown_numeric,False))
    return paths


class Cellfix19Tests(unittest.TestCase):
    def test_received_failures_have_reachable_repairs_and_false_witnesses(self):
        for name,claim,part,context,raw,expected in token_paths19():
            with self.subTest(name=name),runtime.decode_request(None):
                schema=d.decomposition_schema(claim) if part is None else d.assessment_schema(claim,part,context)
                self.assertEqual(accepts(schema,json.dumps(raw)),expected)
                call=(lambda:a.normalize_decomposition(raw,claim)) if part is None else (lambda:a.assess_part(raw,part,context))
                if expected:
                    value=call()
                    if part is not None:self.assertEqual(value['assessed_label'],'contradict')
                else:
                    with self.assertRaises(ValueError):call()

    def test_function_words_are_not_subjects(self):
        for entity in ('The','a','an','of the','in','and','this','all'):
            with self.subTest(entity=entity):
                self.assertEqual(rules.subject_issue({'entity':entity},'The audit evaluated all six categories.',lambda *_:None),'entity_reference_required')
        self.assertIsNone(rules.subject_issue({'entity':'The audit'},'The audit evaluated six categories.',lambda *_:None))

    def test_novel_allocations_preserve_population_and_role(self):
        allocation = importlib.import_module('04_factchecker.inference.cellfix18_rules')
        for source,total,subset,verb,role in [('Harbor Corpus',60,15,'allocates','validation'),
                ('Maple Archive',24,9,'assigns','testing'),('Pine Dataset',50,20,'reserves','training')]:
            claim=f'The {source} {verb} all {total} records for {role}.'
            context=f'The {source} contains {total} records. Of these records, {subset} are assigned for {role}.'
            part=dict(quote=claim,quantifier='all',scope=dict(entity=f'{total} records',metric=f'{verb} all {total} records',time='',condition=f'for {role}'))
            with self.subTest(source=source),runtime.decode_request(None):
                witness=allocation.allocation_witness(part,context);self.assertIsNotNone(witness)
                self.assertEqual(a.assess_part(ledger(witness),part,context)['assessed_label'],'contradict')
                self.assertTrue(accepts(d.assessment_schema(claim,part,context),json.dumps(ledger(witness))))
                for entity in ('The',source,f'{total} records for {role}'):
                    self.assertIsNotNone(rules.subject_issue({'entity':entity},claim,lambda *_:None))
                self.assertIsNone(allocation.allocation_witness(part,context.replace(f'for {role}','for development')))
                self.assertIsNone(allocation.allocation_witness(part,context.replace(f'{subset} are',f'{total} are')))

    def test_novel_actor_source_count_and_verb_controls(self):
        for actor,source,verb in [('audit','Atlas catalog','evaluates'),('analysis','Birch inventory','examines'),('experiment','Cedar dataset','selects')]:
            claim,part,context=example(actor=actor,source=source,verb=verb)
            with self.subTest(actor=actor),runtime.decode_request(None):
                witness=rules.selection_witness(part,context);self.assertIsNotNone(witness)
                self.assertEqual(a.assess_part(ledger(witness),part,context)['assessed_label'],'contradict')
                self.assertTrue(accepts(d.assessment_schema(claim,part,context),json.dumps(ledger(witness))))
        claim,part,context=example(total='9',selected='4')
        context=context.replace('Epsilon, Zeta.', 'Epsilon, Zeta, Eta, Theta, Iota.')
        self.assertIsNotNone(rules.selection_witness(part,context))

    def test_subset_witness_does_not_invent_missing_or_wrong_binding(self):
        claim,part,context=example()
        negatives=[context.replace('only ','') ,context.replace('The audit evaluates','The other audit evaluates'),
            context.replace('Atlas catalog','Other catalog'),context.replace('six categories','five categories'),
            context.replace('first two','first six'),context.replace('first two','first seven'),
            context.replace('only','might evaluate only'),context+' The audit evaluates all six categories.',
            context.replace('Alpha, Beta, Gamma, Delta, Epsilon, Zeta','Alpha, Beta'),
            context.replace('evaluates','does not evaluate')]
        for text in negatives:
            with self.subTest(context=text):self.assertIsNone(rules.selection_witness(part,text))
        modified=deepcopy(part);modified['quote']=claim.replace('categories','specialized categories');modified['scope']['entity']='six specialized categories'
        self.assertIsNone(rules.selection_witness(modified,context))

    def test_unknown_cannot_discard_explicit_exclusion(self):
        _,part,context=example();witness=rules.selection_witness(part,context)
        raw=ledger(witness);raw['observations'][0].update(truth='unknown',numeric=None,quotes=[])
        raw['missing_information']=['population_results_unresolved']
        with runtime.decode_request(None),self.assertRaises(ValueError):a.assess_part(raw,part,context)

    def test_named_entity_modifier_requires_an_explicit_antecedent(self):
        failure=received()[1];case=failure['case']
        raw=failure['result']['trace'][0]['output']
        part=a.normalize_decomposition(raw,case['claim'])['parts'][0]
        witness=rules.selection_witness(part,case['context']);self.assertIsNotNone(witness)
        bad=case['context'].replace('named entity-annotated','quality-annotated')
        self.assertIsNone(rules.selection_witness(part,bad))
        with runtime.decode_request(None):
            try:result=a.assess_part(ledger(witness),part,bad)
            except ValueError:pass
            else:self.assertEqual(result['assessed_label'],'not_enough_info')

    def test_schema_replay_memoizes_requests_but_checks_every_hash(self):
        calls=[];progress=[]
        @runtime.cached
        def expensive(value):calls.append(value);return {'value':value}
        def schema(request):
            expensive('same');return expensive('same'),None
        fake=SimpleNamespace(__package__=d.__package__,schema_for=schema,schema_sha256=lambda _: 'expected')
        message=[{'role':'user','content':'same'}]
        event=dict(structured_decoder={},schema_sha256='expected',deadline_stop_enabled=True)
        criteria=dict(structured_decoder={},require_cooperative_deadline=True)
        self.assertTrue(decoding_trace_complete(fake,[event,event],[message,message],criteria,progress.append))
        self.assertEqual(calls,['same']);self.assertEqual(progress[-1]['state'],'completed')
        bad={**event,'schema_sha256':'tampered'}
        self.assertFalse(decoding_trace_complete(fake,[event,bad],[message,message],criteria))
        self.assertFalse(decoding_trace_complete(fake,[{**event,'deadline_stop_enabled':False}],[message],criteria))
        self.assertFalse(decoding_trace_complete(fake,[],[],criteria))


if __name__ == '__main__':unittest.main()
