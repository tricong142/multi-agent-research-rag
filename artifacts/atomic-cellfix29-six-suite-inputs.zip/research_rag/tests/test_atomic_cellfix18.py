"""Received timeout traces and new allocation controls, without model inference."""
from copy import deepcopy
import cProfile
import importlib
import json
from pathlib import Path
import unittest

from .test_atomic_cellfix16 import accepts

a = importlib.import_module('04_factchecker.inference.atomic_verifier')
d = importlib.import_module('04_factchecker.inference.atomic_decoding')
rules = importlib.import_module('04_factchecker.inference.cellfix18_rules')
legacy_rules = importlib.import_module('04_factchecker.inference.cellfix16_rules')
runtime = importlib.import_module('04_factchecker.inference.cellfix14_runtime')
reporting = importlib.import_module('04_factchecker.inference.assessment_reporting')


def samples():
    return json.loads((Path(__file__).parent / 'fixtures/cellfix17_validation30_failure.json').read_bytes())


def plans():
    first, second = samples()
    raw9 = deepcopy(first['saved_result']['trace'][0]['output'])
    generation = next(e for e in second['events'] if e['event'] == 'generation')
    raw20 = json.loads(generation['raw_output'])
    return [(first['case'], raw9, 'sentence'), (second['case'], raw20, '80 events')]


def ledger(witness):
    return dict(scope_match='matched', coverage=dict(complete=False, members=[], quotes=[]),
                observations=[dict(member=witness['members'][0], truth=witness['truth'],
                    quotes=witness['quotes'], explanation=reporting.OBSERVATION_NOTE, numeric=witness.get('record'))],
                missing_information=[], explanation=reporting.ASSESSMENT_NOTE)


def token_paths18():
    paths = []
    for case, raw, entity in plans():
        paths.append(('cf18_bad_subject_' + entity, case['claim'], None, None, raw, False))
        fixed = deepcopy(raw)
        fixed['parts'][0]['scope']['entity'] = entity
        paths.append(('cf18_nominal_subject_' + entity, case['claim'], None, None, fixed, True))
    case, raw, entity = plans()[1]
    raw['parts'][0]['scope']['entity'] = entity
    part = a.normalize_decomposition(raw, case['claim'])['parts'][0]
    witness = rules.allocation_witness(part, case['context'])
    paths.append(('cf18_allocation_counterexample', case['claim'], part, case['context'], ledger(witness), True))
    return paths


class Cellfix18Tests(unittest.TestCase):
    def test_received_predicate_subjects_rejected_and_nominal_repairs_reachable(self):
        for case, raw, entity in plans():
            with self.subTest(entity=entity), runtime.decode_request(None):
                schema = d.decomposition_schema(case['claim'])
                with self.assertRaisesRegex(ValueError, 'quantified_population_required'):
                    a.normalize_decomposition(raw, case['claim'])
                self.assertFalse(accepts(schema, json.dumps(raw)))
                raw['parts'][0]['scope']['entity'] = entity
                a.normalize_decomposition(raw, case['claim'])
                self.assertTrue(accepts(schema, json.dumps(raw)))

    def test_population_cache_avoids_repeating_context_scan_in_schema(self):
        case, raw, entity = plans()[0]
        raw['parts'][0]['scope']['entity'] = entity
        part = a.normalize_decomposition(raw, case['claim'])['parts'][0]
        profile = cProfile.Profile()
        with runtime.decode_request(None):
            profile.enable()
            schema = d.assessment_schema(case['claim'], part, case['context'])
            profile.disable()
        calls = sum(entry.callcount for entry in profile.getstats()
                    if not isinstance(entry.code, str) and entry.code.co_name == '_population')
        self.assertLessEqual(calls, 1)
        self.assertLessEqual(schema['properties']['observations']['maxItems'], 1)
        for branch in schema['properties']['coverage'].get('anyOf', [schema['properties']['coverage']]):
            self.assertLessEqual(branch['properties']['members']['maxItems'], 1)
        unknown = dict(truth='unknown', members=['Sentence'], quotes=[], record=None)
        raw = ledger(unknown)
        raw['missing_information'] = [reporting.missing_reason(part, case['context'])]
        with self.assertRaisesRegex(ValueError, 'observation_member_is_not_entity'):
            a.assess_part(raw, part, case['context'])
        self.assertFalse(accepts(schema, json.dumps(raw)))
        raw['observations'] = []
        self.assertEqual(a.assess_part(raw, part, case['context'])['assessed_label'], 'not_enough_info')
        self.assertTrue(accepts(schema, json.dumps(raw)))
        raw['coverage'].update(complete=True, members=['Sentence', 'Sentence'])
        self.assertFalse(accepts(schema, json.dumps(raw)))

    def test_received_allocation_subset_has_compact_false_witness(self):
        case, raw, entity = plans()[1]
        raw['parts'][0]['scope']['entity'] = entity
        part = a.normalize_decomposition(raw, case['claim'])['parts'][0]
        with runtime.decode_request(None):
            witness = legacy_rules.count_witness(part, case['context'])
            self.assertIsNotNone(witness)
            record = ledger(witness)
            self.assertEqual(a.assess_part(record, part, case['context'])['assessed_label'], 'contradict')
            schema = d.assessment_schema(case['claim'], part, case['context'])
            self.assertEqual(schema['properties']['observations']['maxItems'], 1)
            self.assertTrue(accepts(schema, json.dumps(record)))
            self.assertLess(len(json.dumps(schema)), 5000)

    def test_new_allocation_source_binding_and_ambiguous_controls(self):
        claim = 'The Harbor Corpus allocates all 60 records for validation.'
        context = 'The Harbor Corpus contains 60 records. Of these records, 15 are assigned for validation.'
        part = dict(quote=claim, quantifier='all', scope=dict(entity='60 records', metric='validation', time='', condition=''))
        witness = rules.allocation_witness(part, context)
        self.assertIsNotNone(witness)
        with runtime.decode_request(None):
            self.assertEqual(a.assess_part(ledger(witness), part, context)['assessed_label'], 'contradict')
        for text in (context.replace('Harbor', 'Other'), context.replace('15', '60'),
                     context.replace('for validation', 'for testing'),
                     context.replace('Of these', 'Possibly, of these')):
            self.assertIsNone(rules.allocation_witness(part, text))


if __name__ == '__main__':
    unittest.main()
