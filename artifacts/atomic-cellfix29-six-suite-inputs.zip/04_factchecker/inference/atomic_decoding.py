"""Schema-constrained decoding for the isolated atomic candidate, not serving."""
from __future__ import annotations

from contextlib import contextmanager
from importlib.metadata import version
import hashlib
import json
import re
import time

from .atomic_verifier import (DECOMPOSE_PROMPT, ASSESS_PROMPT, ASSESSMENT_LIMITS,
                              CaseDeadlineExceeded, _quantifier, scope_clauses)
from .numeric_verifier import numeric_requirements, _operand
from .judge import TransformersJSONBackend

DECODER = {'engine': 'lm-format-enforcer', 'version': '0.11.3',
           'interegular': '0.3.3', 'policy': 'atomic-schema-decoding-v5',
           'source_enum_max_words': 80, 'strict_field_order': True,
           'max_consecutive_whitespaces': 4, 'num_beams': 1,
           'repetition_penalty': 1.05, 'assessment_limits': ASSESSMENT_LIMITS,
           'deadline_policy': 'absolute_monotonic_per_decode_step'}


def obj(properties):
    return {'type': 'object', 'properties': properties, 'required': list(properties),
            'additionalProperties': False}


def array(items, *, minimum=0, maximum=16):
    return {'type': 'array', 'items': items, 'minItems': minimum, 'maxItems': maximum}


TEXT = {'type': 'string'}


def claim_spans(claim):
    words = list(re.finditer(r'\S+', claim))
    if not words or len(words) > DECODER['source_enum_max_words']:
        raise ValueError('Claim exceeds the frozen constrained-decoder word limit')
    spans = {claim}
    for word in words:
        for last in words:
            if last.end() <= word.start():
                continue
            value = claim[word.start():last.end()]
            spans.add(value)
            trimmed = value.rstrip(',.;:')
            if trimmed:
                spans.add(trimmed)
    return sorted(spans)


def decomposition_schema(claim):
    spans = claim_spans(claim)
    from .cellfix14_decomposition import conjunctions,expected_quantifier
    from .cellfix22_scope import full_clause_span
    conjunction = bool(conjunctions(claim))
    unique = [v for v in spans if claim.find(v, claim.find(v) + 1) == -1] if conjunction else [claim]
    quantifier = _quantifier(claim)
    quantifiers = [quantifier] if quantifier is not None else ['atomic', 'all', 'some', 'none']
    alternatives = []
    for clause in scope_clauses(claim):
        source = claim[clause['start']:clause['end']]
        quotes = [v for v in unique if clause['start'] <= claim.find(v)
                  and claim.find(v) + len(v) <= clause['end'] and full_clause_span(v, source)]
        clause_quantifier=expected_quantifier(claim,claim[clause['start']:clause['end']],_quantifier)
        scope_values = {'entity': spans, 'metric': [clause['required_metric']] if clause['required_metric'] else spans,
                        'time': clause['time'] or [''],
                        'condition': ([s for s in spans if all(v in s for v in clause['condition'])]
                                      if clause['condition'] else [''] + [s for s in spans
                                          if s in clause['source'] and not re.search(r'\b(?:after|before|during)\b', s, re.I)])}
        scope_values.update(clause['roles'])
        if not quotes or any(not values for values in scope_values.values()):
            raise ValueError('unsupported_scope_structure')
        alternatives.append(obj({'quote': {'type': 'string', 'enum': quotes},
            'quantifier': {'type': 'string', 'enum': [clause_quantifier]},
            'scope': obj({key: {'type': 'string', 'enum': values} for key, values in scope_values.items()})}))
    part = alternatives[0] if len(alternatives) == 1 else {'anyOf': alternatives}
    return obj({'parts': array(part, minimum=1, maximum=12 if conjunction else 1), 'unresolved': array(TEXT)})


def bounded_text(maximum):
    return {'type': 'string', 'minLength': 1, 'maxLength': maximum}


def source_members(context):
    words = list(re.finditer(r'\S+', context))
    return sorted({context[first.start():last.end()].rstrip(',.;:')
                   for i, first in enumerate(words) for last in words[i:i + 8]
                   if last.end() - first.start() <= ASSESSMENT_LIMITS['member_chars']
                   and context[first.start():last.end()].rstrip(',.;:')})


def evidence_passages(context):
    """Exact whole/adjacent sentences; bounded windows for long sentences."""
    maximum = ASSESSMENT_LIMITS['quote_chars']
    bounds = [0] + [m.end() for m in re.finditer(r'[.!?](?=\s|$)|\n', context)] + [len(context)]
    from .cellfix22_relations import column_passages
    passages = {p for p in column_passages(context) if len(p) <= maximum}
    for i, start in enumerate(bounds[:-1]):
        sentence = context[start:bounds[i + 1]].strip()
        if len(sentence) > maximum:
            words = list(re.finditer(r'\S+', sentence))
            for j, first in enumerate(words):
                ends = [last.end() for last in words[j:] if last.end() - first.start() <= maximum]
                if ends:
                    passages.add(sentence[first.start():max(ends)])
        for end in bounds[i + 1:]:
            value = context[start:end].strip()
            if len(value) > maximum:
                break
            if value:
                passages.add(value)
    return sorted(passages)


def operand_schema(source):
    alternatives = []
    seen = set()
    for requirement in numeric_requirements(source):
        value = {key: requirement[key] for key in ('value', 'unit', 'quote')}
        identity = tuple(value.values())
        if identity in seen:
            continue
        try:
            _operand(value, source)
        except ValueError:
            continue
        seen.add(identity)
        alternatives.append(obj({key: {'type': 'string', 'enum': [text]} for key, text in value.items()}))
    return alternatives


def assessment_schema(claim, part, context):
    if len(context.split()) > ASSESSMENT_LIMITS['context_words']:
        raise ValueError('unsupported_assessment_context')
    limits = ASSESSMENT_LIMITS
    passages, members = evidence_passages(context), source_members(context)
    quote = {'type': 'string', 'enum': passages} if passages else bounded_text(limits['quote_chars'])
    member = {'type': 'string', 'enum': members} if members else bounded_text(limits['member_chars'])
    evidence = array(quote, maximum=limits['quotes_per_record'] if passages else 0)
    left = operand_schema(part['quote']) + operand_schema(context)
    right = operand_schema(context)
    # No finite source operands means no executable numerical proof, never invented values.
    empty_operand = obj({'value': {'type': 'string', 'enum': ['0']},
                         'unit': {'type': 'string', 'enum': ['']}, 'quote': quote})
    left_schema = {'anyOf': left} if left else empty_operand
    right_schema = {'anyOf': right} if right else empty_operand
    numeric = obj({'kind': {'type': 'string', 'enum': ['value', 'change']},
                   'source_quote': quote, 'left': left_schema, 'right': right_schema})
    numeric_schema = {'anyOf': [{'type': 'null'}, numeric, array(numeric, minimum=1)]} if left and right else {'type': 'null'}
    observation = obj({'member': member, 'truth': {'type': 'string', 'enum': ['true', 'false', 'unknown']},
                       'quotes': evidence, 'explanation': bounded_text(limits['explanation_chars']),
                       'numeric': numeric_schema})
    return obj({'scope_match': {'type': 'string', 'enum': ['matched', 'mismatched', 'unknown']},
                'coverage': obj({'complete': {'type': 'boolean'}, 'members': array(member, maximum=16 if members else 0), 'quotes': evidence}),
                'observations': array(observation, maximum=16 if members else 0),
                'missing_information': array(bounded_text(limits['missing_chars']), maximum=limits['missing_items']),
                'explanation': bounded_text(limits['explanation_chars'])})


def schema_for(messages):
    payload = json.loads(messages[1]['content'])
    if messages[0]['content'] == DECOMPOSE_PROMPT and set(payload) == {'claim'}:
        return decomposition_schema(payload['claim']), payload['claim']
    if messages[0]['content'] == ASSESS_PROMPT and set(payload) == {'claim', 'part', 'context'}:
        return assessment_schema(payload['claim'], payload['part'], payload['context']), payload['claim'] + payload['context']
    raise ValueError('Unsupported constrained atomic request')


def schema_sha256(schema):
    return hashlib.sha256(json.dumps(schema, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


class DeadlineStop:
    def __init__(self, deadline):
        self.deadline = deadline

    def __call__(self, input_ids, scores, **kwargs):
        return time.monotonic() >= self.deadline


class ConstrainedAtomicBackend(TransformersJSONBackend):
    def __init__(self, model, tokenizer):
        from lmformatenforcer import TokenEnforcerTokenizerData
        if version('lm-format-enforcer') != DECODER['version'] or version('interegular') != DECODER['interegular']:
            raise ValueError('Structured decoder dependency version differs from frozen policy')
        super().__init__(model, tokenizer)
        self._case_deadline = None
        # Build the 150k-token prefix tree once per loaded tokenizer, not per call.
        # LMFE 0.11.3's convenience adapter imports tokenization_utils, removed
        # in Transformers 5. Use its public core and the documented HF callback.
        zero = tokenizer.encode('0')[-1]
        specials = set(tokenizer.all_special_ids)
        vocabulary = []
        for token_id in range(len(tokenizer)):
            if token_id not in specials:
                after_zero = tokenizer.decode([zero, token_id])[1:]
                alone = tokenizer.decode([token_id])
                vocabulary.append((token_id, after_zero, len(after_zero) > len(alone)))
        self.tokenizer_data = TokenEnforcerTokenizerData(vocabulary,
            lambda ids: tokenizer.decode(ids).rstrip('\ufffd'), tokenizer.eos_token_id, False, len(tokenizer))

    @contextmanager
    def generation_deadline(self, deadline):
        previous, self._case_deadline = self._case_deadline, deadline
        try:
            from .cellfix14_runtime import decode_request
            with decode_request(deadline):
                yield True
        finally:
            self._case_deadline = previous

    def generation_options(self, messages):
        from lmformatenforcer import JsonSchemaParser, CharacterLevelParserConfig, TokenEnforcer
        if self._case_deadline is not None and time.monotonic() >= self._case_deadline:
            raise CaseDeadlineExceeded()
        from .cellfix14_runtime import decode_request
        with decode_request(self._case_deadline):
            schema, source = schema_for(messages)
        config = CharacterLevelParserConfig()
        config.force_json_field_order = DECODER['strict_field_order']
        config.max_consecutive_whitespaces = DECODER['max_consecutive_whitespaces']
        config.alphabet += ''.join(sorted(set(source) - set(config.alphabet)))
        from .decoder_parser import CheckedParser, alphabet_tree
        enforcer = TokenEnforcer(self.tokenizer_data, CheckedParser(JsonSchemaParser(schema, config=config), filtered_cache=True))
        enforcer.tokenizer_tree = alphabet_tree(enforcer.tokenizer_tree, config)
        # TokenEnforcer replaces the parser config while initializing its alphabet.
        # Reapply the prospective limits rather than inheriting environment flags.
        enforcer.root_parser.config = config
        def callback(batch_id, input_ids):
            from .cellfix14_runtime import decode_request
            prompt=getattr(self,'_decode_prompt_length',None)
            if prompt is not None:self._decode_generated_lower_bound=max(0,len(input_ids)-prompt)
            with decode_request(self._case_deadline):
                return enforcer.get_allowed_tokens(input_ids.tolist()).allowed_tokens
        self.decoding_metadata = {'structured_decoder': DECODER, 'schema_sha256': schema_sha256(schema)}
        options = {'prefix_allowed_tokens_fn': callback, 'num_beams': DECODER['num_beams'],
                   'repetition_penalty': DECODER['repetition_penalty']}
        if self._case_deadline is not None:
            if time.monotonic() >= self._case_deadline:
                raise CaseDeadlineExceeded()
            from transformers import StoppingCriteriaList
            options['stopping_criteria'] = StoppingCriteriaList([DeadlineStop(self._case_deadline)])
            self.decoding_metadata['deadline_stop_enabled'] = True
        return options


def constrained_loader(loader):
    @contextmanager
    def load(kind, criteria):
        if criteria['structured_decoder'] != DECODER:
            raise ValueError('Frozen decoder policy changed')
        with loader(kind, criteria) as (backend, metadata):
            constrained = ConstrainedAtomicBackend(backend.model, backend.tokenizer)
            try:
                yield constrained, {**metadata, 'structured_decoder': DECODER}
            finally:
                constrained.model = None
    return load


from .numeric_verifier import direction
DECODER.update(policy='atomic-schema-decoding-v5-cellfix1', max_atomic_observations=2,
               numeric_kind_source_binding=True, assessment_repair='regenerate_without_failed_draft')
_v8_schema = assessment_schema
def assessment_schema(claim, part, context):
    schema = _v8_schema(claim, part, context)
    properties = schema['properties']
    observation = properties['observations']['items']
    if part['quantifier'] == 'atomic':
        properties['observations']['maxItems'] = 2 if source_members(context) else 0
        properties['coverage']['properties']['members']['maxItems'] = 2 if source_members(context) else 0
    quote = observation['properties']['quotes']['items']
    requested = operand_schema(part['quote'])
    variants = []
    for passage in evidence_passages(context):
        observed = operand_schema(passage)
        if not observed:
            continue
        def check(kind, left):
            return obj({'kind':{'type':'string','enum':[kind]},
                        'source_quote':{'type':'string','enum':[passage]},
                        'left':{'anyOf':left}, 'right':{'anyOf':observed}})
        if requested:
            variants.append(check('value', requested))
        ordered = re.search(r'\bfrom\b.*?\bto\b|\bbefore\b.*?\band\b.*?\bafter\b', passage, re.I)
        if not requested and direction(part['quote']) and ordered:
            variants.append(check('change', observed))
    if variants:
        numeric = variants[0] if len(variants) == 1 else {'anyOf':variants}
        maximum = max(1, len(numeric_requirements(part['quote'])))
        observation['properties']['numeric'] = {'anyOf':[{'type':'null'}, numeric, array(numeric, minimum=1, maximum=maximum)]}
    else:
        observation['properties']['numeric'] = {'type':'null'}
    return schema


from copy import deepcopy
from .atomic_verifier import numeric_proof_required
import lmformatenforcer.jsonschemaparser as _js

# Compatibility fix for boolean const in pinned LMFE 0.11.3.
# The JSON values and canonical validator remain unchanged.
if not getattr(_js.get_parser, '_atomic_bool_const_fix', False):
    def _bool_const_parser(state, schema, _previous=_js.get_parser):
        const = (schema.extras or {}).get('const') if schema is not None else None
        if type(const) is bool:
            return _js.StringParsingState(
                state, ['true' if const else 'false'], False, False
            )
        return _previous(state, schema)
    _bool_const_parser._atomic_bool_const_fix = True
    _js.get_parser = _bool_const_parser

DECODER.update(
    policy='atomic-schema-decoding-v5-cellfix2',
    conditional_numeric_truth=True,
    conditional_evidence=True,
    atomic_population_coverage='not_required',
    boolean_const_compat=True,
)
_cellfix1_schema = assessment_schema

def assessment_schema(claim, part, context):
    schema = deepcopy(_cellfix1_schema(claim, part, context))
    props = schema['properties']
    cov = props['coverage']['properties']

    if part['quantifier'] == 'atomic':
        props['coverage'] = obj({
            'complete': {'const': False},
            'members': array(cov['members']['items'], maximum=0),
            'quotes': array(cov['quotes']['items'], maximum=0),
        })
    else:
        incomplete = deepcopy(cov)
        incomplete['complete'] = {'const': False}
        complete = deepcopy(cov)
        complete['complete'] = {'const': True}
        complete['members']['minItems'] = 1
        complete['quotes']['minItems'] = 1
        props['coverage'] = {
            'anyOf': [obj(incomplete), obj(complete)]
        }

    original = props['observations']['items']
    numeric = original['properties']['numeric']
    choices = numeric.get('anyOf', [numeric])
    nonnull = [s for s in choices if s.get('type') != 'null']
    need_numeric = numeric_proof_required(part, [context])

    unknown = deepcopy(original)
    unknown['properties']['truth']['enum'] = ['unknown']
    unknown['properties']['numeric'] = {'type': 'null'}
    branches = [unknown]

    for truth in ('true', 'false'):
        if need_numeric and not nonnull:
            continue  # No grounded operands; unknown remains representable.

        variant = deepcopy(original)
        variant['properties']['truth']['enum'] = [truth]
        variant['properties']['quotes']['minItems'] = 1

        if need_numeric:
            allowed = deepcopy(nonnull)
            count = len(numeric_requirements(part['quote']))
            if truth == 'true' and count > 1:
                allowed = [
                    s for s in allowed if s.get('type') == 'array'
                ]
                for item in allowed:
                    item['minItems'] = count
            variant['properties']['numeric'] = (
                allowed[0] if len(allowed) == 1 else {'anyOf': allowed}
            )

        branches.append(variant)

    props['observations']['items'] = {'anyOf': branches}
    props['observations']['minItems'] = 1 if source_members(context) else 0
    return schema


from .atomic_verifier import target_members, target_entity, numeric_metric_matches
DECODER.update(policy='atomic-schema-decoding-v5-cellfix3',
    target_observation_binding=True, per_requirement_source_binding=True,
    measurement_negation_scope=True)
_cellfix2_schema = assessment_schema

def assessment_schema(claim, part, context):
    schema = _cellfix2_schema(claim, part, context)
    props = schema['properties']
    targets = target_members(part, context) if part['quantifier']=='atomic' else []
    if targets:
        props['observations']['maxItems'] = 1
    choices = []
    for passage in evidence_passages(context):
        for left in operand_schema(part['quote']):
            lhs = {k:v['enum'][0] for k,v in left['properties'].items()}
            for right in operand_schema(passage):
                rhs = {k:v['enum'][0] for k,v in right['properties'].items()}
                record = dict(kind='value',source_quote=passage,left=lhs,right=rhs)
                if numeric_metric_matches(part,record,numeric_requirements(part['quote'])):
                    choices.append(obj({'kind':{'type':'string','enum':['value']},
                        'source_quote':{'type':'string','enum':[passage]},
                        'left':left,'right':right}))
    count = len(numeric_requirements(part['quote']))
    for branch in props['observations']['items']['anyOf']:
        obs = branch['properties']
        if targets:
            obs['member'] = {'type':'string','enum':targets}
        truth = obs['truth']['enum'][0]
        if count and truth != 'unknown':
            if not choices:
                branch['_remove'] = True
                continue
            record = choices[0] if len(choices)==1 else {'anyOf':choices}
            checks = array(record,minimum=count if truth=='true' else 1,maximum=count)
            obs['numeric'] = {'anyOf':[record,checks]} if count==1 else checks
    branches = [b for b in props['observations']['items']['anyOf'] if not b.pop('_remove',False)]
    if part['quantifier']=='atomic' and target_entity(part) and not targets:
        branches = [b for b in branches if b['properties']['truth']['enum']==['unknown']]
    props['observations']['items']['anyOf'] = branches
    return schema

DECODER.update(policy='atomic-schema-decoding-v5-cellfix4', numeric_citation_ledger='verified_source_quote_union')

DECODER.update(policy='atomic-schema-decoding-v5-cellfix5', named_property_source_binding='active_change_verb_and_known_measurement_head')


# Cellfix6: use the same conservative passage and ordered-measurement checks.
from .assessment_rules import passage_issue
from .numeric_verifier import check_numeric
DECODER.update(policy='atomic-schema-decoding-v5-cellfix6',
    assessment_evidence_guards='explicit_absence_and_scope',
    ordered_metric_measurement_binding=True)
_cellfix5_schema = assessment_schema

def assessment_schema(claim, part, context):
    schema = _cellfix5_schema(claim, part, context)
    props = schema['properties']
    changes = []
    if not numeric_requirements(part['quote']) and direction(part['quote']):
        for passage in evidence_passages(context):
            operands = operand_schema(passage)
            for left in operands:
                for right in operands:
                    record = dict(kind='change', source_quote=passage,
                        left={k:v['enum'][0] for k,v in left['properties'].items()},
                        right={k:v['enum'][0] for k,v in right['properties'].items()})
                    result = check_numeric(record, part['quote'], context, metric=part['scope']['metric'])
                    if result['truth'] != 'unknown' and numeric_metric_matches(part,record,[]):
                        changes.append(obj({'kind':{'type':'string','enum':['change']},
                            'source_quote':{'type':'string','enum':[passage]},'left':left,'right':right}))
    kept = []
    for branch in props['observations']['items']['anyOf']:
        obs = branch['properties']
        if obs['truth']['enum'] == ['unknown']:
            kept.append(branch)
            continue
        quotes = [p for p in obs['quotes']['items'].get('enum',[]) if not passage_issue(part,p)]
        if not quotes:
            continue
        obs['quotes']['items'] = {'type':'string','enum':quotes}
        if not numeric_requirements(part['quote']) and direction(part['quote']):
            # Qualitative passages must stay representable even if unrelated
            # numerical evidence elsewhere in context cannot bind this metric.
            choices = ([{'type':'null'}] if any(not numeric_proof_required(part,[p]) for p in quotes) else [])
            if changes:
                record = changes[0] if len(changes)==1 else {'anyOf':changes}
                choices += [record,array(record,minimum=1,maximum=1)]
            if not choices:
                continue
            obs['numeric'] = {'anyOf':choices}
        kept.append(branch)
    props['observations']['items']['anyOf'] = kept
    return schema


# Cellfix7 uses supported object properties, not unsupported tuple/uniqueItems.
from .assessment_decisions import decision_evidence, numeric_choices
DECODER.update(policy='atomic-schema-decoding-v5-cellfix7',
    requirement_ledger='keyed_q_index', decision_evidence='finite_shared_source_rules')
_cellfix6_schema = assessment_schema

def assessment_schema(claim, part, context):
    schema = _cellfix6_schema(claim,part,context)
    props = schema['properties']
    count = len(numeric_requirements(part['quote']))
    evidence = decision_evidence(part,context)
    if evidence:
        props['scope_match'] = {'type':'string','enum':['matched']}
    kept = []
    groups = numeric_choices(part,context) if count>1 else []
    for branch in props['observations']['items']['anyOf']:
        obs = branch['properties']
        truth = obs['truth']['enum'][0]
        if evidence and truth != evidence['truth']:
            continue
        if evidence and not evidence['numeric']:
            obs['member'] = {'type':'string','enum':evidence['members']}
            # Use whole source passages so exact sentence punctuation is preserved.
            quotes = [q for q in evidence_passages(context) if any(c in q for c in evidence['quotes'])]
            obs['quotes']['items'] = {'type':'string','enum':quotes}
        if count>1 and truth!='unknown':
            fields = {}
            false_witnesses = {}
            for index,group in enumerate(groups):
                choices = [obj({k:{'type':'string','enum':[v]} if isinstance(v,str) else
                    obj({field:{'type':'string','enum':[value]} for field,value in v.items()})
                    for k,v in record.items()}) for record,value_truth in group if truth=='false' or value_truth=='true']
                false_witnesses['q'+str(index)] = [obj({k:{'type':'string','enum':[v]} if isinstance(v,str) else
                    obj({field:{'type':'string','enum':[value]} for field,value in v.items()})
                    for k,v in record.items()}) for record,value_truth in group if value_truth=='false']
                if truth=='false': choices.append({'type':'null'})
                if not choices: break
                fields['q'+str(index)] = choices[0] if len(choices)==1 else {'anyOf':choices}
            if len(fields)!=count: continue
            if truth=='false':
                alternatives=[]
                for key,witnesses in false_witnesses.items():
                    if witnesses:
                        required = witnesses[0] if len(witnesses)==1 else {'anyOf':witnesses}
                        alternatives.append(obj({**fields,key:required}))
                if not alternatives:continue
                obs['numeric'] = alternatives[0] if len(alternatives)==1 else {'anyOf':alternatives}
            else:
                obs['numeric'] = obj(fields)
        kept.append(branch)
    if not kept:
        raise ValueError('unrepresentable_assessment_evidence')
    props['observations']['items']['anyOf'] = kept
    return schema


DECODER.update(policy='atomic-schema-decoding-v5-cellfix8',
    json_freetext_policy='character_checked_request_alphabet_cache',
    scoped_missing_information='reject_when_finite_witness_is_decisive')
_cellfix7_final_schema = assessment_schema

def assessment_schema(claim, part, context):
    schema = _cellfix7_final_schema(claim, part, context)
    if decision_evidence(part,context):
        schema['properties']['missing_information']['maxItems'] = 0
    return schema


from .assessment_evidence import citation_issue, population_witness
DECODER.update(policy='atomic-schema-decoding-v5-cellfix9',
    member_predicate_binding='local_clause_no_unrelated_fallback',
    population_coverage='explicit_closed_collective_witness',
    missing_information_scope='part_metric_and_source_reference')
_cellfix8_final_schema = assessment_schema

def assessment_schema(claim, part, context):
    schema = _cellfix8_final_schema(claim,part,context)
    props = schema['properties']
    population = population_witness(part,context)
    if population:
        truth = population['truth']
        complete = (part['quantifier']=='all' and truth=='true'
                    or part['quantifier'] in ('some','none') and truth=='false')
        member = {'type':'string','enum':population['members']}
        proof = {'type':'string','enum':population['quotes']}
        props['coverage'] = obj({'complete':{'const':bool(complete)},
            'members':array(member,minimum=1 if complete else 0,maximum=1 if complete else 0),
            'quotes':array(proof,minimum=1 if complete else 0,maximum=1 if complete else 0)})
        obs = obj({'member':member,'truth':{'type':'string','enum':[truth]},
            'quotes':array(proof,minimum=1,maximum=1),
            'explanation':bounded_text(ASSESSMENT_LIMITS['explanation_chars']),
            'numeric':{'type':'null'}})
        props['observations'] = array(obs,minimum=1,maximum=1)
        props['missing_information']['maxItems'] = 0
        return schema
    kept = []
    for branch in props['observations']['items']['anyOf']:
        obs = branch['properties']
        if obs['truth']['enum']==['unknown']:
            kept.append(branch)
            continue
        # Bind choices jointly, not independent member/quote enums. Otherwise
        # a legal member could still select another member's legal passage.
        def numeric_passages(value):
            if not isinstance(value,dict):
                return set()
            found = set(value.get('properties',{}).get('source_quote',{}).get('enum',[]))
            for item in value.values():
                if isinstance(item,dict):
                    found.update(numeric_passages(item))
                elif isinstance(item,list):
                    for sub in item:
                        found.update(numeric_passages(sub))
            return found
        ledger_quotes = numeric_passages(obs['numeric'])
        for member in obs['member'].get('enum',[]):
            quotes = [q for q in obs['quotes']['items'].get('enum',[])
                      if q in ledger_quotes or not citation_issue(part,member,[q],obs['truth']['enum'][0])]
            if not quotes:
                continue
            fixed = deepcopy(branch)
            fixed['properties']['member'] = {'type':'string','enum':[member]}
            fixed['properties']['quotes']['items'] = {'type':'string','enum':quotes}
            kept.append(fixed)
    if not kept:
        raise ValueError('unrepresentable_assessment_evidence')
    props['observations']['items']['anyOf'] = kept
    return schema



from .assessment_reporting import constrain_schema
DECODER.update(policy='atomic-schema-decoding-v5-cellfix10',
    prose='validated_ledger_renderer_v1',missing_information_scope='part_bound_reason_code')
_cellfix9_final_schema = assessment_schema
def assessment_schema(claim, part, context):
    return constrain_schema(_cellfix9_final_schema(claim,part,context),part,context)



from .assessment_focus import constrain_focus
DECODER.update(policy='atomic-schema-decoding-v5-cellfix11',
    unknown_citation='direct_part_absence_when_unambiguous',
    unknown_observation_scope='local_member_clause_including_unknown')
_cellfix10_final_schema = assessment_schema
def assessment_schema(claim, part, context):
    return constrain_focus(_cellfix10_final_schema(claim,part,context),part,context)


DECODER.update(policy='atomic-schema-decoding-v5-cellfix12', unknown_binding='member_quote_joint', absence_truth='unknown_before_polarity')


DECODER.update(policy='atomic-schema-decoding-v5-cellfix13', member_identity='source_nominal_referents_v1', unresolved_target='empty_unknown_ledger')


from .cellfix14_generation import generate_json
ConstrainedAtomicBackend.generate_json=generate_json
DECODER.update(policy='atomic-schema-decoding-v5-cellfix14',quantity_binding='compound_measurements_v1',target_binding='explicit_source_references_v1',deadline_policy='request_cache_signal_and_worker_watchdog')

DECODER.update(policy='atomic-schema-decoding-v5-cellfix15',member_local_absence='shared_focus_guard_v1')

_cf15_decomposition_schema=decomposition_schema
from .cellfix16_rules import decomposition_schema as joint_decomposition
def decomposition_schema(claim):
    return joint_decomposition(claim,_cf15_decomposition_schema)
DECODER.update(policy='atomic-schema-decoding-v5-cellfix16', explicit_relations='shared_finite_witness', population_subject='pre_or_postposed_quantifier')

_cf15_assessment_schema=assessment_schema
from .cellfix16_rules import coverage_schema,count_witness,count_schema
def assessment_schema(claim,part,context):
    witness=count_witness(part,context)
    if witness:return count_schema(witness)
    return coverage_schema(_cf15_assessment_schema(claim,part,context),part,context)

_cf16_final_assessment_schema=assessment_schema
from .cellfix17_coverage import bind_coverage
def assessment_schema(claim,part,context):
    witness=count_witness(part,context)
    if witness:return count_schema(witness)
    return bind_coverage(_cf15_assessment_schema(claim,part,context),context)
DECODER.update(policy='atomic-schema-decoding-v5-cellfix17',coverage_members='exact_source_observation_spans',empty_coverage_enum='never_unconstrained')

_cf17_final_assessment_schema = assessment_schema
from .cellfix18_rules import bound_member_arrays

def assessment_schema(claim, part, context):
    schema = bound_member_arrays(_cf17_final_assessment_schema(claim, part, context))
    if part['quantifier'] == 'atomic':
        return schema
    from .assessment_evidence import _population, population_witness, universal_coverage
    population = _population(part, context)
    witness = population_witness(part, context)
    props = schema['properties']
    observations = props['observations']['items']
    members = {member for branch in observations.get('anyOf', [observations])
               for member in branch['properties']['member'].get('enum', [])}
    if not (population and population['names'] or witness and witness['complete']
            or any(universal_coverage(part, [m], [context]) for m in members)):
        props['coverage'] = obj({'complete': {'const': False},
                                 'members': array({'type': 'string'}, maximum=0),
                                 'quotes': array({'type': 'string'}, maximum=0)})
    return schema
DECODER.update(policy='atomic-schema-decoding-v5-cellfix18', population_cache='request_local', member_arrays='bounded_by_distinct_source_members', allocation_counts='explicit_total_subset_role')

DECODER.update(policy='atomic-schema-decoding-v5-cellfix19', subject_reference='non_function_word', exclusive_subset='actor_source_bound')

DECODER.update(policy='atomic-schema-decoding-v5-cellfix20', relational_predicate='full_source_span', comparative_citation='same_target_comparator_condition', empirical_claim='explicit_proof_required')

DECODER.update(policy='atomic-schema-decoding-v5-cellfix21', coordination='argument_lists_preserved', comparative_measurement='same_metric_and_comparator', existence_polarity='source_bound')
DECODER.update(policy='atomic-schema-decoding-v5-cellfix24', decomposition='subject_scoped_quantifiers',
    assessment='source_local_relation_witnesses', population_closure='source_proof_required')

_cellfix25_assessment_schema = assessment_schema


def assessment_schema(claim, part, context):
    from .cellfix26_evidence import literal_schema, source_ledger
    witness = source_ledger(part, context)
    if witness is not None:
        return literal_schema(witness[0])
    return _cellfix25_assessment_schema(claim, part, context)


DECODER.update(policy='atomic-schema-decoding-v5-cellfix29', explicit_report_ledger='scoped_report_forms_v3',
               literal_evidence_arrays='complete_source_order_v1')
