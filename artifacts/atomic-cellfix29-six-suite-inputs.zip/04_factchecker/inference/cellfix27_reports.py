"""Cited outcomes for explicit ranges, procedural rules and category lists."""
from decimal import Decimal
import re

from .cellfix26_evidence import _NUM, _TOKEN, _sentences, _same

_RANGE = re.compile(
    rf'(?:Every|Each) (?P<entity>[\w -]+?) (?P<condition>in (?P<name>{_TOKEN})) '
    rf'(?P<metric>has more than (?P<number>{_NUM}) (?P<unit>{_TOKEN}))', re.I)
_CORPUS = re.compile(
    rf'(?P<entity>[A-Z][A-Z0-9]+) (?P<metric>describes (?P<number>{_NUM}) (?P<unit>[\w -]+? tasks))')
_TOTAL = re.compile(rf'and (?P<metric>contains (?P<number>{_NUM}) (?P<unit>[\w -]+? narratives))', re.I)
_GUARANTEE = re.compile(
    r'(?P<entity>A matching POS-tag sequence) '
    r'(?P<metric>guarantees that the evaluated sentence is grammatically correct)', re.I)
_PRIORITY = re.compile(
    r'(?=.*\btext normalization\b)(?:For )?(?P<condition>(?:Among )?matching '
    r'(?:text normalization )?patterns of (?:equal|the same) length), '
    r'(?P<entity>the (?:text normalization )?system) '
    r'(?P<metric>chooses the (?P<direction>lower|higher)-priority pattern)', re.I)
_RESOURCES = re.compile(
    rf'(?P<entity>The proposed (?P<task>{_TOKEN}) approach) (?P<metric>used external resources) '
    rf'(?P<condition>in its evaluation on (?:the )?(?P<dataset>{_TOKEN}) dataset)', re.I)
_PROCEDURE = re.compile(
    r'The (?P<condition>grammatical evaluation) (?P<metric>searches the corpus for a matching POS-tag sequence) '
    r'for each (?P<entity>speech sentence)', re.I)
_TAXONOMY = re.compile(
    rf'(?P<entity>The (?P<platform>{_TOKEN}) speech-act taxonomy) '
    rf'(?P<metric>(?:includes both (?P<first>{_TOKEN}) and (?P<second>{_TOKEN})'
    rf'|excludes the (?P<excluded>{_TOKEN}) category))', re.I)
_SUPERVISION = re.compile(
    rf'(?P<entity>The parser variants) (?P<metric>used no supervision) '
    rf'(?P<condition>from the (?P<language>{_TOKEN}) portion of (?P<dataset>[\w -]+))', re.I)
_TRAIN_COUNT = re.compile(
    rf'(?P<entity>The authors) (?P<metric>used {_NUM} (?P<unit>{_TOKEN} training sentences)'
    r' to supervise the additional parser variants)', re.I)
_CORPUS_SIZE = re.compile(
    rf'(?P<entity>The corpus searched) (?P<time>during the grammatical evaluation) '
    rf'(?P<metric>contained {_NUM} sentences)', re.I)
_CORRECT_RATE = re.compile(
    rf'(?P<entity>(?:The )?rule-based model) (?P<metric>handled {_NUM}% of (?P<group>{_TOKEN}) cases correctly)', re.I)
_UNIT_BLEU = re.compile(
    rf'(?:The )?(?P<unit>{_TOKEN})-based translation system achieved a BLEU score of {_NUM}', re.I)
_CATEGORY_F1 = re.compile(
    rf'(?:The )?speech-act classifier attained an F1 score of {_NUM} on (?P<category>{_TOKEN}) tweets', re.I)
_NER_RECALL = re.compile(
    rf'(?:The )?proposed (?P<task>{_TOKEN}) approach achieved an average recall of {_NUM} '
    rf'on (?:the )?(?P<dataset>{_TOKEN}) dataset', re.I)
_FORMS = (_RANGE, _CORPUS, _TOTAL, _GUARANTEE, _PRIORITY, _RESOURCES,
          _PROCEDURE, _TAXONOMY, _SUPERVISION, _TRAIN_COUNT, _CORPUS_SIZE, _CORRECT_RATE)
_AMBIGUOUS_SPEED = re.compile(r'\b(?:became|got|grew) (?:faster|slower)\b', re.I)
_RESPONSE_TIME = re.compile(
    r'\b(?:response (?:times?|latency)|latency|round[- ]trip time|milliseconds?|ms|seconds?)\b', re.I)


def claim_form(quote):
    for form in _FORMS:
        match = form.fullmatch(quote.strip().rstrip('.'))
        if match:
            return form, match
    return None, None


def ambiguous_response_time(part, context):
    return (part['scope']['metric'].casefold() == 'response time'
            and bool(_AMBIGUOUS_SPEED.search(context))
            and not _RESPONSE_TIME.search(context))


def _pos_search(sentences):
    for first, second in zip(sentences, sentences[1:]):
        if (re.fullmatch(r'For evaluating the grammatical correctness we identify for each sentence of the speech its POS tags\.', first, re.I)
                and re.fullmatch(r'Then we check all sentences of the entire corpus whether one has the same sequence of POS tags\.', second, re.I)):
            yield first, second


def missing_quantity_reason(part, context):
    """Prefer the missing measurement when the requested target is already anchored."""
    from .cellfix26_evidence import _COUNT, _SECTION, claim_form as prior_form
    form, match = claim_form(part['quote'])
    if form is _TRAIN_COUNT:
        english = re.escape(match['unit'].split()[0])
        linked = re.search(r'\bvariants which additionally incorporate supervision from (?:the )?'
                           rf'{english} portion of the dataset\b', context, re.I)
        if linked and not re.search(r'\b(?:sentences?|sentence count|training examples)\b', context, re.I):
            return 'measurement_unreported'
    if form is _CORPUS_SIZE:
        if (len(list(_pos_search(_sentences(context)))) == 1
                and not re.search(r'\d|\b(?:hundred|thousand|million)\b', context, re.I)):
            return 'contained_total_unresolved'
    form, match = prior_form(part['quote'])
    if form is _COUNT and _same(match['unit'], 'tokens'):
        sections = list(_SECTION.finditer(context))
        matches = [i for i, section in enumerate(sections) if _same(section['dataset'], match['dataset'])]
        if len(matches) == 1:
            i = matches[0]
            end = sections[i + 1].start() if i + 1 < len(sections) else len(context)
            passage = context[sections[i].end():end]
            if re.search(r'\b(?:train|dev|test)/', passage, re.I) and not re.search(r'\btokens?\b', passage, re.I):
                return 'contained_total_unresolved'
    return None


def ner_reports(task, dataset, sentences):
    """One local author-owned evaluation, with the dataset in the result sentence."""
    owners = [i for i, sentence in enumerate(sentences) if re.match(
        rf'In this paper we presented a novel architecture for {re.escape(task)}\b', sentence, re.I)]
    if len(owners) != 1:
        return
    owner = owners[0]
    for quote in sentences[owner + 1:owner + 3]:
        if re.match(rf'To address this issue we have presented and evaluated a novel approach '
                    rf'using the {re.escape(dataset)} dataset,', quote, re.I):
            yield sentences[owner], quote


def taxonomy_reports(platform, sentences):
    for quote in sentences:
        found = re.fullmatch(
            rf'Using [^,]+, we established a list of \w+ speech act categories that are commonly seen on '
            rf'{re.escape(platform)}: (?P<items>[\w, -]+)\.', quote, re.I)
        if found:
            yield quote, {item.strip().casefold() for item in re.split(r',|\band\b', found['items'], flags=re.I)}


def missing_measurement(part, context):
    """Name a requested result when its source scope is anchored but the metric is absent."""
    from .cellfix26_evidence import training_unit_reports

    claim = part['quote'].strip().rstrip('.')
    match = _UNIT_BLEU.fullmatch(claim)
    if match and not re.search(r'\bBLEU\b', context, re.I):
        unit = match['unit']
        if any({unit.casefold(), f'{unit.casefold()} unit'} & items
               for _, _, items in training_unit_reports('translation systems', context)):
            return f'The reported BLEU score for the translation system trained with {unit} units.'
    match = _CATEGORY_F1.fullmatch(claim)
    if match and not re.search(r'\bF[ -]?1\b', context, re.I):
        category = match['category']
        if any(category.casefold() in items for _, items in taxonomy_reports('Twitter', _sentences(context))):
            return f'The F1 score of the claimed speech-act classifier on {category} tweets.'
    match = _NER_RECALL.fullmatch(claim)
    if (match and not re.search(r'\brecall\b', context, re.I)
            and any(ner_reports(match['task'], match['dataset'], _sentences(context)))):
        return f"The proposed {match['task']} approach's average recall on the {match['dataset']} dataset."
    match = _CORRECT_RATE.fullmatch(claim)
    if (match and re.search(r'(?m)^The rule-based TN model can handle the TN task\b', context)
            and re.search(r'\b(?:during normalization|text normalization)\b', context, re.I)
            and not re.search(r'%|\b(?:percent(?:age)?|accuracy|success rate)\b', context, re.I)):
        return f"The proportion of {match['group']} cases the rule-based model handled correctly."
    return None


def _corpus_declarations(name, sentences):
    pattern = re.compile(rf'\({re.escape(name)}\) corpus (?:was|is) (?:developed|created)\b')
    return [i for i, quote in enumerate(sentences) if pattern.search(quote)]


def _corpus_witness(form, match, part, sentences):
    name = match['entity'] if form is _CORPUS else match['name'] if form is _RANGE else part['scope']['entity']
    if not re.fullmatch(r'[A-Z][A-Z0-9]+', name):
        return
    owners = _corpus_declarations(name, sentences)
    if form is _TOTAL:
        for quote in sentences:
            found = re.match(rf'The {re.escape(name)} corpus (?:has|contains) (?P<n>{_NUM}) '
                             rf'{re.escape(match["unit"])}(?=\s+and\b|\.)', quote, re.I)
            if found:
                yield name, [quote], found['n'], None
        return
    if len(owners) != 1 or owners[0] + 1 >= len(sentences):
        return
    owner = owners[0]
    quote = sentences[owner + 1]
    if form is _CORPUS:
        unit = re.escape(match['unit'])
        found = re.match(rf'It describes (?P<n>{_NUM}) (?:common )?{unit}\b', quote, re.I)
        if found:
            yield name, [sentences[owner], quote], found['n'], None
    else:
        unit = re.escape(match['unit'])
        member = re.escape(match['entity'])
        found = re.match(rf'It describes {_NUM} (?:common )?{member}s with (?P<member>each task) having '
                         rf'(?P<lo>{_NUM}) to (?P<hi>{_NUM}) {unit}\b', quote, re.I)
        if found:
            yield found['member'], [sentences[owner], quote], found['hi'], found['lo']


def corpus_facts(form, match, part, sentences):
    for member, quotes, value, low in _corpus_witness(form, match, part, sentences):
        number = lambda text: Decimal(text.replace(',', ''))
        if low is None:
            yield member, quotes, number(value) == number(match['number']), (value, None)
        elif number(low) <= number(value) <= number(match['number']):
            yield member, quotes, False, (value, low)


def explicit_facts(form, match, sentences):
    """Yield a positive-predicate outcome from an exact, scope-matched source."""
    if form is _RESOURCES:
        for anchor, quote in ner_reports(match['task'], match['dataset'], sentences):
            if re.search(r', showing [^;]*? without using any external resource or encoded rule, '
                         r'achieving an average of', quote, re.I):
                yield 'novel approach', [anchor, quote], False
    elif form is _PRIORITY:
        owners = [i for i, q in enumerate(sentences) if q.startswith('The rule-based TN model can handle the TN task')]
        if len(owners) != 1:
            return
        start = owners[0]
        for i in range(start + 1, min(start + 8, len(sentences))):
            quote = sentences[i]
            found = re.fullmatch(r'If there are multiple pattern matches with the same length, '
                                 r'the one with a (higher|lower) priority will be chosen for the NSW\.', quote, re.I)
            scope = [q for q in sentences[start:i] if q.startswith('During normalization,')]
            if found and len(scope) == 1:
                yield 'rule-based TN model', [sentences[start], scope[0], quote], _same(found[1], match['direction'])
    elif form is _PROCEDURE:
        for first, second in _pos_search(sentences):
            yield 'each sentence of the speech', [first, second], True
    elif form is _TAXONOMY:
        wanted = [match['excluded']] if match['excluded'] else [match['first'], match['second']]
        for quote, items in taxonomy_reports(match['platform'], sentences):
            if all(item.casefold() in items for item in wanted):
                yield 'speech act categories', [quote], match['excluded'] is None
    else:
        for quote in sentences:
            if form is _GUARANTEE and re.fullmatch(
                    r'Having a sentence with the same POS tag structure does not necessarily mean that the grammar is correct\.', quote, re.I):
                yield 'same POS tag structure', [quote], False
            elif form is _SUPERVISION and re.fullmatch(
                    rf'We train several parsers for each language in the {re.escape(match["dataset"])} dataset'
                    r'(?:\s+BIBREF\d+)?\s*:\s*a traditional monolingual version, and variants which additionally incorporate '
                    rf'supervision from (?:the )?{re.escape(match["language"])} portion of the dataset\.', quote, re.I):
                yield 'variants', [quote], True


def report_facts(form, match, part, context):
    sentences = _sentences(context)
    if form in (_RANGE, _CORPUS, _TOTAL):
        for member, quotes, truth, (value, low) in corpus_facts(form, match, part, sentences):
            yield member, quotes, truth, (quotes[-1], value, match['unit'], value), low
    else:
        for member, quotes, truth in explicit_facts(form, match, sentences):
            yield member, quotes, truth, None, None


def expected_quantifier(form):
    if form in (_RANGE, _PROCEDURE):
        return 'all'
    return 'none' if form is _SUPERVISION else 'atomic'
