"""Finite relational predicates shared by validation and constrained decoding."""
import re

from .assessment_rules import clauses, contains
from .cellfix14_runtime import cached

_TENTATIVE = re.compile(r'\b(?:might|may|could|would|possibly|potentially|hypothetical|alleged|unproven)\b', re.I)
_EXPERIMENTAL = re.compile(r'\b(?:experimentally|empirically)\s+(?:established|demonstrated|confirmed|proved|validated)\b', re.I)
_COMPARISON = re.compile(r'\b(?P<direction>better|worse)\s+than\s+(?P<comparator>.+?)(?=\s+(?:on|during|under|after|before)\b|[.!?]|$)', re.I)


def relational_predicate(quote):
    """Keep the asserted relation, rather than a purpose clause or bare adjective."""
    requirement = re.search(r'\b(?:(?:does|did|do)\s+not\s+|never\s+)?requir(?:e[sd]?|ing)\b', quote, re.I)
    empirical = _EXPERIMENTAL.search(quote)
    comparison = _COMPARISON.search(quote)
    if requirement or empirical:
        start = (requirement or empirical).start()
        return quote[start:].rstrip(' .;')
    if comparison:
        prefix = quote[:comparison.start()]
        verb = re.search(r'\b(?:(?:does|did|do)\s+not\s+)?(?:perform[sed]*|is|was|are|were)\s+(?:not\s+)?$', prefix, re.I)
        return quote[(verb.start() if verb else comparison.start()):].rstrip(' .;')
    return None


def metric_requirement(scope, quote, previous):
    required = relational_predicate(quote)
    if required:
        return required if scope['metric'] != required else None
    return previous(scope, quote)


def empirical_claim(part):
    return bool(_EXPERIMENTAL.search(part['quote']))


def _restrictions(part, text):
    def normalized(value):
        return re.sub(r'\b(on|in|during|under|after|before)\s+the\s+', r'\1 ', value, flags=re.I)
    source = normalized(text)
    return all(contains(normalized(value), source)
               and not re.search(r'\b(?:not|never)\s+' + re.escape(normalized(value)), source, re.I)
               for value in (part['scope']['condition'], part['scope']['time']) if value)


@cached
def comparative_proofs(part, context):
    """Explicit comparisons only; never inherit a comparator across sentences."""
    comparison = _COMPARISON.search(part['quote'])
    if not comparison or part['quantifier'] != 'atomic':
        return []
    from .atomic_verifier import target_members
    members = target_members(part, context)
    name = re.sub(r'^the\s+', '', comparison['comparator'].strip(), flags=re.I)
    comparator = r'(?:the\s+)?' + re.escape(name)
    claimed_negative = bool(re.search(r'\b(?:not|never)\b', part['quote'][:comparison.start()], re.I))
    records = []
    sentences = [v.strip() for v in re.split(r'[.!?](?=\s|$)', context) if v.strip()]
    for source in dict.fromkeys(clauses(context) + sentences):
        # Dates named May are not epistemic modality.
        if _TENTATIVE.search(re.sub(r'\b(?:in|during) May\b', '', source, flags=re.I)):
            continue
        if re.search(r'\b(?:if|unless)\b', source, re.I):
            continue  # This finite comparison grammar does not establish hypothetical results.
        if not _restrictions(part, source):
            continue
        for member in members:
            owner = r'(?<!\w)' + re.escape(member) + r'\s+'
            direct = re.search(owner + r'(?:(?:is|was|are|were|performs?|performed|achieves?|achieved|obtains?|obtained)\s+|(?:does|did)\s+not\s+perform\s+)'
                               r'(?P<negative>not\s+)?(?:a\s+)?(?P<direction>better|worse)(?:\s+result)?\s+than\s+' + comparator + r'(?!\w)', source, re.I)
            # Shared comparator in a coordinated, same-subject result list.
            inherited = re.search(owner + r'(?:is|was)\s+[^.;]*?\b(?:which\s+)?achieves?\s+(?:a\s+)?'
                                  r'comparable result with\s+' + comparator + r'\s+on\s+[^.;]+?\s+and\s+(?:a\s+)?'
                                  r'(?P<direction>better|worse) result\s+', source, re.I)
            elliptical = re.search(owner + r'(?:obtains?|achieves?)\s+(?:a\s+)?(?:similar|comparable)\s+(?:performance|result)\s+on\s+[^,.;]+,?\s+but\s+'
                                   r'(?:is|was)\s+(?:still\s+)?(?P<direction>better|worse)\s+than\s+' + comparator + r'(?!\w)', source, re.I)
            match = direct or inherited or elliptical
            if not match:
                continue
            # The condition must belong to this result, not its test-clean sibling.
            tail = source[match.end():]
            tail = re.split(r'\b(?:and|even though|although)\b|,', tail, maxsplit=1, flags=re.I)[0]
            if not _restrictions(part, tail):
                continue
            opposite = match['direction'].casefold() != comparison['direction'].casefold()
            negated = bool(direct and (direct.groupdict().get('negative') or re.search(r'\b(?:does|did) not\b', direct[0], re.I)))
            if negated and opposite:
                continue  # Not worse does not establish strictly better.
            positive = not (opposite or negated)
            truth = positive != claimed_negative
            records.append(dict(member=member, truth='true' if truth else 'false', source=source))
    return records


def relation_issue(part, member, quotes, truth, context, previous):
    issue = previous(part, member, quotes, truth, context)
    if issue:
        return issue
    if _COMPARISON.search(part['quote']):
        proofs = comparative_proofs(part, context)
        states = {r['truth'] for r in proofs}
        if truth == 'unknown':
            return 'decisive_comparison_missing' if len(states) == 1 else None
        if states != {truth}:
            return 'comparison_evidence_unresolved'
        # Reparse each citation independently: presence in full context is not a citation.
        quoted = [r for q in quotes for r in comparative_proofs(part, q)
                  if contains(member, r['source']) and r['truth'] == truth]
        if not quoted:
            return 'comparison_quote_required'
    if empirical_claim(part) and truth != 'unknown':
        # shortcut: exact proposition + explicit empirical qualification only;
        # unfamiliar paraphrases need unknown/human review, never inferred proof.
        proposition = re.split(r'\bthat\b', part['quote'], maxsplit=1, flags=re.I)[-1].strip(' .')
        if not any(_EXPERIMENTAL.search(c) and not _TENTATIVE.search(c)
                   and not re.search(r'\b(?:not|never|no)\b', c, re.I)
                   and contains(member, c) and contains(proposition, c)
                   for q in quotes for c in clauses(q)):
            return 'experimental_evidence_required'
        if truth != 'true':
            return 'observation_polarity_mismatch'
    return None


def observation_explanation(observation, part):
    # Report the ledger and original assertion; never negate a truncated metric.
    return (f"Ledger for member {observation['member']!r}: truth={observation['truth']} "
            f"before applying {part['quantifier'].upper()}. Original claim part: {part['quote']}")
