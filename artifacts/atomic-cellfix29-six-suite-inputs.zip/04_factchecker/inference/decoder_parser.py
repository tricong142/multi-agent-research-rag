"""Keep LMFE's bounded-string fast path from bypassing character constraints."""
from lmformatenforcer import CharacterLevelParser
import lmformatenforcer.jsonschemaparser as _js
from lmformatenforcer.tokenizerprefixtree import JsonFreetextTokenCache
from copy import copy
import json
import re


def _literal_array(state, values):
    # Allow JSON whitespace between tokens. Literal string parsers keep quotes
    # and escape sequences inside each citation separate from JSON syntax.
    pieces = ['[']
    for index, value in enumerate(values):
        if index:
            pieces.append(',')
        pieces.append(json.dumps(value, ensure_ascii=False))
    pieces.append(']')
    parsers = []
    for piece in pieces:
        parsers.append(_js.StringParsingState(state, [''], False, False))
        parsers.append(_js.StringParser(piece))
    return _js.SequenceParser(parsers)


# LMFE 0.11.3 ignores array uniqueness and pushes an item for maxItems=0.
if not getattr(_js.get_parser, '_atomic_literal_array_fix', False):
    _previous_get_parser = _js.get_parser

    def _empty_array_parser(state, schema, _previous=_previous_get_parser):
        if schema is not None and schema.type == 'array' and schema.extras:
            values = schema.extras.get('const')
            if isinstance(values, list):
                return _literal_array(state, values)
        if schema is not None and schema.type == 'array' and schema.maxItems == 0:
            return _js.StringParsingState(state, ['[]'], False, False)
        if schema is not None and schema.type == 'string' and schema.enum:
            escaped = [v for v in schema.enum if _JSON_ESCAPES.search(v)]
            if escaped:
                # LMFE 0.11.3 treats a literal quote inside a string enum as
                # the closing delimiter. Compile escaped JSON strings as literals.
                alternatives = [_js.StringParser(json.dumps(v, ensure_ascii=False)) for v in escaped]
                plain = [v for v in schema.enum if not _JSON_ESCAPES.search(v)]
                if plain:
                    alternatives.append(_js.StringParsingState(state, plain, True))
                whitespace = _js.StringParsingState(state, [''], False, False)
                return _js.SequenceParser([whitespace, _js.UnionParser(alternatives)])
        return _previous(state, schema)

    _empty_array_parser._atomic_empty_array_fix = True
    _empty_array_parser._atomic_literal_array_fix = True
    _js.get_parser = _empty_array_parser

_JSON_ESCAPES = re.compile(r'["\\\x00-\x1f]')


class CheckedParser(CharacterLevelParser):
    def __init__(self, parser, config=None, filtered_cache=False):
        super().__init__(config or parser.config)
        self.parser = parser
        self.filtered_cache = filtered_cache

    def add_character(self, character):
        if character not in self.parser.get_allowed_characters():
            raise ValueError('Character violates the current JSON state')
        return CheckedParser(self.parser.add_character(character), self.config, self.filtered_cache)

    def get_allowed_characters(self):
        return self.parser.get_allowed_characters()

    def can_end(self):
        return self.parser.can_end()

    def shortcut_key(self):
        key = self.parser.shortcut_key()
        if self.filtered_cache and key and self.no_pending_whitespace(self.parser):
            return key
        return None

    @staticmethod
    def no_pending_whitespace(parser):
        if isinstance(parser, _js.JsonSchemaParser):
            return parser.num_consecutive_whitespaces == 0
        children = getattr(parser, 'parsers', [])
        return bool(children) and all(CheckedParser.no_pending_whitespace(p) for p in children)


def alphabet_tree(tree, config):
    """Share the vocabulary trie; replace only the request's free-text cache."""
    scoped = copy(tree)
    previous = tree.json_freetext_tokens
    cache = JsonFreetextTokenCache(previous.use_bitmask, previous.vocab_size)
    alphabet = set(config.alphabet) | {'\\'}
    excessive_whitespace = re.compile(r'[ \t\r\n]{'+str(config.max_consecutive_whitespaces+1)+r'}')
    for token, text in tree.tokens_to_strs.items():
        if set(text) <= alphabet and not excessive_whitespace.search(text):
            cache.add_token(text, token)
    cache.freeze()
    scoped.json_freetext_tokens = cache
    return scoped
