"""Conservative, source-checked Decimal comparisons for the experimental verifier."""
from __future__ import annotations

from decimal import Decimal, localcontext
import re

from .evidence_screen import DIGITS, DIRECTION_WORDS, WORDS, quantities


from .cellfix14_quantities import numeric_requirements


def direction(text: str) -> str | None:
    values = {DIRECTION_WORDS[w] for w in re.findall(r'[a-z]+', text.lower()) if w in DIRECTION_WORDS}
    values.update({'increase' for _ in re.finditer(r'\b(?:rose|raised|more)\b', text, re.I)})
    values.update({'decrease' for _ in re.finditer(r'\b(?:fell|less)\b', text, re.I)})
    return next(iter(values)) if len(values) == 1 else None


def _occurrences(quote: str, source: str):
    return [m for m in re.finditer(re.escape(quote), source)
            if not (quote[0].isalnum() and m.start() and source[m.start() - 1].isalnum())
            and not (quote[-1].isalnum() and m.end() < len(source) and source[m.end()].isalnum())
            and not (quote[0].isdigit() and m.start() and source[m.start() - 1] in '+-.,')
            and not (quote[-1].isdigit() and re.match(r'[.,]\d', source[m.end():]))]


def _original_operand(raw: dict, source: str) -> tuple[Decimal, str, str]:
    if not isinstance(raw, dict) or set(raw) != {'value', 'unit', 'quote'}:
        raise ValueError('numeric_operand_schema')
    value, unit, quote = raw['value'], raw['unit'], raw['quote']
    if not all(isinstance(s, str) for s in (value, unit, quote)):
        raise ValueError('numeric_operand_schema')
    if not quote.strip() or len(quote) > 2000 or len(unit) > 40 or not _occurrences(quote, source):
        raise ValueError('numeric_source_membership')
    if not re.fullmatch(r'[+-]?\d+(?:\.\d+)?', value) or len(value) > 60:
        raise ValueError('numeric_value_format')
    number = Decimal(value)
    found = quantities(quote)
    if len(found) != 1 or next(iter(found))[0] != number:
        raise ValueError('numeric_value_not_grounded')
    kind = next(iter(found))[1]
    if kind == 'percent' and unit not in ('%', 'percent'):
        raise ValueError('numeric_unit_not_grounded')
    if kind != 'percent' and unit in ('%', 'percent'):
        raise ValueError('numeric_unit_not_grounded')
    if unit.casefold() in _NON_UNITS:
        raise ValueError('numeric_unit_not_grounded')
    if unit and not (unit == '%' and '%' in quote or re.search(r'(?<!\w)' + re.escape(unit) + r'(?!\w)', quote, re.I)):
        raise ValueError('numeric_unit_not_grounded')
    # Empty units are allowed only for a bare dimensionless number/count.
    words = set(re.findall(r'[a-z]+', quote.lower())) - set(WORDS)
    if not unit and words:
        raise ValueError('numeric_unit_required')
    if not unit:
        for match in _occurrences(quote, source):
            tail = re.match(r'\s*(%|[A-Za-z]+)', source[match.end():])
            if tail and tail[1].casefold() not in _NON_UNITS:
                raise ValueError('numeric_unit_required')
    return number, '%' if unit == 'percent' else unit.casefold(), quote


def check_numeric(raw: dict, claim_part: str, context: str) -> dict:
    """Return unknown on unsupported comparisons; malformed source records raise.

    Scope/metric association is an explicit model judgment in the caller. Exact
    source membership and arithmetic do not independently prove that association.
    """
    if not isinstance(raw, dict) or set(raw) != {'kind', 'source_quote', 'left', 'right'}:
        raise ValueError('numeric_schema')
    kind, proof = raw['kind'], raw['source_quote']
    if kind not in ('value', 'change') or not isinstance(proof, str) or not proof.strip():
        raise ValueError('numeric_schema')
    if len(proof) > 2000 or not _occurrences(proof, context):
        raise ValueError('numeric_source_membership')
    left, left_unit, left_quote = _operand(raw['left'], claim_part if kind == 'value' else proof)
    right, right_unit, right_quote = _operand(raw['right'], proof)
    result = {'kind': kind, 'input': raw, 'truth': 'unknown', 'reason': '',
              'left': str(left), 'right': str(right), 'unit': left_unit}
    if kind == 'value':
        requirements = numeric_requirements(claim_part)
        bound = [r for r in requirements if r['quote'] == left_quote]
        if len(requirements) > 1 and len(bound) != 1:
            return {**result, 'reason': 'numeric_requirement_binding_unresolved'}
        if len(requirements) <= 1 and {(Decimal(r['value']),r['kind']) for r in requirements} != quantities(left_quote):
            return {**result, 'reason': 'unbound_claim_quantity'}
        if bound:
            result['requirement'] = bound[0]
    if re.search(r'\b(?:not|never|without)\b', claim_part, re.I):
        return {**result, 'reason': 'unsupported_numeric_negation'}
    if re.search(r'[<>\u2260\u2264\u2265\u2248]', claim_part):
        return {**result, 'reason': 'unsupported_comparison_operator'}
    if kind == 'value' and re.search(r'\b(?:about|approximately|between|up to|less than|more than|at least|at most|over|under)\b', claim_part, re.I):
        return {**result, 'reason': 'unsupported_threshold_or_approximation'}
    # shortcut: explicit "observed X, not claimed Y" only; no inferred unit conversion.
    if kind == 'value' and direction(claim_part) is None and (left, left_unit) != (right, right_unit):
        denial = re.search(r'(?<!\w)' + re.escape(right_quote) + r'\s*,?\s+(?:but\s+)?not\s+'
                           + re.escape(left_quote) + r'(?!\w)', proof, re.I)
        remainder = proof[:denial.start()] + proof[denial.end():] if denial else proof
        if denial and not re.search(r'\b(?:not|never|without|hypothetical|would|could|may|might|should|if|expected|predicted|approximately|about)\b', remainder, re.I):
            return {**result, 'truth': 'false', 'reason': 'explicit_quantity_denial'}
    from .cellfix16_rules import measurement_qualification
    qualification = measurement_qualification(proof,raw)
    if re.search(r'\b(?:not|never|hypothetical|would|could|may|might|should|if|expected|predicted|approximately|about)\b', qualification, re.I):
        return {**result, 'reason': 'qualified_numeric_evidence'}
    from .cellfix14_quantities import compatible_count_units
    if left_unit != right_unit and not (kind=='value' and compatible_count_units(left_unit,right_unit)):
        return {**result, 'reason': 'unit_mismatch_no_conversion'}
    if kind == 'value':
        requested = direction(claim_part)
        if requested and direction(proof) != requested:
            return {**result, 'reason': 'reported_change_direction_not_matched'}
        truth = left == right
        return {**result, 'truth': 'true' if truth else 'false', 'reason': 'exact_value_comparison'}

    requested = direction(claim_part)
    if requested is None:
        return {**result, 'reason': 'ambiguous_requested_direction'}
    if quantities(claim_part, claim=True):
        return {**result, 'reason': 'change_amount_requires_additional_rule'}
    # shortcut: two English pair forms only; extend after numerical evaluation.
    # No guessed chronology, cross-sentence joins or automatic unit conversion.
    a, b = re.escape(left_quote), re.escape(right_quote)
    patterns = (
        r'\bfrom\s+' + a + r'\s+(?:before\s+[\w -]{1,80}\s+)?to\s+' + b,
        a + r'\s+before\s+[\w -]{1,80}?\s+and\s+' + b + r'\s+after\b',
    )
    if not any(re.search(p, proof, re.I) for p in patterns):
        return {**result, 'reason': 'unbound_before_after_order'}
    if quantities(proof) != {(left, 'percent' if left_unit == '%' else 'number'),
                             (right, 'percent' if right_unit == '%' else 'number')}:
        return {**result, 'reason': 'ambiguous_numeric_passage'}
    observed = 'increase' if right > left else 'decrease' if right < left else 'unchanged'
    with localcontext() as decimal_context:
        decimal_context.prec = 128  # Operands are bounded to 60 characters each.
        delta = str(right - left)
    return {**result, 'truth': 'true' if observed == requested else 'false',
            'reason': 'ordered_change_comparison', 'requested_direction': requested,
            'observed_direction': observed, 'delta': delta}


# Cellfix3: bind a record to its measurement clause before numerical comparison.
_cellfix2_numeric = check_numeric
_NUMERIC_MODAL = r'\b(?:hypothetical|would|could|may|might|should|if|expected|predicted|approximately|about)\b'

def measurement_clauses(proof):
    return [p.strip(' ,') for p in re.split(
        r';|[.!?](?=\s|$)|,\s*however\b|\b(?:and|but|whereas)\b', proof, flags=re.I
    ) if p.strip(' ,')]

def measurement_scope(raw, claim_part, metric):
    """Return an exact source clause and finite lexical binding, not entailment."""
    proof = raw['source_quote']
    if raw['kind'] != 'value':
        return change_scope(raw, metric)
    left, right = raw['left'], raw['right']
    requirements = numeric_requirements(claim_part)
    anchor = left['unit'] if len(requirements) > 1 else metric
    if not anchor:
        return proof, True
    time_units = {'ms','s','second','seconds','minute','minutes','hour','hours'}
    lu, ru = left['unit'].casefold(), right['unit'].casefold()
    from .cellfix14_quantities import compatible_count_units
    if len(requirements) > 1 and lu != ru and not {lu,ru} <= time_units and not compatible_count_units(lu,ru):
        return proof, False
    families = (r'takes?|took', r'contains?|contained', r'uses?|used', r'evaluates?|evaluated')
    first = anchor.split()[0].casefold()
    family = next((f for f in families if re.fullmatch(f, first)), None)
    def matches(clause):
        positions = _occurrences(right['quote'], clause)
        if not positions or all(re.search(r'\b(?:not|never)\s*$',clause[:m.start()],re.I) for m in positions):
            return False
        if family:
            return bool(re.search(r'\b(?:'+family+r')\s+(?:exactly\s+)?'
                +re.escape(right['quote'])+r'(?!\w)', clause, re.I))
        return bool(re.search(r'(?<!\w)'+re.escape(anchor)+r'(?!\w)', clause, re.I)) or compatible_count_units(anchor,right['unit'])
    candidates = [c for c in measurement_clauses(proof) if matches(c)]
    if not candidates:
        return proof, False
    # Preserve shared modality and broad negation rather than strip a prefix.
    broad = r'\b(?:not true|not the case|not established|not known|no evidence|neither)\b'
    if (len(candidates) != 1 or re.search(_NUMERIC_MODAL+'|'+broad, proof, re.I)):
        return proof, True
    selected = candidates[0]
    prefix = proof[:proof.find(selected)]
    if re.search(r'\b(?:not|never|without)\b', prefix, re.I):
        return proof, True
    # A later denial can refer back to the selected statement. Only separate
    # an explicit different measurement; pronoun/back-reference scope is unknown.
    properties = {'accuracy','precision','recall','latency','memory','throughput',
        'capacity','duration','cost','speed','temperature','pressure','score'}
    own_words = set(re.findall(r'[a-z]+',anchor.casefold()))
    for other in measurement_clauses(proof):
        if other==selected or not re.search(r'\b(?:not|never|without)\b',other,re.I):
            continue
        from .cellfix21_rules import independent_error_distribution
        if independent_error_distribution(other, metric):
            continue
        words = set(re.findall(r'[a-z]+',other.casefold()))
        units = {r['unit'].casefold() for r in numeric_requirements(other)} - {'','%','percent'}
        if (not numeric_requirements(other) or own_words & words
                or words & {'this','it','that','claim','finding','above'}
                or not (properties & words - own_words or units - {lu,ru})):
            return proof, True
    verb = r'\b(?:is|was|were|uses?|used|retains?|retained|contains?|contained|takes?|took|evaluates?|evaluated|fell|rose|increased|decreased|improved|reduced|measured|recorded|reported|achieves?|achieved|reached|scored|included|comprised|has|had)\b'
    return (selected if re.search(verb, selected, re.I) else proof), True

def check_numeric(raw, claim_part, context, *, metric=''):
    # The original checker validates all source spans, operands and claim guards.
    result = _cellfix2_numeric(raw, claim_part, context)
    from .cellfix16_rules import quantity_modifier_issue
    modifier_issue=quantity_modifier_issue(raw,claim_part,context)
    if modifier_issue:return {**result,'truth':'unknown','reason':modifier_issue}
    proof, bound = measurement_scope(raw, claim_part, metric)
    if raw['kind'] == 'change':
        if not bound:
            return {**result, 'truth':'unknown', 'reason':'numeric_metric_binding_unresolved'}
        if proof != raw['source_quote']:
            result = {**_cellfix2_numeric({**raw, 'source_quote':proof}, claim_part, context), 'input':raw}
        return result
    if metric and not bound:
        return {**result, 'truth':'unknown', 'reason':'numeric_metric_binding_unresolved'}
    if proof != raw['source_quote']:
        narrowed = {**raw, 'source_quote':proof}
        result = {**_cellfix2_numeric(narrowed, claim_part, context), 'input':raw}
    # Only extend the already-qualified explicit-denial grammar. Other claim
    # guards (thresholds, negated claim, unit grounding) retain their result.
    if result['reason'] != 'qualified_numeric_evidence' or re.search(_NUMERIC_MODAL, proof, re.I):
        return result
    left, lu, lq = _operand(raw['left'], claim_part)
    right, ru, rq = _operand(raw['right'], proof)
    if (left,lu) == (right,ru) or direction(claim_part) is not None:
        return result
    denial = re.search(r'(?<!\w)'+re.escape(rq)
        +r'(?P<bridge>(?:\s+[A-Za-z][A-Za-z-]*){0,4})\s*,?\s+(?:but\s+)?not\s+'
        +re.escape(lq)+r'(?!\w)', proof, re.I)
    if not denial:
        return result
    bridge = re.findall(r'[a-z-]+', denial['bridge'].casefold())
    claim_words = set(re.findall(r'[a-z-]+', claim_part.casefold()))
    remainder = proof[:denial.start()] + proof[denial.end():]
    if (any(w not in claim_words for w in bridge)
            or re.search(r'\b(?:not|never|without)\b', remainder, re.I)):
        return result
    return {**result, 'truth':'false', 'reason':'explicit_quantity_denial'}


# Cellfix6: one lexical rule for requirement extraction and operand validation.
_NON_UNITS = {'before', 'after', 'afterward', 'afterwards', 'previously',
    'subsequently', 'then', 'to', 'and', 'on', 'in', 'at', 'for', 'with', 'than', 'or'}

def metric_in_measurement(metric, proof):
    if re.search(r'(?<!\w)' + re.escape(metric) + r'(?!\w)', proof, re.I):
        return True
    # shortcut: a single intervening object modifier can be discharged by an
    # explicit "for the same <object plural>" clause, never by the claim itself.
    words = metric.split()
    if len(words) == 3:
        statistic, obj, head = words
        if (statistic.casefold() in {'median', 'mean', 'average', 'peak', 'maximum', 'minimum'}
                and re.search(r'\bfor the same\s+' + re.escape(obj) + r's\b', proof, re.I)
                and re.search(r'\b' + re.escape(statistic + ' ' + head) + r'\b', proof, re.I)
                and not re.search(r'\b(?:other|different)\s+' + re.escape(obj) + r's\b', proof, re.I)):
            return True
    return False

def change_scope(raw, metric):
    proof = raw['source_quote']
    if not metric:
        return proof, True
    # Preserve the before-and-after pair. Split only between measurements.
    pieces = [p.strip(' ,') for p in re.split(
        r';|[.!?](?=\s|$)|\b(?:while|whereas|but)\b|\band\b(?=\s+[A-Za-z][^.;]*?\bfrom\b)', proof, flags=re.I) if p.strip(' ,')]
    candidates = [p for p in pieces if _occurrences(raw['left']['quote'], p)
        and _occurrences(raw['right']['quote'], p) and (not metric or metric_in_measurement(metric, p))]
    if len(candidates) != 1:
        return proof, False
    selected = candidates[0]
    if selected != proof:
        # No stripping shared modality, negation or a later retraction.
        if re.search(_NUMERIC_MODAL + r'|\b(?:not|never|without|neither|retracted|incorrect|false|hypothetically)\b', proof, re.I):
            return proof, False
    return selected, True


from .cellfix14_quantities import grounded_operand
def _operand(raw,source):
    return grounded_operand(raw,source,_original_operand)

from .cellfix18_rules import allocation_check
_previous_numeric18 = check_numeric

def check_numeric(raw, claim_part, context, *, metric=''):
    return allocation_check(raw, claim_part, context, metric, _previous_numeric18)

from .cellfix19_rules import selection_check
_previous_numeric19 = check_numeric

def check_numeric(raw, claim_part, context, *, metric=''):
    return selection_check(raw, claim_part, context, metric, _previous_numeric19)

from .cellfix21_rules import measurement_scope as local_measurement_scope21
_previous_measurement_scope21 = measurement_scope
def measurement_scope(raw, claim_part, metric):
    return local_measurement_scope21(raw, claim_part, metric, _previous_measurement_scope21)
