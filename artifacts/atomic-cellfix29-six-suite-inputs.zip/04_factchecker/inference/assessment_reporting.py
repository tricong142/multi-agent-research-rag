"""Render checked decisions, while retaining raw model prose only for audit."""
import re

from .assessment_rules import clauses, scope_conflict

OBSERVATION_NOTE = 'Predicate evidence recorded.'
ASSESSMENT_NOTE = 'Assess the recorded evidence ledger.'
REASONS = {
    'causal_relationship': 'Evidence establishing the claimed causal relationship, beyond co-occurrence/correlation',
    'experimental_evidence_unestablished': 'Experimental evidence establishing the asserted proposition, rather than a tentative explanation',
    'source_evidence_absent': 'Source evidence for this claim part',
    'target_binding_unresolved': 'Evidence identifying the claimed target in the reported results',
    'subject_count_unresolved': 'A source-backed count for the claimed group',
    'qualified_count_unresolved': 'A source-backed count for the group and evidence that its members meet the claimed qualification',
    'contained_total_unresolved': 'A source-backed total for the claimed target',
    'comparison_unresolved': 'An in-scope baseline/comparison establishing the claimed change',
    'measurement_unreported': 'The unreported in-scope measurement/result',
    'population_results_unresolved': 'A closed target population and the remaining member results',
    'scoped_evidence_unresolved': 'Evidence resolving this predicate for the claimed target and scope',
}

_BASELINE_ABSENCE = re.compile(
    r'\b(?:no|without)\s+(?:before[- ]\w+|baseline|comparative|comparison)\b'
    r'|\b(?:baseline|before[- ]\w+|comparative change)\b[^.;]*\b(?:not reported|unreported|not measured)\b', re.I)
_UNREPORTED = r'(?:not (?:reported|measured|evaluated|recorded|available)|unreported|unmeasured|unevaluated)'
_AUXILIARY = r'(?:(?:is|are|was|were|has|have|had|been)\s+){0,3}'


def local_clauses(part, context):
    from .atomic_verifier import other_named_target
    return [clause for clause in clauses(context)
            if not scope_conflict(part, clause) and not other_named_target(part, clause)]


def baseline_gaps(part, context, *, require_metric=False):
    from .atomic_verifier import _PROPERTY_HEADS
    from .assessment_evidence import metric_present
    from .numeric_verifier import direction
    if not direction(part['quote']) or not metric_present(part, context):
        return []
    wanted = set(re.findall(r'[a-z]+', part['scope']['metric'].lower())) & _PROPERTY_HEADS
    gaps = []
    for clause in local_clauses(part, context):
        mentioned = set(re.findall(r'[a-z]+', clause.lower())) & _PROPERTY_HEADS
        if _BASELINE_ABSENCE.search(clause) and (wanted & mentioned or not mentioned and not require_metric):
            gaps.append(clause)
    return gaps


def requires_experimental_evidence(part):
    from .cellfix20_rules import empirical_claim
    from .cellfix22_scope import intervention_claim
    return empirical_claim(part) or intervention_claim(part['quote'])


def missing_reason(part, context):
    from .atomic_verifier import target_entity, target_members
    from .assessment_rules import missing_result
    if not context.strip():
        return 'source_evidence_absent'
    from .cellfix27_reports import ambiguous_response_time, missing_measurement, missing_quantity_reason
    if ambiguous_response_time(part, context):
        return 'comparison_unresolved'
    quantity_gap = missing_quantity_reason(part, context)
    if quantity_gap:
        return quantity_gap
    if missing_measurement(part, context):
        return 'measurement_unreported'
    if part['quantifier'] == 'atomic' and target_entity(part) and not target_members(part, context):
        return 'target_binding_unresolved'
    from .assessment_focus import causal_claim
    if requires_experimental_evidence(part):
        return 'experimental_evidence_unestablished'
    if causal_claim(part):
        return 'causal_relationship'
    if baseline_gaps(part, context):
        return 'comparison_unresolved'
    if any(missing_result(part, c, require_metric=True) for c in local_clauses(part, context)):
        return 'measurement_unreported'
    if part['quantifier'] != 'atomic':
        return 'population_results_unresolved'
    return 'scoped_evidence_unresolved'


def missing_text(reason, part, members=(), *, unit=''):
    scope = part['scope']
    fields = [f"target={scope['entity']}", f"predicate/metric={scope['metric']}"]
    if members:
        fields.append('unresolved members=' + ', '.join(members))
    if unit:
        fields.append(f'unit={unit}')
    fields.extend(f'{key}={scope[key]}' for key in ('time', 'condition') if scope[key])
    fields.append('original claim part=' + part['quote'])
    return REASONS[reason] + ': ' + '; '.join(fields)


def missing_target_details(part, measurement_absent):
    from .atomic_verifier import target_entity
    from .numeric_verifier import numeric_requirements
    details = []
    if measurement_absent:
        details.append(missing_text('measurement_unreported', part))
    target = target_entity(part).casefold()
    quote, metric = part['quote'], part['scope']['metric']
    metric_start = quote.casefold().find(metric.casefold())
    contained = re.fullmatch(r'contain(?:s|ed)?\s+(?:(?:exactly|a total of)\s+)?(.+)', metric, re.I)
    supervised = re.fullmatch(r'used\s+(.+? training sentences)\s+to supervise\b.*', metric, re.I)
    for quantity in numeric_requirements(quote):
        unit = quantity['unit']
        if quantity['kind'] != 'number' or not unit:
            continue
        if target in (unit.casefold(), quantity['quote'].casefold()):
            details.append(missing_text('subject_count_unresolved', part))
        elif target and quantity['end'] <= metric_start and unit.casefold().endswith(' ' + target):
            details.append(missing_text('qualified_count_unresolved', part, unit=unit))
        elif contained and contained[1].casefold() == quantity['quote'].casefold():
            details.append(missing_text('contained_total_unresolved', part, unit=unit))
        elif supervised and supervised[1].casefold() == quantity['quote'].casefold():
            details.append(missing_text('measurement_unreported', part, unit=unit))
    if requires_experimental_evidence(part):
        details.append(missing_text('experimental_evidence_unestablished', part))
    return list(dict.fromkeys(details))


def missing_source_evidence(part, context, observations, reason):
    """Quote explicit gaps without adding a member, outcome or closure proof."""
    from .assessment_focus import absence_quotes
    from .assessment_members import member_absence_quotes
    from .atomic_verifier import ASSESSMENT_LIMITS

    quotes = list(absence_quotes(part, context))
    named = []
    local = local_clauses(part, context)
    for obs in observations:
        if obs['truth'] != 'unknown':
            continue
        member = obs['member']
        direct = member_absence_quotes(part, member, context)
        if part['quantifier'] != 'atomic':
            # shortcut: explicit member-owned result statements. Other
            # paraphrases need a validated model citation or wider review.
            pattern = (r'(?:results?|measurements?|outcomes?) for ' + re.escape(member)
                       + r'\s+' + _AUXILIARY + _UNREPORTED)
            direct = direct + [c for c in local if re.fullmatch(pattern, c, re.I)]
        if direct:
            quotes.extend(direct)
            named.append(member)

    scope = part['scope']
    scoped = [c for c in clauses(context) if not scope_conflict(part, c)]
    metric = re.escape(scope['metric'])
    time = r'(?:\s+' + re.escape(scope['time']) + r')?' if scope['time'] else ''
    direct_measurement = re.compile(
        r'(?:no (?:model )?' + metric + r'(?: (?:results?|measurements?|data))?\s+'
        + _AUXILIARY + r'(?:reported|recorded)|' + metric + time
        + r'\s+' + _AUXILIARY + _UNREPORTED + r')', re.I)
    measurements = [c for c in scoped if re.fullmatch(direct_measurement, c)]
    quotes.extend(measurements)

    event = re.sub(r'^(?:after|before|during)\s+', '', scope['time'], flags=re.I)
    if event and event != scope['time']:
        event_gap = (r'no ' + re.escape(event) + r' results? for (?:the )?'
                     + re.escape(re.sub(r'^the\s+', '', scope['entity'], flags=re.I))
                     + r'\s+' + _AUXILIARY + r'(?:reported|recorded|available)')
        quotes.extend(c for c in local if re.fullmatch(event_gap, c, re.I))
    if reason == 'comparison_unresolved':
        quotes.extend(baseline_gaps(part, context, require_metric=True))
    if part['quantifier'] != 'atomic':
        entity = scope['entity']
        for clause in scoped:
            roster = re.search(r'\b(?:did|does|do) not (?:identify|list|report|specify)\s+'
                               r'(?:the )?(?:complete|full|entire) (?:set|roster|population) of\s+'
                               r'(?P<entity>[\w -]+?)(?:\s+or\b|$)', clause, re.I)
            if roster and roster['entity'].casefold() in {entity.casefold(), entity.casefold() + 's'}:
                quotes.append(clause)

    limit = ASSESSMENT_LIMITS['quote_chars']
    quotes = list(dict.fromkeys(quote for quote in quotes if len(quote) <= limit and quote in context))
    return quotes[:ASSESSMENT_LIMITS['quotes_per_record']], named, bool(measurements)


def reporting_issue(raw, part, context):
    codes = [v for v in raw['missing_information'] if v in REASONS]
    if codes and (len(raw['missing_information']) != 1 or codes != [missing_reason(part, context)]):
        return 'missing_reason_binding'
    return None


def render(result, raw, part, context):
    """Called only after validation; cannot change truth, citations or label."""
    result = dict(result)
    q, label = part['quantifier'], result['assessed_label']
    observations = []
    for obs in result['observations']:
        from .cellfix20_rules import observation_explanation
        text = observation_explanation(obs, part)
        if q == 'none' and label == 'contradict' and obs['truth'] == 'true':
            text = f"Source evidence for {obs['member']!r} provides a counterexample to the claimed absence."
        if obs['numeric_result'] is not None:
            text += ' See the checked numeric records and their source quotes.'
        observations.append({**obs, 'model_explanation': obs['explanation'], 'explanation': text})
    result['observations'] = observations
    result['model_missing_information'] = list(raw['missing_information'])
    if label == 'not_enough_info':
        reason = missing_reason(part, context)
        quotes, members, measurement_absent = missing_source_evidence(part, context, observations, reason)
        result['missing_reason'] = reason
        result['missing_evidence'] = quotes
        from .cellfix27_reports import missing_measurement
        measurement = missing_measurement(part, context) if reason == 'measurement_unreported' else None
        missing = [measurement or missing_text(reason, part, members)]
        if reason == 'target_binding_unresolved':
            missing.extend(missing_target_details(part, measurement_absent))
        result['missing_information'] = missing
        text = 'The checked ledger does not decide this claim part. ' + ' '.join(missing)
    else:
        result['missing_reason'] = None
        result['missing_evidence'] = []
        result['missing_information'] = []
        text = {
            ('atomic', 'support'): 'The checked in-scope evidence establishes this predicate.',
            ('atomic', 'contradict'): 'The checked in-scope evidence refutes this predicate.',
            ('all', 'support'): 'The complete checked population satisfies the predicate for every member.',
            ('all', 'contradict'): 'A checked member fails the predicate, refuting ALL.',
            ('some', 'support'): 'A checked member satisfies the predicate, establishing SOME.',
            ('some', 'contradict'): 'The complete checked population has no true member, refuting SOME.',
            ('none', 'support'): 'The complete checked population has no true member, establishing NONE.',
            ('none', 'contradict'): 'The cited source provides a counterexample to the claimed absence.',
        }[(q, label)]
        if q == 'none' and label == 'contradict':
            counterexamples = dict.fromkeys(quote for obs in observations if obs['truth'] == 'true'
                                            for quote in obs['quotes'])
            text += ' ' + ' '.join(counterexamples)
    result['explanation'] = text
    result['explanation_origin'] = 'validated_ledger_renderer_v1'
    if q != 'atomic':
        from .assessment_evidence import _population
        population = _population(part, context)
        result['population_binding_basis'] = population['binding_basis'] if population else 'model_ledger'
    return result


def constrain_schema(schema, part, context):
    props = schema['properties']
    props['explanation'] = {'type': 'string', 'enum': [ASSESSMENT_NOTE]}
    props['missing_information']['items'] = {'type': 'string', 'enum': [missing_reason(part, context)]}
    props['missing_information']['maxItems'] = min(1, props['missing_information'].get('maxItems', 4))
    items = props['observations']['items']
    for branch in items.get('anyOf', [items]):
        branch['properties']['explanation'] = {'type': 'string', 'enum': [OBSERVATION_NOTE]}
    return schema
