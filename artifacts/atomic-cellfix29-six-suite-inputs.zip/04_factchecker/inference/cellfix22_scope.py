"""Recognize source spans that fill specific roles in a claim."""
import re

from .cellfix22_relations import _ACTIVITY_LIST

_FINITE = re.compile(
    r'\b(?:is|are|was|were|has|have|had|do|does|did|uses?|used|takes?|took|'
    r'contains?|contained|achieves?|achieved|consists?|consisted|'
    r'improves?|improved|increases?|increased|decreases?|decreased|'
    r'produces?|produced|generates?|generated|assigns?|assigned|'
    r'requires?|required|starts?|started|works?|worked|outperforms?|outperformed)\b', re.I)
_PHASES = re.compile(r'\b(?:after|before|during)\s+' + _ACTIVITY_LIST + r'\b', re.I)
_ROLE_PATTERNS = (
    r'(?P<entity>.+?\s+and\s+(?:the )?.+?)\s+(?:have|had)\s+(?P<metric>identical .+? results)\s+for\s+.+',
    r'(?P<entity>.+?\s+column)\s+(?P<metric>(?:was|is)\s+(?:not\s+)?(?:entered|coded|annotated|reviewed|filled)\s+by\s+.+)',
    r'(?P<entity>.+?)\s+(?:is|are|was|were)\s+(?P<metric>(?:classified|categorized|categorised|grouped) into\s+.+)',
    r'(?P<entity>.+?)\s+(?P<metric>(?:were|was|are|is)\s+(?:not\s+)?(?:retained|kept|removed|excluded|dropped)\s+(?:in|from)\s+.+?)\s+(?:before|during|after)\s+' + _ACTIVITY_LIST,
    r'(?P<entity>.+?)\s+(?P<metric>(?:starts?|begins?|started|began)\s+in\s+\d{4})',
    r'(?P<entity>.+?)\s+(?P<metric>(?:consists?|consisted)\s+of\s+.+?\s+by\s+.+)',
    r'(?P<entity>Removing .+?)\s+(?:increased|decreased|improved|reduced)\s+(?P<metric>.+?)\s+by\s+.+',
    r'(?P<entity>.+?)\s+(?P<metric>(?:was|were)\s+(?:the\s+test set|used as a test set)\b.*)',
    r'(?:and\s+)?(?:(?P<entity>.+?)\s+)?(?P<metric>(?:produces?|produced|generates?|generated)\s+.+?\s+in\s+.+?(?:seconds?|minutes?|hours?))',
)


def nominal_coordination(left, right):
    # No finite verb on the left and a noun phrase before the finite verb on
    # the right indicate a shared predicate, e.g. "Model X and Model Y have ...".
    predicate = _FINITE.search(right)
    return bool(predicate and not _FINITE.search(left)
                and re.fullmatch(r'\s*(?:[\w-]+\s+){1,8}', right[:predicate.start()]))


def full_clause_span(quote, source):
    def content(text):
        return re.sub(r'^and\b\s*', '', text.strip(), flags=re.I).strip(' ,.;:')
    return content(quote) == content(source)


def time_phrase(text, start):
    from .cellfix27_reports import claim_form
    _, match = claim_form(text)
    time = match.groupdict().get('time') if match else None
    if time and text.startswith(time, start):
        return time
    found = _PHASES.match(text, start)
    return found[0] if found else None


def roles(source):
    """An empty condition is explicit for these forms; restrictions stay in the quote."""
    from .cellfix26_evidence import predicate_roles
    bound = predicate_roles(source)
    if bound:
        result = {'metric': [bound['metric']], 'condition': [bound.get('condition') or '']}
        if 'entity' in bound:
            result['entity'] = entity_spans(bound['entity'])
        if bound.get('time'):
            result['time'] = [bound['time']]
        return result
    text = re.sub(r'^and\b\s*', '', source.strip(), flags=re.I).strip(' ,.;:')
    for pattern in _ROLE_PATTERNS:
        found = re.fullmatch(pattern, text, re.I)
        if found:
            entity = found['entity']
            result = {'metric': [found['metric']], 'condition': ['']}
            if entity:
                result['entity'] = entity_spans(entity)
            return result
    return {}


def entity_spans(entity):
    bare = re.sub(r'^(?:all|every|each|the|a|an)\s+', '', entity, flags=re.I)
    return list(dict.fromkeys((bare, entity)))


def preceding_actor(source):
    from .cellfix26_evidence import predicate_roles
    actor = predicate_roles(source).get('entity')
    if actor:
        return entity_spans(actor)
    found = _FINITE.search(source)
    if not found:
        return []
    actor = re.sub(r'^and\b\s*', '', source[:found.start()].strip(), flags=re.I)
    return entity_spans(actor) if actor and ',' not in actor else []


def intervention_claim(quote):
    return bool(re.match(r'Removing .+?\s+(?:increased|decreased|improved|reduced)\b', quote, re.I))


def subject_quantifier_text(text):
    """Quantifiers in the object of these predicates do not quantify the actor."""
    relation = re.search(r'\b(?:(?:was|were)\s+(?:not\s+)?used as a test set|'
                         r'(?:produces?|produced|generates?|generated)\s+each\b)', text, re.I)
    return text[:relation.start()] if relation else text
