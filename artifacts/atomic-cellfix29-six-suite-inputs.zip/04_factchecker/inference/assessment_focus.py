"""Shared local scope and explicit-absence checks, including unknown records."""
import re

from .assessment_rules import clauses, contains, scope_conflict, missing_result, _MISSING
from .assessment_evidence import metric_present, predicate_truth

_CAUSAL = re.compile(r'\b(?:caus(?:e[sd]?|ing)|led to|leads? to|resulted in|causal relationship)\b', re.I)
_ABSENT = r'(?:not (?:reported|measured|evaluated|established|known|available)|unreported|unmeasured|unevaluated|unknown)'


def causal_claim(part):
    return bool(_CAUSAL.search(part['quote']))


def member_scope_issue(part, member, quotes, context):
    """An unknown record still cannot belong to an explicitly opposed scope."""
    if scope_conflict(part, member):
        return 'observation_scope_mismatch'
    from .atomic_verifier import other_named_target, target_members
    if part['quantifier']=='atomic' and target_members(part,context):
        if any(other_named_target(part,q) for q in quotes):
            return 'observation_target_mismatch'
    unowned = [q for q in quotes if not any(contains(member,c) for c in clauses(q))]
    if unowned:
        # An explicit metric/relation absence may omit the event subject.
        preferred = absence_quotes(part,context)
        from .numeric_verifier import numeric_requirements
        from .assessment_decisions import numeric_choices
        numeric_sources = {r['source_quote'] for group in numeric_choices(part,context) for r,_ in group} if numeric_requirements(part['quote']) else set()
        if not all(q in numeric_sources or any(a in q for a in preferred) for q in unowned):
            return 'observation_evidence_unbound'
    if not part['scope']['time'] and not part['scope']['condition']:
        return None
    # Exact local ownership also rejects a source span crossing two sentences.
    source = [c for c in clauses(context) if contains(member, c)]
    if not source:
        return 'observation_scope_binding_unresolved'
    cited = [c for q in quotes for c in clauses(q) if contains(member, c)]
    own = cited or source
    if all(scope_conflict(part, c) for c in own):
        return 'observation_scope_mismatch'
    if any(scope_conflict(part, c) for c in own):
        return 'observation_scope_binding_unresolved'
    return None


def _direct_absence(part, clause):
    metric = re.escape(part['scope']['metric'])
    if re.search(r'(?<!\w)' + metric + r'(?!\w)\s+'
                 r'(?:(?:was|were|is|are|has|have|had|been)\s+){0,3}' + _ABSENT + r'\b', clause, re.I):
        return True
    if re.search(r'\bno\s+' + metric + r'\s+(?:results?|measurements?|data|evidence)\b', clause, re.I) or (
            re.search(r'\bno\s+' + metric + r'\s+changes?\b',clause,re.I)
            and _MISSING.search(clause)):
        return True
    if causal_claim(part) and re.search(
            r'\b(?:did not|does not|cannot|could not)\s+(?:establish|demonstrate|prove|confirm)\b[^.;]*'
            r'\b(?:causal relationship|causality|causal link)\b'
            r'|\b(?:causal relationship|causality|causal link)\b[^.;]*\b(?:not established|unproven|unknown)\b', clause, re.I):
        return True
    return False


def absence_quotes(part, context):
    """Exact source clauses that directly state the current predicate is missing.

    This selects unknown evidence, not its truth. Competing in-scope positive
    facts keep the general ledger available instead of hiding a conflict.
    """
    from .atomic_verifier import target_entity, target_members, other_named_target, ASSESSMENT_LIMITS
    from .numeric_verifier import numeric_requirements
    if part['quantifier']=='atomic' and target_entity(part) and not target_members(part, context):
        return []
    local = [c for c in clauses(context) if not scope_conflict(part,c) and not other_named_target(part,c)]
    found = [c for c in local if _direct_absence(part,c)]
    if not found:
        return []
    for c in local:
        if causal_claim(part) and not _CAUSAL.search(c):
            continue  # Co-occurring property changes do not establish cause.
        if c not in found and metric_present(part,c) and not missing_result(part, c):
            if predicate_truth(part,c) is not None or numeric_requirements(c):
                return []
    # Prefer the intact sentence when it contains no unrelated clause. This
    # preserves "Precision was not measured." exactly, with punctuation.
    exact = []
    for c in found:
        sentence = next((m[0].strip() for m in re.finditer(r'[^.!?]+(?:[.!?](?=\s|$)|$)',context) if c in m[0]),c)
        if scope_conflict(part,sentence) and not scope_conflict(part,c):
            # An unqualified "that group" cannot inherit a foreign antecedent.
            key=re.sub(r'^(?:in|on|under|for)\s+', '', part['scope']['condition'], flags=re.I)
            if not key or not contains(key,c):
                continue
        if clauses(sentence)==[c] or (re.search(r'\b(?:that group|these|those)\b',c,re.I)
                and not any(scope_conflict(part,v) for v in clauses(sentence))):
            quote=sentence
        else:
            quote=c
        if quote in context and len(quote)<=ASSESSMENT_LIMITS['quote_chars']:
            exact.append(quote)
    return sorted(set(exact))


def focus_issue(result, part, context):
    from .assessment_members import empty_identity_required, empty_ledger_issue
    if empty_identity_required(part,context):
        return empty_ledger_issue(result)
    preferred = absence_quotes(part,context)
    for obs in result['observations']:
        issue = member_scope_issue(part,obs['member'],obs['quotes'],context)
        if issue:
            return issue
        issue = observation_focus_issue(part,obs['member'],obs['quotes'],obs['truth'],context)
        if issue:
            return issue
        if obs['truth']=='unknown' and preferred and not any(
                quote in cited for quote in preferred for cited in obs['quotes']):
            return 'missing_evidence_quote_required'
    if preferred and not result['observations']:
        return 'missing_evidence_quote_required'
    return None


def constrain_focus(schema, part, context):
    from copy import deepcopy
    from .assessment_members import empty_identity_required, constrain_empty_ledger, member_absence_quotes
    if empty_identity_required(part,context):
        return constrain_empty_ledger(schema)
    props = schema['properties']
    preferred = absence_quotes(part,context)
    original = props['observations']['items']
    branches = original.get('anyOf',[original])
    kept = []
    for branch in branches:
        obs = branch['properties']
        unknown = obs['truth']['enum']==['unknown']
        members = [m for m in obs['member'].get('enum',[]) if not scope_conflict(part,m)]
        quote_choices = preferred if unknown and preferred else obs['quotes']['items'].get('enum',[])
        groups = {}
        for member in members:
            truth = obs['truth']['enum'][0]
            local_absence = member_absence_quotes(part,member,context) if unknown else []
            choices = local_absence or quote_choices
            quotes = [q for q in choices if observation_focus_issue(part,member,[q],truth,context) is None]
            required = max(obs['quotes'].get('minItems',0),int(unknown and bool(preferred or local_absence)))
            if observation_focus_issue(part,member,[],truth,context):
                required = max(1,required)
            if required and not quotes:
                continue
            groups.setdefault((tuple(quotes),required,bool(local_absence)),[]).append(member)
        # Equivalent members share a branch; do not duplicate its numeric schema
        # once per source span, which slows the token filter without adding proof.
        for (quotes, required, local_absence), bound_members in groups.items():
            fixed = deepcopy(branch)
            values = fixed['properties']
            values['member'] = {'type':'string','enum':bound_members}
            if quotes:
                values['quotes']['items'] = {'type':'string','enum':list(quotes)}
            values['quotes']['minItems'] = required
            if unknown and (preferred or local_absence):
                values['quotes']['maxItems'] = 1
            elif not quotes:
                values['quotes']['maxItems'] = 0
            kept.append(fixed)
    if kept:
        props['observations']['items'] = {'anyOf':kept} if 'anyOf' in original or len(kept)>1 else kept[0]
    elif preferred:
        raise ValueError('unrepresentable_scoped_absence')
    else:
        # A context exclusively about another scope needs no invented witness.
        # Existing decisive-witness validation still rejects an empty dodge.
        props['observations']['minItems'] = 0
        props['observations']['maxItems'] = 0
    return schema



def observation_focus_issue(part, member, quotes, truth, context):
    issue = member_scope_issue(part,member,quotes,context)
    if issue:
        return issue
    from .assessment_members import member_identity_issue, member_absence_quotes
    # Missing status is local to this member; other members retain known outcomes.
    if truth != 'unknown' and member_absence_quotes(part,member,context):
        return 'missing_evidence_is_not_false'
    from .cellfix16_rules import relation_issue
    relation_error=relation_issue(part,member,quotes,truth,context)
    if relation_error:return relation_error
    identity_issue = member_identity_issue(part,member,truth,context)
    if identity_issue:
        return identity_issue
    if truth=='unknown':
        direct = member_absence_quotes(part,member,context)
        if direct and not any(q in cited for q in direct for cited in quotes):
            return 'missing_evidence_quote_required'
    # An absence assertion is evidence about availability, not an entity name.
    if _MISSING.search(member) and re.search(r'\b(?:was|were|is|are|has been|have been)\b',member,re.I):
        return 'observation_member_is_not_entity'
    if truth!='unknown' and absence_quotes(part,context):
        return 'missing_evidence_is_not_false'
    own = [c for q in quotes for c in clauses(q) if contains(member,c)]
    relevant = [c for c in own if metric_present(part,c) or _direct_absence(part,c)] or own
    if truth!='unknown' and relevant and all(_direct_absence(part,c) for c in relevant):
        return 'missing_evidence_is_not_false'
    return None


def atomic_property_truth(part, text, member):
    """Root subject + exact property direction only; no inferred coreference."""
    from .assessment_decisions import scope_supported
    from .numeric_verifier import numeric_requirements
    if (numeric_requirements(part['quote']) or numeric_requirements(text)
            or causal_claim(part) or not scope_supported(part,text)):
        return None
    if re.search(r'(?<!\w)(?:non-|un)'+re.escape(member),text,re.I):
        return None
    clean = text.strip(' .,;:')
    for restriction in (part['scope']['time'],part['scope']['condition']):
        if restriction:
            clean = re.sub(r'^'+re.escape(restriction)+r'\s*,?\s*','',clean,flags=re.I)
            clean = re.sub(r'\s*,?\s*'+re.escape(restriction)+r'$','',clean,flags=re.I)
    subject = r'(?:the\s+)?'+re.escape(member)
    metric = re.escape(part['scope']['metric'])
    verb = r'(?:increased|decreased|reduced|rose|fell|gained|lost|remained unchanged|stayed the same)'
    shape = subject+r"(?:'s\s+"+metric+r'\s+'+verb+r'|\s+'+verb+r'\s+(?:its\s+)?'+metric+r')'
    if not re.fullmatch(shape,clean,re.I):
        return None
    # The claim must also be a direct predicate about this exact target/property.
    claim = part['quote'].strip(' .,;:')
    for restriction in (part['scope']['time'],part['scope']['condition']):
        if restriction:
            claim = re.sub(r'^'+re.escape(restriction)+r'\s*,?\s*','',claim,flags=re.I)
            claim = re.sub(r'\s*,?\s*'+re.escape(restriction)+r'$','',claim,flags=re.I)
    if not re.fullmatch(shape,claim,re.I):
        return None
    return predicate_truth(part,text)


from .cellfix14_binding_rules import property_issue
_previous_focus=observation_focus_issue
def observation_focus_issue(part,member,quotes,truth,context):
    return property_issue(part,member,quotes,truth,context,_previous_focus)


from .cellfix14_runtime import cached
absence_quotes=cached(absence_quotes)
