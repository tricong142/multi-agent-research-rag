"""Bound evidence for a small set of explicit report forms."""
from decimal import Decimal
import re

from .cellfix14_runtime import cached

_TOKEN = r'[\w-]+'
_NUM = r'(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?'
_SPLIT = r'train(?:ing)?|dev(?:elopment)?|test(?:ing)?'
_POLY = re.compile(r'For (?:every|each) (?P<entity>(?P<unit>[\w-]+) in (?P<dataset>[\w -]+)), '
                   r'the authors (?P<metric>trained both a monolingual parser and parser variants with added '
                   r'(?P<language>[\w-]+) supervision)', re.I)
_UNITS = re.compile(r'(?P<entity>(?:The )?[\w -]+ systems) (?P<metric>were trained using '
                    r'(?P<first>[\w -]+?) and (?P<second>[\w -]+?) as basic units)', re.I)
_EXCLUSIVE_UNITS = re.compile(
    r'(?P<entity>(?:The )?[\w-]+ systems) (?P<metric>were trained (?:exclusively|only) on '
    r'(?P<first>[\w-]+) and (?P<second>[\w-]+) units)', re.I)
_ANNOTATION = re.compile(r'(?P<entity>(?:The )?(?P<name>[A-Z][A-Z0-9]+)) (?P<metric>contains '
                         r'(?P<object>[\w-]+ pairs) whose responses were manually labeled as '
                         r'(?:primarily )?(?P<first>[\w-]+(?: based)?) or (?P<second>[\w-]+(?: based)?))', re.I)
_COUNT = re.compile(rf'(?P<entity>(?:The )?(?P<dataset>{_TOKEN}) (?P<split>{_SPLIT}) split'
                    rf'(?P<experiment> used in the experiment)?) (?P<metric>contained (?:a total of )?'
                    rf'(?P<number>{_NUM}) (?P<unit>pairs|tokens))', re.I)
_F1 = re.compile(rf'(?P<entity>(?:The )?proposed (?P<task>{_TOKEN}) approach) '
                 rf'(?P<metric>achieved an average F1 score of (?P<number>{_NUM})) '
                 rf'(?P<condition>on (?:the )?(?P<dataset>{_TOKEN}) dataset)', re.I)
_COMPARE = re.compile(rf'The study found (?P<entity>{_TOKEN}) (?P<metric>more suitable than (?P<other>{_TOKEN})) '
                      r'(?P<condition>when the task domain differed from the training data domain|'
                      r'for tasks with a domain mismatch relative to the training data)', re.I)
_FORMS = (_POLY, _UNITS, _EXCLUSIVE_UNITS, _ANNOTATION, _COUNT, _F1, _COMPARE)
_SECTION = re.compile(rf'\(\d+\) (?P<dataset>{_TOKEN})(?![\w-])')
_SPLIT_COUNTS = re.compile(rf'(?P<first>{_NUM})/(?P<second>{_NUM})/(?P<third>{_NUM}) pairs for '
                          rf'(?P<a>{_SPLIT})/(?P<b>{_SPLIT})/(?P<c>{_SPLIT})\.', re.I)


def claim_form(quote):
    quote = quote.strip().rstrip('.')
    for form in _FORMS:
        match = form.fullmatch(quote)
        if match:
            return form, match
    return None, None


def predicate_roles(quote):
    form, match = claim_form(quote)
    if form is None:
        from .cellfix27_reports import claim_form as additional_form
        form, match = additional_form(quote)
    return match.groupdict() if match is not None else {}


def _sentences(text):
    return [m[0] for m in re.finditer(r'\S.*?(?:[.!?](?=\s|$)|$)', text, re.S)]


def _phase(text):
    return re.match(r'train|dev|test', text, re.I)[0].casefold()


def _number(text):
    return Decimal(text.replace(',', ''))


def _same(a, b):
    return a.casefold() == b.casefold()


def _polarity(value):
    return 'true' if value else 'false'


def training_unit_reports(entity, context):
    entity = re.sub(r'^the ', '', entity, flags=re.I)
    pattern = re.compile(rf'We trained (?P<member>{re.escape(entity)}) over the following basic units: '
                         r'(?P<items>[\w, -]+)\.', re.I)
    for quote in _sentences(context):
        found = pattern.fullmatch(quote)
        if found:
            items = {v.strip().casefold() for v in re.split(r',|\band\b', found['items'], flags=re.I)
                     if v.strip()}
            yield found['member'], quote, items


def _finite_sources(form, match, context):
    """Yield exact member, citations, predicate polarity and optional observed number."""
    if form is _COUNT:
        if match['unit'].casefold() != 'pairs':
            return
        sections = list(_SECTION.finditer(context))
        introduction = context[:sections[0].start()].strip() if sections else ''
        for i, section in enumerate(sections):
            if not _same(section['dataset'], match['dataset']):
                continue
            end = sections[i + 1].start() if i + 1 < len(sections) else len(context)
            tail = context[section.end():end]
            counts = list(_SPLIT_COUNTS.finditer(tail))
            if len(counts) != 1:
                continue
            if match['experiment'] and not re.search(r'\bwe experiment on\b[^.!?]*:$', introduction, re.I):
                continue
            packed = counts[0]
            if re.search(r'\b(?:not|never|only|hypothetical|planned|might|may|could)\b', tail[:packed.end()], re.I):
                continue
            phases = [_phase(packed[k]) for k in ('a', 'b', 'c')]
            if set(phases) != {'train', 'dev', 'test'}:
                continue
            observed = packed[('first', 'second', 'third')[phases.index(_phase(match['split']))]]
            quote = context[section.start():section.end() + packed.end()]
            quotes = [introduction, quote] if match['experiment'] else [quote]
            truth = _polarity(_number(observed) == _number(match['number']))
            yield section['dataset'], quotes, truth, (quote, observed, 'pairs', observed)
        return

    if form in (_UNITS, _EXCLUSIVE_UNITS):
        wanted = {match['first'].casefold(), match['second'].casefold()}
        for member, quote, items in training_unit_reports(match['entity'], context):
            if form is _EXCLUSIVE_UNITS:
                normalized = {re.sub(r' units?$', '', item) for item in items}
                yield member, [quote], _polarity(normalized == wanted), None
            elif all(w in items or (w.endswith('s') and w[:-1] in items) for w in wanted):
                yield member, [quote], 'true', None
        return

    sentences = _sentences(context)
    if form is _F1:
        from .cellfix27_reports import ner_reports
        for anchor, quote in ner_reports(match['task'], match['dataset'], sentences):
            found = re.fullmatch(
                rf'To address this issue we have presented and evaluated a (?P<member>novel approach) using the '
                rf'{re.escape(match["dataset"])} dataset, [^;]*?achieving an average of (?P<number>{_NUM}) F1\.', quote, re.I)
            if not found or re.search(r'\b(?:not|never|only|might|may|could|would|if|baseline|without achieving)\b', quote, re.I):
                continue
            value = found['number']
            truth = _polarity(_number(value) == _number(match['number']))
            yield found['member'], [anchor, quote], truth, (quote, value, 'F1', value + ' F1')
        return

    if form is _ANNOTATION:
        name = re.escape(match['name'])
        pattern = re.compile(
            rf'\b(?:[A-Z][\w-]+ ){{1,5}}Corpus \((?P<member>{name})\)(?:\s+BIBREF\d+)?\s*\.\s*'
            rf'This corpus includes {re.escape(match["object"])} that were manually annotated with respect to whether the response is primarily '
            rf'(?:an? )?{re.escape(match["first"])} or {re.escape(match["second"])}(?: argument)?(?=[,.])')
        for found in pattern.finditer(context):
            yield found['member'], [found[0]], 'true', None
        return

    for quote in sentences:
        if form is _POLY:
            found = re.fullmatch(
                rf'We train several parsers for (?P<member>(?:each|every) {re.escape(match["unit"])} in (?:the )?'
                rf'{re.escape(match["dataset"])} dataset)(?:\s+BIBREF\d+)?\s*:\s*a traditional monolingual version,? '
                rf'and variants which additionally incorporate supervision from (?:the )?{re.escape(match["language"])} portion of the dataset\.', quote, re.I)
            if found:
                yield found['member'], [quote], 'true', None
        elif form is _COMPARE:
            found = re.fullmatch(
                rf'(?:It was (?:also )?observed that )?(?P<first>{_TOKEN}) (?:are|were) more suitable than (?P<second>{_TOKEN}) '
                r'for tasks whose domain does not match that of the training data(?:, such as [\w -]+)?\.', quote, re.I)
            if not found or re.search(r'\b(?:except|unless|only|not always)\b', quote, re.I):
                continue
            if _same(found['first'], match['entity']) and _same(found['second'], match['other']):
                yield found['first'], [quote], 'true', None
            elif _same(found['second'], match['entity']) and _same(found['first'], match['other']):
                yield found['second'], [quote], 'false', None


@cached
def source_ledger(part, context):
    """Shortcut: verified report grammars only. Other forms use the regular ledger."""
    from .atomic_verifier import ASSESSMENT_LIMITS, numeric_requirements
    from .assessment_reporting import ASSESSMENT_NOTE, OBSERVATION_NOTE
    from . import cellfix27_reports as reports

    form, match = claim_form(part['quote'])
    complete = form is _POLY
    if form is not None:
        if part['quantifier'] != ('all' if complete else 'atomic'):
            return None
        facts = [(*fact, None) for fact in _finite_sources(form, match, context)]
    else:
        form, match = reports.claim_form(part['quote'])
        if form is None or part['quantifier'] != reports.expected_quantifier(form):
            if reports.ambiguous_response_time(part, context):
                return dict(scope_match='unknown', coverage=dict(complete=False, members=[], quotes=[]),
                            observations=[], missing_information=['comparison_unresolved'],
                            explanation=ASSESSMENT_NOTE), None
            return None
        complete = form is reports._PROCEDURE
        facts = [(member, quotes, _polarity(truth), measured, low)
                 for member, quotes, truth, measured, low in reports.report_facts(form, match, part, context)]
    if len(facts) != 1:
        return None
    member, quotes, truth, measured, low = facts[0]
    if len(member) > ASSESSMENT_LIMITS['member_chars']:
        return None
    if any(not q or q not in context or len(q) > ASSESSMENT_LIMITS['quote_chars'] for q in quotes):
        return None
    record = checked = None
    if measured:
        reqs = numeric_requirements(part['quote'])
        if len(reqs) != 1 or reqs[0]['value'] != str(_number(match['number'])):
            return None
        req = reqs[0]
        proof, value, unit, observed = measured
        if observed not in proof:
            return None
        kind = 'range' if low is not None else 'value'
        record = dict(kind=kind, source_quote=proof, left={k: req[k] for k in ('value', 'unit', 'quote')},
                      right=dict(value=str(_number(value)), unit=unit, quote=observed))
        checked = dict(kind=kind, input=record, truth=truth, reason='explicit_scoped_report',
                       left=req['value'], right=record['right']['value'], unit=unit, requirement=req)
        if low is not None:
            checked.update(reason='upper_bound_refutes_strict_threshold',
                           lower_bound=str(_number(low)), upper_bound=record['right']['value'])
    raw = dict(scope_match='matched',
               coverage=dict(complete=complete, members=[member] if complete else [], quotes=quotes if complete else []),
               observations=[dict(member=member, truth=truth, quotes=quotes, explanation=OBSERVATION_NOTE, numeric=record)],
               missing_information=[], explanation=ASSESSMENT_NOTE)
    return raw, checked


def literal_schema(value):
    from .atomic_decoding import array, obj
    if isinstance(value, dict):
        return obj({k:literal_schema(v) for k,v in value.items()})
    if isinstance(value, list):
        if len(value)>1:
            return {'type':'array','const':value}
        items = literal_schema(value[0]) if value else {'type':'string'}
        return array(items, minimum=len(value), maximum=len(value))
    if isinstance(value, bool):
        return {'const':value}
    if value is None:
        return {'type':'null'}
    return {'type':'string','enum':[value]}


def _same_quotes(actual, expected):
    return (isinstance(actual, list) and all(isinstance(q, str) for q in actual)
            and sorted(actual) == sorted(expected))


def assess_ledger(raw, part, context, expected, numeric):
    from .atomic_verifier import numeric_requirements
    from .assessment_reporting import render
    if not expected['observations']:
        if raw != expected or type(raw['coverage']['complete']) is not bool:
            raise ValueError('decisive_witness_missing_or_unknown')
        result = dict(part=part, numeric_requirements=numeric_requirements(part['quote']),
                      assessed_label='not_enough_info', observations=[], explanation=raw['explanation'],
                      coverage=raw['coverage'], scope_match=raw['scope_match'], missing_information=[],
                      model_explanation=raw['explanation'], validation_issues=[])
        return render(result, raw, part, context)
    observations = raw.get('observations') if isinstance(raw,dict) else None
    if not isinstance(observations,list) or len(observations)!=1 or not isinstance(observations[0],dict):
        raise ValueError('decisive_witness_missing_or_unknown')
    obs = observations[0]
    quotes = obs.get('quotes')
    wanted = expected['observations'][0]['quotes']
    coverage = raw.get('coverage')
    coverage_quotes = expected['coverage']['quotes']
    if (not isinstance(coverage, dict) or type(coverage.get('complete')) is not bool
            or not _same_quotes(quotes, wanted) or not _same_quotes(coverage.get('quotes'), coverage_quotes)
            or {**raw, 'coverage':{**coverage,'quotes':coverage_quotes},
                'observations':[{**obs,'quotes':wanted}]}!=expected):
        raise ValueError('decisive_witness_missing_or_unknown')
    support = obs['truth'] == ('false' if part['quantifier'] == 'none' else 'true')
    result = dict(part=part,numeric_requirements=numeric_requirements(part['quote']),
                  assessed_label='support' if support else 'contradict',
                  observations=[{**obs,'numeric_result':numeric,'citation_additions':[],'model_truth':obs['truth']}],
                  explanation=raw['explanation'],coverage=raw['coverage'],scope_match=raw['scope_match'],
                  missing_information=[],model_explanation=raw['explanation'],validation_issues=[])
    return render(result,raw,part,context)
