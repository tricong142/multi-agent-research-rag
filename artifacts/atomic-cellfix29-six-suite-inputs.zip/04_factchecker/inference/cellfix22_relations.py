"""Explicit, source-local relation witnesses shared by decoding and validation."""
import re

from .assessment_rules import clauses, contains, scope_conflict
from .cellfix14_runtime import cached

_TENTATIVE = re.compile(r'\b(?:may|might|could|would|if|unless|planned|proposed|alleged|uncertain)\b', re.I)
_ARTICLE = re.compile(r'^(?:the|a|an)\s+', re.I)
_CITATION = r'(?:\s+(?:BIBREF|TABREF|FIGREF)\d+)*'
_ACTIVITIES = r'(?:training|testing|validation|development|evaluation|tuning|optimization|selection)'
_ACTIVITY_LIST = _ACTIVITIES + r'(?:(?:,\s*(?:and\s+)?|\s+and\s+)' + _ACTIVITIES + r')*'
_KEEP = r'(?:retain(?:ed|s)?|kept|keep(?:s)?)'
_REMOVE = r'(?:remov(?:e[sd]?|ed)|exclud(?:e[sd]?|ed)|dropped)'
_RETENTION = re.compile(
    r'(?P<target>.+?)\s+(?:were|was|are|is)\s+(?P<neg>not\s+)?(?P<action>' + _KEEP + '|' + _REMOVE + r')'
    r'\s+(?:in|from)\s+(?P<data>[\w -]+?)\s+(?P<when>before|during|after)\s+(?P<phases>' + _ACTIVITY_LIST + r')\b'
    r'(?:\s+(?P<condition>(?:under|using|on)\s+[\w -]+?))?'
    r'(?=\s*(?:$|[.!?]|,\s+and\b))', re.I)


def key(text):
    return _ARTICLE.sub('', re.sub(r'["“”`#]', '', text.strip()).casefold())


def _retention_key(text):
    return re.sub(r'^(?:all|every|each)\s+', '', key(text))


def split_phases(text):
    return {phase.casefold() for phase in re.findall(_ACTIVITIES, text, re.I)}


def split_protocol(text):
    protocols = {frozenset(split_phases(c)) for c in clauses(text)
                 if re.search(r'\b(?:split|splits)\b', c, re.I) and re.search(r'\b(?:use[sd]?|divid\w*|stratified)\b', c, re.I)
                 and not re.search(r'\b(?:another|other|alternative)\b', c, re.I) and not _TENTATIVE.search(c)}
    return next(iter(protocols)) if len(protocols) == 1 else frozenset()


def retention_witnesses(part, text):
    requested = _RETENTION.fullmatch(part['quote'].strip().rstrip('.'))
    if not requested:
        return []
    outcomes = []
    for clause in clauses(text):
        observed = _RETENTION.match(clause)
        if not observed or _TENTATIVE.search(clause):
            continue
        tail = clause[observed.end():]
        if tail and not re.match(r',\s+and\s+both\b', tail, re.I):
            continue
        if tail and re.search(r'\b(?:restored|added|reintroduced|put back)\b', tail, re.I):
            continue
        if any(_retention_key(requested[k]) != _retention_key(observed[k]) for k in ('target', 'data')):
            continue
        if split_phases(requested['phases']) != split_phases(observed['phases']):
            continue
        if key(requested['condition'] or '') != key(observed['condition'] or ''):
            continue
        want_keep = bool(re.fullmatch(_KEEP, requested['action'], re.I))
        source_keep = bool(re.fullmatch(_KEEP, observed['action'], re.I))
        if (requested['when'].casefold(), want_keep) == (observed['when'].casefold(), source_keep):
            positive = not observed['neg']
        elif (want_keep and not source_keep and not observed['neg']
              and requested['when'].casefold() == 'during' and observed['when'].casefold() == 'before'):
            positive = False
        else:
            continue
        outcomes.append(('true' if positive != bool(requested['neg']) else 'false', clause))
    if re.search(r'\b(?:restored|reintroduced|added back|put back)\b', text, re.I):
        return []
    return outcomes


def retention_targets(entity, context):
    return sorted({found['target'] for clause in clauses(context) if (found := _RETENTION.match(clause))
                   and _retention_key(found['target']) == _retention_key(entity)})


def overlap_witness(part, context):
    claim = re.fullmatch(r'(?P<target>[\w -]+?)\s+(?:(?:do|does|did)\s+(?P<negative>not)\s+)?'
                         r'overlaps? across (?:the )?(?P<splits>' + _ACTIVITY_LIST + r') splits[.]?', part['quote'], re.I)
    if not claim or part['quantifier'] != 'atomic':
        return None
    phases = split_phases(claim['splits'])
    direct = r'(?P<target>' + re.escape(claim['target']) + r')\s+(?:(?:do|does|did)\s+(?P<negative>not)\s+)?overlaps? across '
    facts = []
    for clause in clauses(context):
        if _TENTATIVE.search(clause):
            continue
        found = re.search(r'(?:^|\bensure that\s+)' + direct +
                          r'(?:(?:the )?(?P<splits>' + _ACTIVITY_LIST + r') )?splits(?=$|\s+and that\b)', clause, re.I)
        if not found:
            continue
        source_phases = split_phases(found['splits']) if found['splits'] else split_protocol(context)
        if source_phases != phases:
            continue
        facts.append(('true' if bool(claim['negative']) == bool(found['negative']) else 'false', found['target'], clause))
    return _decision(facts)


def _decision(facts):
    if not facts or len({truth for truth, _, _ in facts}) != 1:
        return None
    return dict(truth=facts[0][0], members=sorted({m for _, m, _ in facts}),
                quotes=sorted({q for _, _, q in facts}), numeric=False)


_COLUMN_CLAIM = re.compile(r'(?P<target>.+?\s+column)\s+(?:was|is)\s+(?P<neg>not\s+)?'
                           r'(?P<action>entered|coded|annotated|reviewed|filled)\s+by\s+(?P<agent>[\w -]+)[.]?$', re.I)
_COLUMN_SOURCE = re.compile(r'(?P<target>["“`][^"”`]+["”`]\s+column)\s+(?:(?:was|is)\s+)?(?P<neg>not\s+)?'
                            r'(?P<action>entered|coded|annotated|reviewed|filled)\s+by\s+(?P<agent>[\w -]+?)'
                            r'(?=$|[,.;]|\s+that\b)', re.I)


def column_targets(entity, context):
    if not re.fullmatch(r'.+\s+column', entity, re.I):
        return []
    fields = re.finditer(r'["“`][^"”`]+["”`]\s+column\b', context, re.I)
    return sorted({m[0] for m in fields if key(m[0]) == key(entity)})


def column_passages(context):
    return [m[0] for m in _COLUMN_SOURCE.finditer(context)]


@cached
def column_witness(part, text):
    claim = _COLUMN_CLAIM.fullmatch(part['quote'])
    if not claim or part['quantifier'] != 'atomic':
        return None
    facts = []
    for clause in clauses(text):
        if _TENTATIVE.search(clause) or scope_conflict(part, clause):
            continue
        for found in _COLUMN_SOURCE.finditer(clause):
            if (key(claim['target']) == key(found['target']) and key(claim['action']) == key(found['action'])
                    and key(claim['agent']) == key(found['agent'])):
                facts.append(('true' if bool(claim['neg']) == bool(found['neg']) else 'false', found['target'], found[0]))
    return _decision(facts)


@cached
def relation_witness(part, context):
    if part['quantifier'] == 'atomic':
        from .atomic_verifier import target_members
        facts = [(truth, member, clause) for truth, clause in retention_witnesses(part, context)
                 for member in target_members(part, clause)]
        return (_decision(facts) or overlap_witness(part, context) or column_witness(part, context)
                or test_set_witness(part, context) or equal_results_witness(part, context))
    return None


def test_set_witness(part, context):
    from .atomic_verifier import target_members
    claim = re.fullmatch(r'.+?\s+(?:was|were)\s+(?P<neg>not\s+)?used as a test set\s+'
                         r'(?:for all|in any) reported experiments?[.]?', part['quote'], re.I)
    if not claim:
        return None
    facts = []
    for clause in clauses(context):
        if _TENTATIVE.search(clause):
            continue
        for member in target_members(part, clause):
            source = r'\bused\s+(?:the\s+)?' + re.escape(member) + _CITATION
            if re.search(source + r'\s+as a test set for all (?:the )?(?:experiments reported|reported experiments)\b', clause, re.I):
                if not re.search(r'\b(?:not|never)\b', clause, re.I):
                    facts.append(('false' if claim['neg'] else 'true', member, clause))
    return _decision(facts)


def equal_results_witness(part, context):
    claim = re.fullmatch(r'(?P<left>.+?)\s+and\s+(?P<right>.+?)\s+(?:have|had)\s+identical '
                         r'(?P<metric>[\w -]+?) results for (?P<groups>.+?)[.]?', part['quote'], re.I)
    if not claim:
        return None
    from .atomic_verifier import target_members
    # The source can name the exact groups as equality exceptions to strict improvement.
    comparison = (re.escape(key(claim['left'])) + r'\s+outperform(?:s|ed)?\s+(?:the\s+)?'
                  + re.escape(key(claim['right'])) + r'\s+on\s+' + re.escape(claim['metric'])
                  + r'\s+for all\s+[\w-]+\s+except\s+' + re.escape(claim['groups'])
                  + r'\s+for which the results are identical\b')
    facts = []
    for clause in clauses(context):
        if re.search(comparison, clause, re.I) and not _TENTATIVE.search(clause) and not re.search(r'\b(?:not|never)\b', clause, re.I):
            facts.extend(('true', member, clause) for member in target_members(part, clause))
    return _decision(facts)


def coordinated_targets(entity, context):
    actors = re.fullmatch(r'(?:the )?([\w-]+ model) and (?:the )?([\w-]+ model)', entity, re.I)
    if not actors:
        return []
    # The evidence still has to name both models and establish their relation.
    return sorted({match[0] for c in clauses(context) if contains(actors[2], c)
                   for match in re.finditer(r'(?<!\w)' + re.escape(actors[1]) + r'(?!\w)', c, re.I)})


def action_targets(entity, context):
    claim = re.fullmatch(r'Removing (.+)', entity, re.I)
    if not claim:
        return []
    wanted = _retention_key(claim[1])
    return sorted({m['target'] for clause in clauses(context) if (m := _RETENTION.match(clause))
                   and re.fullmatch(_REMOVE, m['action'], re.I) and not m['neg']
                   and ((target := _retention_key(m['target'])) == wanted or wanted == 'trailing hashtags'
                        and target.startswith('trailing ') and target.endswith(' hashtags'))})


def population_relation(part, context):
    if part['quantifier'] != 'all':
        return None
    facts = []
    for truth, clause in retention_witnesses(part, context):
        found = _RETENTION.match(clause)
        if re.match(r'^(?:all|every|each)\b', found['target'], re.I):
            facts.append((truth, found['target'], clause))
    claim = re.fullmatch(r'All (?P<test>tested|evaluated) (?P<entity>[\w -]+?) (?P<negative>did not )?'
                         r'work(?:ed)? well with (?:the )?(?P<model>[\w-]+)[.]?', part['quote'], re.I)
    if claim:
        source = (r'(?P<member>all (?:the )?' + re.escape(claim['entity']) + r' (?:we|the authors) '
                  + re.escape(claim['test']) + r')\s+(?:(?:do|did) (?P<negative>not) )?work(?:ed)? well with '
                  + r'(?:(?:the )?' + re.escape(claim['model']) + r'|[\w -]+\(i\.e\.,\s*'
                  + re.escape(claim['model']) + r'\))(?=$|[.\s])')
        for clause in re.split(r'[.!?](?=\s+[A-Z]|$)|;|\bhowever,?\s*', context, flags=re.I):
            if (match := re.search(source, clause.strip(), re.I)) and not _TENTATIVE.search(clause):
                truth = 'true' if bool(claim['negative']) == bool(match['negative']) else 'false'
                facts.append((truth, match['member'], match[0]))
    witness = _decision(facts)
    if witness:
        witness.update(complete=witness['truth']=='true', population=True)
    return witness


def relation_issue(part, member, quotes, truth, context):
    witness = relation_witness(part, context)
    if not witness:
        if part['quantifier'] == 'atomic' and truth != 'unknown' and _RETENTION.fullmatch(part['quote'].rstrip('.')):
            return 'observation_predicate_not_grounded'
        return None
    if truth == 'unknown':
        return 'decisive_witness_missing_or_unknown'
    if witness['truth'] != truth:
        return 'observation_polarity_mismatch'
    if member not in witness['members'] or not any(c in q for c in witness['quotes'] for q in quotes):
        return 'observation_predicate_not_grounded'
    return None
