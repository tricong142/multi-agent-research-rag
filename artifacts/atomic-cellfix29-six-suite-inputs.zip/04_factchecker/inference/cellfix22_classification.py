"""Bind a classification count and optional explicit roster to its object."""
import re

from .cellfix22_relations import key, _TENTATIVE
from .evidence_screen import WORDS

_COUNT = r'(?:\d+|' + '|'.join(WORDS) + r')'
_RELATION = r'(?:classif(?:y|ies|ied)|categori[sz](?:e[sd]?|ed)|group(?:s|ed)?)'
_TAIL = (r'\s+into\s+(?P<count>' + _COUNT + r'\s+(?P<unit>categories|groups|classes|types))'
         r'(?:\s*(?:[:–—]|\s-)\s*(?P<labels>[^.;]+))?\s*[.]?')
_PASSIVE = re.compile(r'(?P<object>[\w -]+?)\s+(?:is|are|was|were)\s+' + _RELATION + _TAIL, re.I)
_ACTIVE = re.compile(r'(?:Then,?\s+)?(?:we|the authors|the researchers|[A-Z][\w-]+)\s+' + _RELATION +
                     r'\s+(?P<object>[\w -]+?)' + _TAIL, re.I)


def _labels(found):
    if not found['labels']:
        return set()
    head = key(found['object']).split()[-1].rstrip('s')
    labels = re.split(r',\s*(?:and\s+)?|\s+and\s+', found['labels'], flags=re.I)
    return {re.sub(r'\s+' + re.escape(head) + r's?$', '', key(s)) for s in labels if s.strip()}


def classification_measurement(raw, claim):
    """Return a local measurement and whether its operands describe the claim."""
    requested = _PASSIVE.fullmatch(claim.strip())
    if not requested or raw.get('kind') != 'value':
        return None
    from .assessment_rules import clauses
    wanted = _labels(requested)
    proof = raw['source_quote']
    for clause in clauses(proof):
        found = _PASSIVE.fullmatch(clause) or _ACTIVE.fullmatch(clause)
        if not found or _TENTATIVE.search(clause) or key(found['object']) != key(requested['object']):
            continue
        if found['unit'].casefold() != requested['unit'].casefold():
            continue
        if raw['left']['quote'] != requested['count'] or raw['right']['quote'] != found['count']:
            continue
        # Different counts decide the claim even if the source omits the roster.
        # Equal counts need the explicitly claimed names as well.
        names = _labels(found)
        if raw['left']['value'] != raw['right']['value'] or not wanted or names == wanted:
            return clause, True
    return proof, False
