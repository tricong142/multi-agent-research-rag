"""Finite population subjects and explicitly linked allocation counts."""
import re


def subject_issue(scope, quote, previous):
    from .cellfix22_scope import subject_quantifier_text
    entity = scope['entity']
    quantifier = re.search(r'\b(?:all|every|each|some|none)\b', subject_quantifier_text(quote), re.I)
    start = quote.find(entity)
    if quantifier and start >= 0 and start < quantifier.start() < start + len(entity):
        return 'quantified_population_required'
    return previous(scope, quote)


def allocation_witness(part, context):
    from .numeric_verifier import numeric_requirements
    if part['quantifier'] != 'all':
        return None
    if re.search(r'\b(?:not|never|however|might|may|could|would|reportedly)\b', context, re.I):
        return None
    claim = re.fullmatch(
        r'(?P<subject>[\w -]+?) (?:reserves?|reserved|allocates?|allocated|assigns?|assigned) '
        r'all (?P<count>\d+) (?P<noun>[\w-]+) for (?P<role>training|testing|validation|development)[.]?',
        part['quote'], re.I)
    requirements = numeric_requirements(part['quote'])
    if not claim or len(requirements) != 1:
        return None
    entity = re.sub(r'^all\s+', '', part['scope']['entity'], flags=re.I)
    if entity != requirements[0]['quote']:
        return None
    declaration = re.search(
        r'(?<!\w)' + re.escape(claim['subject']) + r'(?: BIBREF\d+)? '
        r'(?:is a [\w -]+ consisting of|contains?|contained|consists? of) '
        r'(?P<members>' + re.escape(claim['count']) + r' (?:[\w-]+ ){0,3}'
        + re.escape(claim['noun']) + r')\b[^.!?]*[.]', context, re.I)
    if not declaration:
        return None
    subset = re.match(
        r'\s*Of these ' + re.escape(claim['noun']) + r', (?P<count>\d+) '
        r'(?:are |were )?(?:reserved|allocated|assigned) for ' + re.escape(claim['role']) + r'\b',
        context[declaration.end():], re.I)
    if not subset or not 0 <= int(subset['count']) < int(claim['count']):
        return None
    proof = context[declaration.start():declaration.end() + subset.end()]
    if len(proof) > 384:
        return None
    record = dict(kind='value', source_quote=proof,
                  left={k: requirements[0][k] for k in ('value', 'unit', 'quote')},
                  right=dict(value=subset['count'], unit='', quote=subset['count']))
    return dict(truth='false', members=[declaration['members']], quotes=[proof], numeric=True, record=record)


def allocation_check(raw, claim, context, metric, previous):
    result = previous(raw, claim, context, metric=metric)
    if result['reason'] not in {'unit_mismatch_no_conversion', 'numeric_metric_binding_unresolved'}:
        return result
    from .numeric_verifier import numeric_requirements
    requirements = numeric_requirements(claim)
    if len(requirements) != 1:
        return result
    part = dict(quote=claim, quantifier='all',
                scope=dict(entity=requirements[0]['quote'], metric=metric, time='', condition=''))
    witness = allocation_witness(part, context)
    if witness and raw == witness['record']:
        return {**result, 'truth': 'false', 'reason': 'explicit_allocation_subset'}
    return result


def bound_member_arrays(schema):
    props = schema['properties']
    observations = props['observations']
    branches = observations['items'].get('anyOf', [observations['items']])
    members = {m for branch in branches for m in branch['properties']['member'].get('enum', [])}
    observations['maxItems'] = min(observations['maxItems'], len(members))
    for branch in props['coverage'].get('anyOf', [props['coverage']]):
        names = branch['properties']['members']
        if 'enum' in names['items']:
            names['maxItems'] = min(names['maxItems'], len(set(names['items']['enum'])))
    return schema
