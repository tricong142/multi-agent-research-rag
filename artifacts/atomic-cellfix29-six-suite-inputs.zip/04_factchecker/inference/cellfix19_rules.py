"""Nominal subjects and explicit exclusive-subset evidence; no case IDs or gold."""
import re


def quantified_object(quote):
    match = re.fullmatch(r'[\w -]+? (?:reserves?|reserved|allocates?|allocated|assigns?|assigned|targets?|selects?|evaluates?|examines?) '
                         r'all (?P<object>[\w -]+?) (?:for|from) [\w -]+[.]?', quote, re.I)
    return match['object'] if match else None


def subject_issue(scope, quote, previous):
    if re.fullmatch(r'(?:the|a|an|all|every|each|some|none|this|that|these|those|of|in|on|for|and|or|is|are)(?:\s+(?:the|a|an|of))*', scope['entity'], re.I):
        return 'entity_reference_required'
    population = quantified_object(quote)
    if population and scope['entity'] not in {population, 'all ' + population}:
        return 'quantified_population_required'
    return previous(scope, quote)


def selection_witness(part, context, *, bind_qualifiers=True):
    """A declared source set followed by an actor's exclusive proper subset.

    shortcut: finite English selection grammar, not general discourse resolution.
    Unbound actors, sources, modifiers and contradictory counts remain undecided.
    """
    from .numeric_verifier import numeric_requirements
    if part['quantifier'] != 'all':
        return None
    claim = re.fullmatch(r'(?P<actor>The [\w -]+?) (?P<verb>targets?|selects?|evaluates?|examines?) all '
                         r'(?P<object>[\w -]+?) from (?:the )?(?P<source>[\w -]+?)[.]?', part['quote'], re.I)
    requirements = numeric_requirements(part['quote'])
    if not claim or len(requirements) != 1:
        return None
    left = requirements[0]
    entity = re.sub(r'^all ', '', part['scope']['entity'], flags=re.I)
    if entity != left['quote'] or claim['object'] != left['quote']:
        return None
    if part['scope']['time'] or part['scope']['condition'].lower() not in {'', 'from the '+claim['source'].lower(), 'from '+claim['source'].lower()}:
        return None
    head = left['unit'].lower()
    # These aliases are limited to an explicitly enumerated category/type roster.
    if head not in {'categories', 'types', 'named-entity categories'}:
        return None
    if head == 'named-entity categories' and bind_qualifiers:
        # "Types" alone does not identify a named-entity taxonomy. This finite
        # original-dataset reference needs exactly one explicit NER antecedent.
        antecedents = re.findall(r'\bnamed entity[- ]annotated (?:[\w-]+\s+){0,3}dataset\b', context, re.I)
        if claim['source'].lower() != 'original dataset' or len(antecedents) != 1:
            return None
    number = r'(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)'
    actor = re.sub(r'^The ', '', claim['actor'], flags=re.I)
    verb = claim['verb'].lower().rstrip('s')
    source = re.escape(claim['source'])
    declaration = r'(?:The )?' + source + r' (?:includes?|contains?|lists?) [^.!?]*?'
    declaration += r'(?P<total>' + number + r' (?:categories|types))\s*:\s*(?P<roster>[^.!?]+)[.]'
    matches = list(re.finditer(declaration, context, re.I))
    facts = []
    for match in matches:
        total = numeric_requirements(match['total'])
        roster = [v.strip() for v in re.split(r',\s*|\s+and\s+', match['roster']) if v.strip()]
        if len(total) != 1 or total[0]['value'] != left['value'] or len(roster) != int(left['value']):
            continue
        if head == 'named-entity categories' and not re.search(r'\bnamed (?:entity[ -])?annotations?\b', match[0], re.I):
            continue
        follow = re.match(r'\s*(?:However, )?(?:in this ' + re.escape(actor) + r', we|The ' + re.escape(actor) + r') '
                          + re.escape(verb) + r'(?:s)? only (?:at )?(?:the )?(?:first )?'
                          r'(?P<subset>' + number + r' (?:categories|types))\b[^.!?]*[.]', context[match.end():], re.I)
        if not follow:
            continue
        right = numeric_requirements(follow['subset'])
        proof = context[match.start():match.end() + follow.end()]
        if (len(right) != 1 or not 0 < int(right[0]['value']) < int(left['value']) or len(proof) > 768
                or re.search(r'\b(?:not|never|might|may|could|would|reportedly|hypothetical)\b', proof, re.I)):
            continue
        # Do not choose one report when additional selection reports may conflict.
        if len(re.findall(r'\b' + re.escape(verb) + r'(?:s)?\b', context, re.I)) != 1:
            continue
        record = dict(kind='value', source_quote=proof,
                      left={k: left[k] for k in ('value', 'unit', 'quote')},
                      right={k: right[0][k] for k in ('value', 'unit', 'quote')})
        facts.append(dict(truth='false', members=[match['total']], quotes=[proof], numeric=True, record=record))
    return facts[0] if len(facts) == 1 else None


def selection_check(raw, claim, context, metric, previous):
    result = previous(raw, claim, context, metric=metric)
    from .numeric_verifier import numeric_requirements
    required = numeric_requirements(claim)
    if len(required) != 1:
        return result
    part = dict(quote=claim, quantifier='all',
                scope=dict(entity=required[0]['quote'], metric=metric, time='', condition=''))
    witness = selection_witness(part, context)
    if witness and raw == witness['record']:
        return {**result, 'truth': 'false', 'reason': 'explicit_exclusive_subset'}
    return result
