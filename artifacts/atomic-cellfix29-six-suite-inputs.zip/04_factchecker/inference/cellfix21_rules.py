"""Source-bound coordination, comparisons and explicit polarity; no evaluation IDs."""
import re


def unsupported_logic(claim):
    from .cellfix26_evidence import _ANNOTATION, claim_form
    if claim_form(claim)[0] is _ANNOTATION:
        return False
    if re.search(r'\b(?:either|unless|not both)\b', claim, re.I):
        return True
    for match in re.finditer(r'\bor\b', claim, re.I):
        right = claim[match.end():]
        # Finite shared-head nominal alternatives; propositional OR remains unsupported.
        if not re.match(r'\s+[\w-]+\s+(?:hashtags|categories|types|labels|features|attributes)\s+(?:were|was|are|is)\b', right, re.I):
            return True
    return False


def conjunctions(claim, previous):
    from .cellfix22_scope import nominal_coordination
    from .cellfix26_evidence import _EXCLUSIVE_UNITS, _POLY, _UNITS, claim_form
    from .cellfix27_reports import _TAXONOMY, claim_form as report_form
    if claim_form(claim)[0] in (_POLY, _UNITS, _EXCLUSIVE_UNITS) or report_form(claim)[0] is _TAXONOMY:
        return []
    result = []
    for match in previous(claim):
        left, right = claim[result[-1].end() if result else 0:match.start()], claim[match.end():]
        if nominal_coordination(left, right):
            continue
        # Noun lists and temporal/activity pairs are one argument, not two propositions.
        if (re.search(r'\b(?:for|before|during|after|across|both|between|into)\b[^.;]*$', left, re.I)
                or re.search(r':[^.;]*$', left)) and re.fullmatch(r'\s*[\w, -]+[.]?\s*', right):
            from .cellfix14_decomposition import _VERB
            words=right.strip(' .').split()
            nominal = bool(words and (words[-1].lower() in {'training','testing','validation','development','optimization','evaluation','tuning','selection','splits','occupations','categories','types','labels','features','attributes','languages','datasets','sets'}
                or all(w[:1].isupper() for w in words) or ':' in left))
            if nominal and not re.match(r'\s*(?:the|a|an)\b',right,re.I) and not _VERB.search(right):
                continue
        result.append(match)
    return result


def comparison_issue(part, member, quotes, truth):
    if truth == 'unknown':
        return None
    claim = re.search(r'\b(?P<direction>fewer|more|less)\s+(?P<metric>[\w -]+?)\s+than\s+(?P<other>[^.!?]+)', part['quote'], re.I)
    if not claim:
        return None
    # Presence of the subject alone does not establish a comparative measurement.
    pattern = (r'(?<!\w)' + re.escape(member) + r'\s+(?:uses?|used|has|had|requires?|required)\s+'
               + r'(?P<direction>fewer|more|less)\s+' + re.escape(claim['metric'])
               + r'\s+than\s+(?:the\s+)?' + re.escape(claim['other'].strip()) + r'(?!\w)')
    states = set()
    for q in quotes:
        proof = re.search(pattern, q, re.I)
        if proof and not re.search(r'\b(?:might|may|could|not|never|if)\b', q, re.I):
            same = (proof['direction'].lower() == 'more') == (claim['direction'].lower() == 'more')
            states.add('true' if same else 'false')
    if not states:
        return 'comparison_predicate_evidence_required'
    return None if states == {truth} else 'observation_polarity_mismatch'


def existence_truth(part, member, text):
    match = re.search(r'\b(?P<neg>(?:did|does|do)\s+not\s+)?contain(?:s|ed)?\s+(?:any\s+)?(?P<object>[\w -]+)[.]?$', part['quote'], re.I)
    if not match or re.search(r'\b(?:might|may|could|would|if|alleged|planned)\b', text, re.I):
        return None
    source = re.search(r'(?<!\w)' + re.escape(member) + r'\s+(?:contain(?:s|ed)?|contains)\s+(?P<n>\d[\d,]*)\s+'
                       + re.escape(match['object'].strip(' .')) + r'(?!\w)', text, re.I)
    if not source or re.search(r'\b(?:not|never|without)\b', text[:source.end()], re.I):
        return None
    positive = int(source['n'].replace(',', '')) > 0
    return 'true' if positive != bool(match['neg']) else 'false'


def relation_issue(part, member, quotes, truth, context, previous):
    from .cellfix22_relations import relation_issue as checked_relation
    issue = checked_relation(part, member, quotes, truth, context)
    if issue:
        return issue
    issue = comparison_issue(part, member, quotes, truth)
    if issue:
        return issue
    if truth != 'unknown':
        states = {existence_truth(part, member, q) for q in quotes} - {None}
        if states and states != {truth}:
            return 'observation_polarity_mismatch'
    return previous(part, member, quotes, truth, context)


def source_targets(part, context, previous):
    from .atomic_verifier import target_entity
    from .cellfix22_relations import action_targets, column_targets, coordinated_targets, retention_targets
    entity = target_entity(part)
    typed = column_targets(entity, context)
    if typed:
        return typed
    found = previous(part, context)
    if found:
        return found
    typed = coordinated_targets(entity, context) or action_targets(entity, context)
    if not typed and re.search(r'\b(?:retained|removed|excluded|kept|dropped)\b', part.get('quote', ''), re.I):
        typed = retention_targets(entity, context)
    if typed:
        return typed
    # Quotes around a field name do not create a different field. Return original bytes.
    words = entity.split()
    if len(words) >= 2:
        pattern = r'(?<!\w)' + r'["“”`\x27]*\s*'.join(map(re.escape, words)) + r'(?!\w)'
        found = sorted({m[0] for m in re.finditer(pattern, context, re.I)})
        if found:
            return found
    # A restrictive relative clause may express the same tested noun phrase.
    tested = re.fullmatch(r'tested (.+)', entity, re.I)
    if tested:
        matches = list(re.finditer(r'(?<!\w)(' + re.escape(tested[1]) + r')\s+(?:we|the authors) tested\b', context, re.I))
        if len(matches) == 1:
            return [matches[0][1]]
    attribute=re.fullmatch(r'(?:(?i:stated) )?([A-Z][\w-]+) (?:coverage period|coverage range)(?: for .+)?',entity)
    if attribute:
        return sorted({m[0] for m in re.finditer(r'(?<!\w)'+re.escape(attribute[1])+r'(?!\w)',context)})
    return []


def independent_error_distribution(other, metric):
    """Do not let an independently stated distribution negate an accuracy value."""
    return metric.casefold() == 'accuracy' and bool(re.fullmatch(
        r'\s*(?:however[,]?\s+)?(?:its|their) errors are not evenly distributed(?:,\s*as shown in [\w ]+)?\s*[.]?\s*', other, re.I))


def decision_witness(part, context):
    from .atomic_verifier import target_members
    from .assessment_rules import clauses
    facts=[]
    if part['quantifier']=='atomic':
        for member in target_members(part,context):
            for clause in clauses(context):
                truth=existence_truth(part,member,clause)
                if truth and len(clause)<=384:
                    facts.append((truth,member,clause))
                denied_use=re.search(r'\b(?:was|were) not used as a (test|training|validation) set in any reported experiments?\b',part['quote'],re.I)
                if (denied_use and member.lower() in clause.lower() and len(clause)<=384
                        and re.search(r'\bas a '+re.escape(denied_use[1])+r' set for all (?:the )?experiments reported',clause,re.I)
                        and not re.search(r'\b(?:not|never|might|may|could|if)\b',clause,re.I)):
                    facts.append(('false',member,clause))
                quality=re.search(r'\b(?:(?:did|does|do) (?P<neg>not) )?work(?:s|ed)? well with (?:the )?(?P<object>[\w-]+)[.]?$',part['quote'],re.I)
                stated=re.search(r'\b(?:(?:did|does|do) (?P<neg>not) )?work(?:s|ed)? well\b',clause,re.I)
                if (quality and stated and member in clause and len(clause)<=384
                        and re.search(r'(?<!\w)'+re.escape(quality['object'])+r'(?!\w)',clause)
                        and not re.search(r'\b(?:might|may|could|if|hypothetical)\b',clause,re.I)):
                    facts.append(('true' if bool(quality['neg'])==bool(stated['neg']) else 'false',member,clause))
    if part['quantifier']=='all':
        comparison=re.fullmatch(r'(?:The )?(?P<subject>.+?) outperforms (?:the )?(?P<other>.+?) on (?P<metric>.+?) for every (?P<unit>\w+)[.]?',part['quote'],re.I)
        if comparison:
            for clause in clauses(context):
                exceptions=re.search(r'\bfor all '+re.escape(comparison['unit'])+r's except (?P<names>[A-Z][\w-]*(?: and [A-Z][\w-]*)?) for which the results are identical\b',clause)
                if (exceptions and len(clause)<=384 and all(v.lower() in clause.lower() for v in (comparison['subject'],comparison['other'],comparison['metric']))
                        and not re.search(r'\b(?:not|never|might|may|could|if)\b',clause,re.I)):
                    facts.extend(('false',name,clause) for name in exceptions['names'].split(' and '))
    if not facts or len({f[0] for f in facts})!=1:
        return None
    return dict(truth=facts[0][0],members=sorted({m for _,m,_ in facts}),quotes=sorted({q for _,_,q in facts}),numeric=False)


def owned_clauses(member, quotes, previous):
    result=previous(member,quotes)
    if not re.fullmatch(r'[\w-]+ model',member,re.I):
        return result
    for quote in quotes:
        sentences=[s.strip() for s in re.split(r'(?<=[.!?])\s+',quote) if s.strip()]
        for before,after in zip(sentences,sentences[1:]):
            if (member in before and len(re.findall(r'\bmodel\b',before,re.I))==1
                    and re.search(r'\b(?:employ|use|test|evaluate)\w*\s+(?:a |the )?'+re.escape(member)+r'\b',before,re.I)
                    and re.search(r'\bthe model\s+(?:achieves?|achieved|obtains?|obtained|scores?|scored)\b',after,re.I)
                    and not re.search(r'\b(?:another|other|different|second)\b',before+' '+after,re.I)
                    and len(re.findall(r'\bmodel\b',after,re.I))==1):
                result.append(after)
    return list(dict.fromkeys(result))


def measurement_scope(raw, claim, metric, previous):
    from .cellfix22_classification import classification_measurement
    classification = classification_measurement(raw, claim)
    if classification is not None:
        return classification
    temporal=coverage_range(claim,raw.get('source_quote',''))
    if temporal and raw.get('kind')=='value':
        role,claimed,observed,proof=temporal
        left=raw['left']['quote'];right=raw['right']['quote']
        if left in claimed:
            index=claimed.index(left)
            return proof,right==observed[index]
    if raw.get('kind')=='value' and re.match(r'consists? of\b', metric, re.I):
        subject=re.match(r'(?:The |the )?(.+?) consists of\b',claim)
        if subject:
            target=subject[1]
            chunks=re.split(r';|[.!?](?=\s|$)',raw['source_quote'])
            owning=[c for c in chunks if raw['right']['quote'] in c]
            if owning and not any(re.search(r'(?<!\w)'+re.escape(target)+r'(?!\w)',c,re.I) for c in owning):
                return owning[0].strip(),False
            publisher = re.search(r'\bpublished by (.+?)[.]?$', claim, re.I)
            if publisher:
                qualifier = (r'\s+published by\s+(?:the (?:[\w-]+\s+){0,5}'
                             r'(?:newspaper|publisher|journal|magazine|outlet)\s+)?'
                             + re.escape(publisher[1]) + r'\s*$')
                for clause in owning:
                    if (not re.search(r'\b(?:not|never|might|may|could|if)\b', clause, re.I)
                            and re.search(r'(?<!\w)' + re.escape(target) + r'\s+consists? of\s+'
                                          + re.escape(raw['right']['quote']) + qualifier, clause, re.I)):
                        return clause.strip(), True
                return raw['source_quote'], False
            for clause in chunks:
                if re.search(r'(?<!\w)'+re.escape(target)+r'\s*,\s*of\s+'+re.escape(raw['right']['quote'])+r'(?!\w)',clause,re.I):
                    return clause.strip(),True
        proof,bound=previous(raw,claim,metric)
        if subject and re.search(r'\b(?:corpus|dataset|collection|cohort|group)\b',subject[1],re.I):
            if not re.search(r'(?<!\w)'+re.escape(subject[1])+r'(?!\w)',proof,re.I):
                return proof,False
        return proof,bound
    return previous(raw,claim,metric)


def coverage_range(claim, context):
    """Finite explicitly named coverage range, with population and endpoint roles."""
    start=re.fullmatch(r"The stated (?P<owner>[\w-]+) coverage period for (?P<group>[\w'-]+) matches starts in (?P<a>\d{4})[.]?",claim)
    interval=re.fullmatch(r"(?P<owner>[\w-]+) covers the majority of (?P<group>[\w'-]+) matches from (?P<a>\d{4}) to (?P<b>\d{4})[.]?",claim)
    parsed=start or interval
    if not parsed or not re.search(r'(?<!\w)'+re.escape(parsed['owner'])+r'(?!\w)',context):
        return None
    if re.search(r'\b(?:not|never|might|may|could|if|hypothetical|approximately)\b',context,re.I):
        return None
    if not re.search(r'covers the majority of the matches played',context,re.I):
        return None
    pattern=r"on the "+re.escape(parsed['group'])+r" side from (?P<a>\d{4})[-–](?P<b>\d{4})"
    matches=list(re.finditer(pattern,context,re.I))
    if len(matches)!=1:return None
    found=matches[0]
    claimed=[parsed['a']] if start else [parsed['a'],parsed['b']]
    observed=[found['a']] if start else [found['a'],found['b']]
    return 'start' if start else 'interval',claimed,observed,found[0]


def disjoint_population(part, context):
    """An explicit universal disjointness statement closes the shared-entity set."""
    if part['quantifier']!='some' or part['scope']['entity'].casefold()!='entities':return None
    claim=re.fullmatch(r'Some entities occur in both the (training|validation|testing|development) and (training|validation|testing|development) splits[.]?',part['quote'],re.I)
    if not claim or claim[1].casefold()==claim[2].casefold():return None
    from .assessment_rules import clauses
    from .cellfix22_relations import _ACTIVITY_LIST, split_phases, split_protocol
    phases = {name.casefold() for name in claim.groups()}
    proof = []
    for clause in clauses(context):
        match = re.search(r'(?:^|\bensure that\s+)entities do not overlap across '
                          r'(?:(?:the )?(?P<splits>' + _ACTIVITY_LIST + r') )?splits\b', clause, re.I)
        if not match or re.search(r'\b(?:might|may|could|if|unless|cannot|not true|not ensure|not all)\b', clause, re.I) or len(clause)>384:
            continue
        observed = split_phases(match['splits']) if match['splits'] else split_protocol(context)
        if phases <= observed:
            proof.append(clause)
    if len(proof)!=1:return None
    return dict(truth='false',members=['entities'],quotes=proof,numeric=False,complete=True,population=True)
